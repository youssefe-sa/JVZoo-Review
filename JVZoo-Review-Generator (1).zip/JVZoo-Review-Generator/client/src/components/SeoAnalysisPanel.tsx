import { useState, useEffect } from "react";
import { Progress } from "@/components/ui/progress";
import { SeoAnalysis } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { 
  AlertCircle, 
  CheckCircle, 
  Info, 
  BarChart2, 
  BookOpen, 
  Award, 
  ArrowUpRight,
  FileText,
  Type,
  Link2,
  Hash
} from "lucide-react";

interface SeoAnalysisPanelProps {
  reviewContent: string | null;
  targetKeyword: string;
  focusKeyphrase?: string;
  keywordSynonyms?: string;
  secondaryKeywords?: string;
  longTailKeywords?: string;
  metaDescription?: string;
  includeStructuredData?: boolean;
}

export default function SeoAnalysisPanel({
  reviewContent,
  targetKeyword,
  focusKeyphrase = "",
  keywordSynonyms = "",
  secondaryKeywords = "",
  longTailKeywords = "",
  metaDescription = "",
  includeStructuredData = true
}: SeoAnalysisPanelProps) {
  const [analysis, setAnalysis] = useState<SeoAnalysis>({
    score: 85,
    keywordDensity: { [targetKeyword || 'product review']: 2.1 },
    suggestions: [
      "Add more heading tags (H2, H3) throughout the review",
      "Include the target keyword in the first 100 words",
      "Increase the content length for better SEO performance"
    ],
    wordCount: reviewContent ? countWords(reviewContent) : 0,
    readabilityScore: 72
  });
  
  // Analyze the content when the review changes
  useEffect(() => {
    if (reviewContent) {
      // Real implementation would do actual SEO analysis here
      analyzeContent(reviewContent);
    }
  }, [reviewContent, targetKeyword]);
  
  // Analyze the content for SEO and readability
  function analyzeContent(content: string) {
    const wordCount = countWords(content);
    const strippedText = stripHtml(content);
    
    // Calculate keyword density
    const keywordDensity: Record<string, number> = {};
    if (targetKeyword) {
      const keywordRegex = new RegExp(targetKeyword, 'gi');
      const keywordMatches = strippedText.match(keywordRegex) || [];
      const keywordDensityValue = ((keywordMatches.length / wordCount) * 100).toFixed(1);
      keywordDensity[targetKeyword] = parseFloat(keywordDensityValue);
    }
    
    // Calculate reading time (average reading speed is ~225 words per minute)
    const readingTimeMinutes = Math.max(1, Math.ceil(wordCount / 225));
    
    // Generate SEO suggestions and checks
    const suggestions: string[] = [];
    const seoChecks: {title: string, passed: boolean, importance: 'high' | 'medium' | 'low'}[] = [];
    
    // Check Title Tag (H1)
    const hasH1 = /<h1[^>]*>/i.test(content);
    const keywordInH1 = hasH1 && new RegExp(`<h1[^>]*>.*?${targetKeyword}.*?</h1>`, 'i').test(content);
    
    if (!hasH1) {
      suggestions.push("Add an H1 title tag to your content");
      seoChecks.push({
        title: "Content has H1 heading",
        passed: false,
        importance: 'high'
      });
    } else if (!keywordInH1) {
      suggestions.push("Include your target keyword in the H1 title");
      seoChecks.push({
        title: "Target keyword in H1",
        passed: false,
        importance: 'high'
      });
    } else {
      seoChecks.push({
        title: "Target keyword in H1",
        passed: true,
        importance: 'high'
      });
    }
    
    // Check meta description
    if (!metaDescription) {
      suggestions.push("Add a meta description with your target keyword");
      seoChecks.push({
        title: "Meta description present",
        passed: false,
        importance: 'high'
      });
    } else if (metaDescription.length < 120) {
      suggestions.push("Meta description is too short (aim for 120-160 characters)");
      seoChecks.push({
        title: "Meta description length",
        passed: false,
        importance: 'medium'
      });
    } else if (metaDescription.length > 160) {
      suggestions.push("Meta description is too long (keep under 160 characters)");
      seoChecks.push({
        title: "Meta description length",
        passed: false,
        importance: 'medium'
      });
    } else {
      seoChecks.push({
        title: "Meta description length",
        passed: true,
        importance: 'medium'
      });
    }
    
    // Check keyword density
    const idealDensityMin = 0.8;
    const idealDensityMax = 2.5;
    const density = keywordDensity[targetKeyword] || 0;
    
    if (density < idealDensityMin) {
      suggestions.push(`Keyword density (${density}%) is too low. Aim for ${idealDensityMin}-${idealDensityMax}%`);
      seoChecks.push({
        title: "Keyword density",
        passed: false,
        importance: 'medium'
      });
    } else if (density > idealDensityMax) {
      suggestions.push(`Keyword density (${density}%) is too high. Aim for ${idealDensityMin}-${idealDensityMax}%`);
      seoChecks.push({
        title: "Keyword density",
        passed: false,
        importance: 'medium'
      });
    } else {
      seoChecks.push({
        title: "Keyword density",
        passed: true,
        importance: 'medium'
      });
    }
    
    // Check content length
    const minContentLength = 1000;
    if (wordCount < minContentLength) {
      suggestions.push(`Content length (${wordCount} words) is too short. Aim for at least ${minContentLength} words for better ranking`);
      seoChecks.push({
        title: "Content length",
        passed: false,
        importance: 'high'
      });
    } else {
      seoChecks.push({
        title: "Content length",
        passed: true,
        importance: 'high'
      });
    }
    
    // Check heading structure (H2, H3)
    const h2Count = (content.match(/<h2[^>]*>/g) || []).length;
    const h3Count = (content.match(/<h3[^>]*>/g) || []).length;
    
    if (h2Count < 2) {
      suggestions.push("Add more H2 headings to structure your content");
      seoChecks.push({
        title: "H2 headings present",
        passed: false,
        importance: 'medium'
      });
    } else {
      seoChecks.push({
        title: "H2 headings present",
        passed: true,
        importance: 'medium'
      });
    }
    
    // Check internal links
    const internalLinks = (content.match(/<a[^>]*href=["'][^"']*["'][^>]*>/g) || []).length;
    if (internalLinks < 2) {
      suggestions.push("Add more internal links to enhance SEO and user experience");
      seoChecks.push({
        title: "Internal links",
        passed: false,
        importance: 'medium'
      });
    } else {
      seoChecks.push({
        title: "Internal links",
        passed: true,
        importance: 'medium'
      });
    }
    
    // Check for images with alt text
    const imagesWithAlt = (content.match(/<img[^>]*alt=["'][^"']*["'][^>]*>/g) || []).length;
    const imagesWithoutAlt = (content.match(/<img(?![^>]*alt=["'][^"']*["'])[^>]*>/g) || []).length;
    
    if (imagesWithoutAlt > 0) {
      suggestions.push(`${imagesWithoutAlt} image(s) missing alt text. Add descriptive alt attributes to all images`);
      seoChecks.push({
        title: "Image alt attributes",
        passed: false,
        importance: 'medium'
      });
    } else if (imagesWithAlt > 0) {
      seoChecks.push({
        title: "Image alt attributes",
        passed: true,
        importance: 'medium'
      });
    }
    
    // Calculate SEO score based on checks
    const highImportanceChecks = seoChecks.filter(check => check.importance === 'high');
    const mediumImportanceChecks = seoChecks.filter(check => check.importance === 'medium');
    const lowImportanceChecks = seoChecks.filter(check => check.importance === 'low');
    
    const highScore = highImportanceChecks.filter(check => check.passed).length / (highImportanceChecks.length || 1) * 50;
    const mediumScore = mediumImportanceChecks.filter(check => check.passed).length / (mediumImportanceChecks.length || 1) * 35;
    const lowScore = lowImportanceChecks.filter(check => check.passed).length / (lowImportanceChecks.length || 1) * 15;
    
    const seoScore = Math.min(100, Math.round(highScore + mediumScore + lowScore));
    
    // Calculate readability score (simplified)
    // In a real implementation, this would use algorithms like Flesch-Kincaid
    const paragraphs = (content.match(/<p[^>]*>.*?<\/p>/g) || []).length;
    const avgSentenceLength = strippedText.split(/[.!?]+/).filter(s => s.trim().length > 0).map(s => s.split(/\s+/).length).reduce((a, b) => a + b, 0) / paragraphs;
    
    // Simplified readability calculation - in reality, would use more sophisticated methods
    const readabilityScore = Math.min(100, Math.max(40, Math.round(100 - (avgSentenceLength - 15) * 2)));
    
    setAnalysis({
      score: seoScore,
      keywordDensity,
      suggestions,
      wordCount,
      readabilityScore,
      seoChecks,
      readingTimeMinutes
    });
  }
  
  function stripHtml(html: string): string {
    return html.replace(/<[^>]*>/g, '');
  }
  
  function countWords(text: string): number {
    // Strip HTML tags
    const strippedText = stripHtml(text);
    // Split by whitespace and filter out empty strings
    const words = strippedText.split(/\s+/).filter(word => word.length > 0);
    return words.length;
  }
  
  // Calculate score color based on value
  const getSeoScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };
  
  const getProgressColor = (score: number) => {
    if (score >= 80) return "bg-green-600";
    if (score >= 60) return "bg-yellow-600";
    return "bg-red-600";
  };
  
  if (!reviewContent) {
    return null;
  }
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mt-4">
      <div className="p-4 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <BarChart2 className="h-5 w-5 text-indigo-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-800">SEO Analysis & Insights</h2>
          </div>
          <Badge variant="outline" className="bg-gradient-to-r from-indigo-50 to-blue-50 text-indigo-700 border-indigo-200">
            <span className="flex items-center text-xs">
              <Award className="h-3 w-3 mr-1" />
              Pro Analysis
            </span>
          </Badge>
        </div>
      </div>
      
      <div className="p-4">
        <div className="grid grid-cols-3 gap-4">
          <div className="border border-gray-200 rounded-lg p-3 relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-gray-700 flex items-center">
                <svg className="h-4 w-4 mr-1.5 text-indigo-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="m15 9-6 6"></path>
                  <path d="m9 9 6 6"></path>
                </svg>
                SEO Score
              </h3>
              <div className="relative">
                <div className={`flex items-center justify-center w-12 h-12 rounded-full ${getProgressColor(analysis.score).replace('bg-', 'bg-opacity-20 bg-')} text-${getProgressColor(analysis.score).replace('bg-', '')}`}>
                  <span className={`text-base font-bold ${getSeoScoreColor(analysis.score)}`}>
                    {analysis.score}
                  </span>
                </div>
                <div className="absolute -top-1 -right-1 w-5 h-5 bg-white rounded-full flex items-center justify-center shadow-sm">
                  {analysis.score >= 80 ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-green-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-yellow-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  )}
                </div>
              </div>
            </div>
            <div className="mb-3">
              <div className="relative pt-1">
                <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                  <div 
                    className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center transition-all duration-500 ${getProgressColor(analysis.score)}`} 
                    style={{ width: `${analysis.score}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>0</span>
                  <span>50</span>
                  <span>100</span>
                </div>
              </div>
            </div>
            <p className="text-xs text-gray-600 mt-1">
              {analysis.score >= 80 
                ? "Great! Your content is well-optimized for search engines." 
                : analysis.score >= 60 
                  ? "Good start. Some improvements could help your search ranking." 
                  : "Needs improvement to rank well in search results."}
            </p>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-3 relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-gray-700 flex items-center">
                <svg className="h-4 w-4 mr-1.5 text-indigo-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
                  <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
                </svg>
                Readability
              </h3>
              <div className="relative">
                <div className={`flex items-center justify-center w-12 h-12 rounded-full ${
                  analysis.readabilityScore >= 70 
                    ? "bg-green-100 text-green-600" 
                    : analysis.readabilityScore >= 50 
                      ? "bg-yellow-100 text-yellow-600" 
                      : "bg-red-100 text-red-600"
                }`}>
                  <span className={`text-base font-bold ${
                    analysis.readabilityScore >= 70 
                      ? "text-green-600" 
                      : analysis.readabilityScore >= 50 
                        ? "text-yellow-600" 
                        : "text-red-600"
                  }`}>
                    {analysis.readabilityScore}
                  </span>
                </div>
                <div className="absolute -top-1 -right-1 w-5 h-5 bg-white rounded-full flex items-center justify-center shadow-sm">
                  {analysis.readabilityScore >= 70 ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-green-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-yellow-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  )}
                </div>
              </div>
            </div>
            <div className="mb-3">
              <div className="relative pt-1">
                <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                  <div 
                    className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center transition-all duration-500 ${
                      analysis.readabilityScore >= 70 
                        ? "bg-green-600" 
                        : analysis.readabilityScore >= 50 
                          ? "bg-yellow-600" 
                          : "bg-red-600"
                    }`} 
                    style={{ width: `${analysis.readabilityScore}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>Basic</span>
                  <span>Advanced</span>
                </div>
              </div>
            </div>
            <p className="text-xs text-gray-600 mt-1">
              {analysis.readabilityScore >= 70 
                ? "Excellent! Your content is easy to read and understand." 
                : analysis.readabilityScore >= 50 
                  ? "Your content is somewhat readable but could be simplified." 
                  : "Your content may be difficult for the average reader."}
            </p>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-3 relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-gray-700 flex items-center">
                <svg className="h-4 w-4 mr-1.5 text-indigo-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
                Content Stats
              </h3>
            </div>
            
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="bg-gradient-to-r from-indigo-50 to-blue-50 p-3 rounded-lg flex items-center">
                <div className="bg-white rounded-full p-2 shadow-sm mr-3 flex-shrink-0">
                  <svg className="h-4 w-4 text-indigo-600" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="16" y1="13" x2="8" y2="13"></line>
                    <line x1="16" y1="17" x2="8" y2="17"></line>
                    <polyline points="10 9 9 9 8 9"></polyline>
                  </svg>
                </div>
                <div>
                  <div className="text-base font-bold text-indigo-700">
                    {analysis.wordCount.toLocaleString()}
                  </div>
                  <div className="text-xs text-indigo-600">Total Words</div>
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-3 rounded-lg flex items-center">
                <div className="bg-white rounded-full p-2 shadow-sm mr-3 flex-shrink-0">
                  <svg className="h-4 w-4 text-purple-600" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <polyline points="12 6 12 12 16 14"></polyline>
                  </svg>
                </div>
                <div>
                  <div className="text-base font-bold text-purple-700">
                    {analysis.readingTimeMinutes || Math.ceil(analysis.wordCount / 225)}
                  </div>
                  <div className="text-xs text-purple-600">Min Read Time</div>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-xs font-medium text-gray-700 flex items-center">
                  <svg className="h-3 w-3 mr-1 text-indigo-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="4" y1="9" x2="20" y2="9"></line>
                    <line x1="4" y1="15" x2="20" y2="15"></line>
                    <line x1="10" y1="3" x2="8" y2="21"></line>
                    <line x1="16" y1="3" x2="14" y2="21"></line>
                  </svg>
                  Keyword Density
                </span>
                {Object.entries(analysis.keywordDensity).map(([keyword, density]) => {
                  const isGood = density >= 0.8 && density <= 2.5;
                  return (
                    <span key={keyword} className={`text-xs font-medium px-2 py-0.5 rounded-full ${isGood ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                      {density}%
                    </span>
                  );
                })}
              </div>
              <div className="text-xs text-gray-600 truncate">
                {Object.keys(analysis.keywordDensity).map(keyword => (
                  <span key={keyword} className="italic">
                    "{keyword.length > 20 ? keyword.substring(0, 20) + '...' : keyword}"
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mt-4">
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
              <FileText className="h-4 w-4 mr-1 text-indigo-500" />
              Content Analysis
            </h3>
            <div className="border border-gray-200 rounded-lg p-3 space-y-3">
              <div>
                <div className="mb-1 flex justify-between">
                  <h4 className="text-xs font-medium text-gray-700">Keyword Strategy</h4>
                  <span className="text-xs text-green-600 font-medium">
                    {targetKeyword ? "Configured" : "Not Set"}
                  </span>
                </div>
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center bg-gray-50 p-2 rounded-md">
                    <span className="text-xs text-gray-600 flex items-center">
                      <Hash className="h-3 w-3 mr-1 text-indigo-400" />
                      Primary Keyword
                    </span>
                    <span className="text-xs font-medium">{targetKeyword || 'Not set'}</span>
                  </div>
                  {focusKeyphrase && (
                    <div className="flex justify-between items-center bg-gray-50 p-2 rounded-md">
                      <span className="text-xs text-gray-600 flex items-center">
                        <Type className="h-3 w-3 mr-1 text-indigo-400" />
                        Focus Keyphrase
                      </span>
                      <span className="text-xs font-medium">{focusKeyphrase}</span>
                    </div>
                  )}
                  {secondaryKeywords && (
                    <div className="flex justify-between items-center bg-gray-50 p-2 rounded-md">
                      <span className="text-xs text-gray-600 flex items-center">
                        <Hash className="h-3 w-3 mr-1 text-indigo-400" />
                        Secondary Keywords
                      </span>
                      <span className="text-xs font-medium">
                        {secondaryKeywords.length > 25 
                          ? secondaryKeywords.substring(0, 25) + '...' 
                          : secondaryKeywords}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              
              <div>
                <div className="mb-1 flex justify-between">
                  <h4 className="text-xs font-medium text-gray-700">Technical SEO</h4>
                  <span className="text-xs text-green-600 font-medium">
                    {includeStructuredData ? "Enabled" : "Disabled"}
                  </span>
                </div>
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center bg-gray-50 p-2 rounded-md">
                    <span className="text-xs text-gray-600 flex items-center">
                      <Link2 className="h-3 w-3 mr-1 text-indigo-400" />
                      Internal Links
                    </span>
                    <span className="text-xs font-medium">
                      {(reviewContent.match(/<a[^>]*href=["'][^"']*["'][^>]*>/g) || []).length} links
                    </span>
                  </div>
                  <div className="flex justify-between items-center bg-gray-50 p-2 rounded-md">
                    <span className="text-xs text-gray-600 flex items-center">
                      <Type className="h-3 w-3 mr-1 text-indigo-400" />
                      Headings Structure
                    </span>
                    <span className="text-xs font-medium">
                      H1: {(reviewContent.match(/<h1[^>]*>/g) || []).length}, 
                      H2: {(reviewContent.match(/<h2[^>]*>/g) || []).length}, 
                      H3: {(reviewContent.match(/<h3[^>]*>/g) || []).length}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
              <ArrowUpRight className="h-4 w-4 mr-1 text-indigo-500" />
              Improvement Suggestions
            </h3>
            <div className="border border-gray-200 rounded-lg p-3">
              {analysis.suggestions.length > 0 ? (
                <ul className="space-y-2">
                  {analysis.suggestions.map((suggestion, index) => (
                    <li key={index} className="text-xs text-gray-600 flex items-start">
                      <AlertCircle className="h-3 w-3 mr-1.5 flex-shrink-0 mt-0.5 text-yellow-500" />
                      {suggestion}
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="flex items-center justify-center h-16 text-center">
                  <div>
                    <CheckCircle className="h-5 w-5 text-green-500 mb-1 mx-auto" />
                    <p className="text-xs text-green-600 font-medium">
                      No suggestions - content is well optimized!
                    </p>
                  </div>
                </div>
              )}
            </div>
            
            {analysis.seoChecks && (
              <div className="mt-3 border border-gray-200 rounded-lg p-3">
                <h4 className="text-xs font-medium text-gray-700 mb-2">SEO Checklist</h4>
                <div className="space-y-1.5">
                  {analysis.seoChecks.map((check, index) => (
                    <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded-md">
                      <span className="text-xs text-gray-600 flex items-center">
                        {check.passed ? (
                          <CheckCircle className="h-3 w-3 mr-1.5 text-green-500" />
                        ) : (
                          <AlertCircle className="h-3 w-3 mr-1.5 text-yellow-500" />
                        )}
                        {check.title}
                      </span>
                      <Badge 
                        variant="outline" 
                        className={check.importance === 'high' 
                          ? 'border-red-200 bg-red-50 text-red-700 text-xs px-1.5 py-0' 
                          : check.importance === 'medium'
                            ? 'border-yellow-200 bg-yellow-50 text-yellow-700 text-xs px-1.5 py-0'
                            : 'border-blue-200 bg-blue-50 text-blue-700 text-xs px-1.5 py-0'
                        }
                      >
                        {check.importance}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
        
        <div className="mt-4 bg-gradient-to-r from-indigo-50 to-blue-50 border-l-4 border-indigo-400 p-3 rounded-r-md">
          <div className="flex">
            <Info className="h-4 w-4 mt-0.5 mr-2 flex-shrink-0 text-indigo-600" />
            <div>
              <p className="text-xs text-indigo-800 font-medium">Google Ranking Factors</p>
              <p className="text-xs text-indigo-700 mt-1">
                For maximum search visibility: (1) Use a properly structured hierarchy of headings with keywords, 
                (2) Ensure optimal keyword density (1-2%), (3) Include keyword variations naturally, 
                (4) Create comprehensive content (1,500+ words), and (5) Optimize for user engagement metrics.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}