import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  generateReviewSchema, 
  loginUserSchema, 
  registerUserSchema, 
  forgotPasswordSchema, 
  paymentFormSchema,
  subscriptionSchema,
  users,
  subscriptionPlans
} from "@shared/schema";
import { eq, or } from 'drizzle-orm';
import { db } from './db';
import { ZodError } from "zod";
import * as crypto from 'crypto';
import session from 'express-session';
import memoryStoreModule from 'memorystore';
import * as firebaseAdmin from './firebase-admin';

// Session data is defined in client/src/types/express-session.d.ts

// Helper function to format Zod validation errors
function formatZodError(error: ZodError) {
  return error.errors.map(err => ({
    path: err.path.join('.'),
    message: err.message
  }));
}

// Function to call Google AI Studio API
async function callGoogleAIStudio(apiKey: string, model: string, prompt: string): Promise<string> {
  try {
    const modelMap: Record<string, string> = {
      'gemini-1.5-pro': 'models/gemini-1.5-pro',
      'gemini-1.5-flash': 'models/gemini-1.5-flash',
      'gemini-2.0-flash': 'models/gemini-2.0-flash',
      'gemini-2.5-pro-exp': 'models/gemini-2.5-pro-exp-03-25', // Experimental version that has free quota
      'gemini-1.0-pro': 'models/gemini-pro-vision', // This maps to a valid model
      'gemini-pro': 'models/gemini-pro-vision', // Legacy model
      'gemini-flash': 'models/gemini-1.5-flash', // Alias for latest flash model
      'default': 'models/gemini-2.5-pro-exp-03-25' // Set default to the experimental version
    };
    
    const modelId = modelMap[model] || modelMap['default'];
    const url = `https://generativelanguage.googleapis.com/v1beta/${modelId}:generateContent?key=${apiKey}`;
    
    console.log(`Using model: ${modelId} for request`);

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: prompt
              }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 30000, // Increased max tokens for longer reviews
        },
        safetySettings: [
          {
            category: "HARM_CATEGORY_HARASSMENT",
            threshold: "BLOCK_NONE"
          },
          {
            category: "HARM_CATEGORY_HATE_SPEECH",
            threshold: "BLOCK_NONE"
          },
          {
            category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
            threshold: "BLOCK_NONE"
          },
          {
            category: "HARM_CATEGORY_DANGEROUS_CONTENT",
            threshold: "BLOCK_NONE"
          }
        ]
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Google AI API error: ${response.status} - ${errorText}`);
      throw new Error(`Google AI API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    
    // Check if we have valid data structure
    if (!data.candidates || !data.candidates[0] || !data.candidates[0].content || !data.candidates[0].content.parts || !data.candidates[0].content.parts[0]) {
      console.error('Unexpected API response structure:', JSON.stringify(data));
      throw new Error('Received malformed response from Google AI API. The response did not contain expected content structure.');
    }
    
    // Check if we have text content
    if (!data.candidates[0].content.parts[0].text) {
      console.error('Missing text content in API response:', JSON.stringify(data.candidates[0]));
      throw new Error('The AI model did not return any text content. Please try again or use a different model.');
    }
    
    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error('Error calling Google AI API:', error);
    
    // Enhance error message for common issues
    if (error instanceof Error) {
      if (error.message.includes('429')) {
        error.message = 'Rate limit exceeded. The API is receiving too many requests. Please try again in a few minutes.';
      } else if (error.message.includes('401') || error.message.includes('403')) {
        error.message = 'Authentication error. Please check your API key is valid and has the necessary permissions.';
      } else if (error.message.includes('404')) {
        error.message = 'Model not found. The selected AI model may not be available or you may need to check your model name.';
      } else if (error.message.includes('timeout') || error.message.includes('ECONNRESET')) {
        error.message = 'The request timed out. This may be due to generating a very long review. Try using a shorter review length setting.';
      }
    }
    
    throw error;
  }
}

// Generate a prompt for the AI model
function generatePrompt(data: any): string {
  // Format SEO keywords
  const seoSection = data.targetKeyword ? `
SEO OPTIMIZATION REQUIREMENTS:
- Primary Keyword: ${data.targetKeyword} (use in title, H1, meta description, first paragraph, and conclusion)
${data.focusKeyphrase ? `- Focus Keyphrase: "${data.focusKeyphrase}" (use in title tag and H1 heading)` : ''}
${data.secondaryKeywords ? `- Secondary Keywords: ${data.secondaryKeywords} (distribute naturally throughout content)` : ''}
${data.keywordSynonyms ? `- LSI Keywords & Synonyms: ${data.keywordSynonyms} (use to avoid keyword stuffing)` : ''}
${data.longTailKeywords ? `- Long-tail Keywords: ${data.longTailKeywords} (incorporate into subheadings)` : ''}
${data.keywordDensity ? `- Target Keyword Density: ${data.keywordDensity}% (maintain natural language flow)` : '- Maintain keyword density between 1-2%'}
${data.keywordPosition ? `- Keyword Placement Strategy: ${data.keywordPosition} distribution` : ''}
${data.targetSearchIntent ? `- Search Intent: Optimize for ${data.targetSearchIntent} search intent` : ''}

META TAG SPECIFICATIONS:
${data.metaDescription ? `- Meta Description: "${data.metaDescription}"` : '- Create a compelling meta description (120-160 characters) that includes the primary keyword and a call to action'}
${data.includeSeoMetaTags ? `- Include SEO meta tags (title, description, keywords)` : ''}
${data.includeCanonicalUrl ? `- Add canonical URL tag` : ''}
${data.includeOpenGraph ? `- Include Open Graph meta tags for social sharing` : ''}
${data.includeTwitterCard ? `- Include Twitter Card meta tags for social sharing` : ''}
${data.includeSeoSchema ? `- Add schema.org structured data for Product Review` : ''}
${data.includeFaq ? `- Implement FAQ schema markup in the FAQ section` : ''}
${data.includeHowTo ? `- Implement HowTo schema markup in the step-by-step section` : ''}

CONTENT STRUCTURE OPTIMIZATION:
${data.includeTableOfContents ? `- Add a table of contents with anchor links` : ''}
${data.targetFeaturedSnippet ? `- Structure content to target featured snippets (use Q&A format in key sections)` : ''}
${data.optimizeSlugs ? `- Suggest SEO-friendly URL structure` : ''}
${data.optimizeImages ? `- Include proper image alt text and title attributes that contain keywords where appropriate` : ''}
- Implement proper heading hierarchy (H1 → H2 → H3) with keywords in headings
- Use short paragraphs (3-4 sentences max) for improved readability
- Include bulleted or numbered lists where appropriate (helps with featured snippets)
- Add internal linking suggestions with keyword-rich anchor text
- Use responsive, fast-loading image suggestions
- Ensure content is at least 1,500-2,000 words for comprehensive coverage
- Include LSI (Latent Semantic Indexing) keywords throughout the content
` : '';

  // Enhanced professional review template structure
  const reviewTemplateStructure = `
REVIEW TEMPLATE STRUCTURE:
1. HEADER & INTRODUCTION
   - H1: [${data.productName}] Review 2025: Honest Analysis & Results
   - Create a compelling hook using PAS (Problem-Agitation-Solution) framework to grab attention
   - Include a brief product summary (2-3 sentences) that highlights the core value proposition
   - Add a professional product rating box (${data.productRatingScore || '4.5'}/5) with star visualization ★★★★★
   - Include a featured image placeholder with proper alt text

2. MAIN CONTENT STRUCTURE
   - H2: What is [${data.productName}]? (Include product image)
     - Clear, concise explanation of the product's purpose and core functionality
     - Highlight the primary problem it solves and target audience
     - Include professionally formatted product image with proper caption
   
   - H2: Who Created [${data.productName}]? (Creator Credibility Section)
     - Brief background on creator's expertise and authority
     - Previous successful products or relevant experience
     - Add creator image if available
   
   - H2: How [${data.productName}] Works (Process Section)
     - Step-by-step breakdown of how the product functions
     - Use numbered steps with clear headings for each step
     - Include visual flow diagram or process illustration (placeholder)
   
   - H2: Key Benefits of [${data.productName}]
     - Format as visually distinct benefit boxes with icons
     - Each benefit should have a clear headline and 2-3 sentences of explanation
     - Use consistent styling for all benefit elements

   - H2: Top Features of [${data.productName}]
     - H3: [Feature 1] - with detailed explanation and practical application
     - H3: [Feature 2] - with detailed explanation and practical application
     - H3: [Feature 3] - with detailed explanation and practical application
     - H3: [Feature 4] - with detailed explanation and practical application
     - H3: [Feature 5] - with detailed explanation and practical application
     - Format each feature as a distinct card with icon, title, and description
     - Include relevant screenshots for each feature (placeholders)

3. PRICING SECTION
   - H2: [${data.productName}] Pricing & Plans
   - Create a professionally formatted pricing table with:
     - Column headers: Plan Name | Price | Features | Best For
     - Style the header row with a distinct background color
     - Include "Recommended" badge on the best value option
     - Add check marks (✓) for included features
   - Below pricing table, include a special discount notification box if applicable
   - IMPORTANT: Add a professionally styled CTA button with compelling action text

4. EVALUATION SECTION
   - H2: Pros and Cons of [${data.productName}]
   - Format as two-column layout on desktop (stack on mobile)
   - H3: [${data.productName}] Pros (styled in green with checkmark icons)
     - Use bulleted list with descriptive points (not just one-word items)
     - Each pro should explain the benefit and why it matters
   - H3: [${data.productName}] Cons (styled in red with x-mark icons)
     - Honest assessment of limitations (minimum 3 points)
     - Each con should be balanced and fair (not deal-breakers)

5. SOCIAL PROOF
   - H2: User Results & Testimonials
   - Format testimonials as distinct cards with:
     - User name and relevant details (occupation, results achieved)
     - Star rating (★★★★★)
     - Brief quote in italics with quotation marks
     - Avatar/image placeholder (generic user icon)
   - Style each testimonial with subtle border, background and spacing

6. COMPARISON SECTION (if comparison table enabled)
   - H2: How [${data.productName}] Compares to Alternatives
   - Create a feature comparison table with:
     - Row 1: Product names with logos/icons
     - Rows 2+: Feature-by-feature comparison
     - Highlight where [${data.productName}] excels with green checkmarks
     - Use color coding for easy scanning (green = good, red = bad)
   - Add a short paragraph explaining why [${data.productName}] is superior

7. PERSONAL EXPERIENCE
   - H2: My Personal Experience with [${data.productName}]
   - Include "case study" format with:
     - Initial situation and goals
     - Implementation process with timeline
     - Results achieved (with specific metrics if possible)
     - Screenshots of actual usage (placeholders)
   - Format as a narrative journey with clear before/after elements

8. BONUS SECTION (if bonus enabled)
   - H2: Exclusive Bonuses When You Purchase Today
   - Format each bonus as a visually distinct element with:
     - Eye-catching bonus value ($XX Value)
     - Clear bonus title with icon
     - 2-3 sentence description of the bonus
     - How it complements the main product
   - Add a total bonus value calculation at the end
   - Include a countdown timer element for urgency

9. FAQ SECTION (if FAQ enabled)
   - H2: Frequently Asked Questions
   - Format as expandable accordion elements with:
     - Questions in bold with toggle indicators
     - Clear, direct answers without fluff
     - Cover common objections and concerns
   - Include 6-8 relevant questions addressing common concerns

10. CONCLUSION & CALL TO ACTION
    - H2: Final Verdict: Is [${data.productName}] Worth It?
    - Summarize key points from the review
    - Provide clear recommendation for specific use cases
    - Include a final "verdict" rating box
    - Add PROMINENT final call-to-action section with:
      - High-contrast button styling
      - Compelling button text
      - Urgency/scarcity elements if applicable
      - Final benefit reinforcement
    - Include money-back guarantee reminder if applicable

11. DESIGN REQUIREMENTS
    - Use a clean, professional design throughout
    - Maintain consistent styling for headings, lists, and UI elements
    - Ensure all buttons are large, visually distinct and compelling
    - Add subtle separation between sections (dividers, background colors)
    - Use appropriate icons to enhance visual appeal and scanability
    - Ensure responsive design with mobile optimization
`;

  // Format advanced features
  const advancedFeaturesSection = `
ADVANCED FEATURES:
${data.includeComparisonTable ? `- Include a comparison table comparing ${data.productName} with ${data.competingProducts || 'competing products'}` : ''}
${data.includeTestimonials ? '- Include 2-3 realistic testimonials from satisfied customers' : ''}
${data.includeProductRating ? `- Display a product rating of ${data.productRatingScore || '4.5'} out of 5 stars` : ''}
${data.includeBonusSection ? `- Include a special bonus section offering: ${data.bonusContent || 'exclusive bonuses for readers who purchase through your link'}` : ''}
`;

  // Format theme/style settings
  const themeSection = `
STYLING AND FORMATTING REQUIREMENTS:
- Apply the ${data.reviewTheme || 'classic'} theme style to the review with consistent branding
- Create a clean, premium layout with proper spacing and alignment throughout
- Use a professional color scheme appropriate for the niche (${data.reviewTheme === 'luxury' ? 'dark backgrounds with gold accents' : data.reviewTheme === 'modern' ? 'clean whites with bold accent colors' : 'classic blue and white with gray accents'})
- Ensure all HTML elements use semantic markup (article, section, aside, etc.)
- Use CSS Grid or Flexbox for layout (not tables for layout purposes)
- Create visual hierarchy through consistent heading styles (H1, H2, H3)
- Style all CTA buttons with high-conversion elements:
  * High-contrast colors (e.g., orange or green on light backgrounds)
  * Rounded corners with subtle shadows
  * Clear action text ("Get [Product] Now", not just "Click Here")
  * Hover effects that enhance visibility
  * Arrow icons or similar visual indicators
- Apply professional container styles:
  * Subtle box shadows
  * Light border radius on containers
  * Proper internal padding (1.5-2em)
  * Alternating background colors for visual separation
- Format lists consistently with:
  * Custom bullet points or icons for unordered lists
  * Numbered steps with visual emphasis for ordered lists
  * Proper indentation and line spacing
- Include responsive breakpoints:
  * Desktop (1200px+): Multi-column layouts, larger visuals
  * Tablet (768px-1199px): Simplified grid layouts, optimized spacing
  * Mobile (320px-767px): Single column, touch-friendly elements
- Add subtle animations or transitions for:
  * Button hover states
  * Accordion/tab interfaces
  * Rating widgets
  * Testimonial carousels

VISUAL ELEMENTS:
- For star ratings: Use actual star characters (★★★★★) or SVG star icons with proper color
- For product images: Add professional borders, subtle shadows and proper captions
- For CTA buttons: Include arrow icons (→) or other visual indicators
- For comparison tables: Use color-coding and icons for easy scanning
- For pricing tables: Add visual hierarchy with featured/recommended options
- For pros/cons: Include green checkmarks and red X icons
- For testimonials: Include quotation marks and user avatars
- For benefit boxes: Use appropriate icons for each benefit

${data.includeProductImages && data.productImagesList && data.productImagesList.length > 0 ? `
PRODUCT IMAGES:
${data.productImagesList.map((img: any, index: number) => `
- Image ${index + 1}:
  * URL: ${img.url}
  * Caption: ${img.caption || 'Product image'}
  * Alt Text: ${img.altText || img.caption || 'Product image'}
  * Position: ${img.position} section
  * Size: ${img.size}
  * Alignment: ${img.alignment}
  * Style: ${img.style}
`).join('')}
` : ''}
`;

  // Format professional copywriting instructions
  const copywritingSection = data.useMarketingCopywriting ? `
PROFESSIONAL COPYWRITING (ELITE LEVEL):
- Implement advanced multi-layered AIDA framework (Attention, Interest, Desire, Action)
- Weave in sophisticated PAS formula (Problem, Agitation, Solution) with complex psychological triggers
- Use expert storytelling techniques with consumer transformation narratives
- Apply strategic NLP (Neuro-Linguistic Programming) patterns for maximum persuasion
- Employ powerful emotional language with benefit-driven copy throughout
- Create authentic urgency and legitimized scarcity elements without being salesy
- Implement "future-pacing" to help readers imagine successful outcomes
- Use authority positioning elements and strategic social proof references
- Include multiple pattern interrupts to maintain reader engagement
- Build compelling objection-handling sections that address common concerns
` : '';

  // Determine length based on extended word count
  const lengthSetting = data.extendedWordCount ? 'Ultra-Comprehensive (3,500+ words)' : 
                      data.reviewStyle === 'ultra-comprehensive' ? 'Ultra-Comprehensive (3,500+ words)' :
                      data.reviewStyle === 'comprehensive' ? 'Comprehensive (2000+ words)' : 
                      data.reviewStyle === 'balanced' ? 'Balanced (1200-1500 words)' : 
                      'Concise (800-1000 words)';

  // Multi-phase approach
  if (data.usePhaseApproach) {
    return `
You are an elite affiliate marketing review writer specializing in creating premium, SEO-optimized product reviews that convert readers into buyers. Your reviews consistently outrank competitors in Google and drive high-converting affiliate traffic.

I need you to follow a comprehensive five-phase process to create an exceptional, market-leading review for "${data.productName}" using this exact template structure:

${reviewTemplateStructure}

IMPORTANT: For each phase of the process, I want you to:
1. Begin with a clear heading for the phase (e.g., "PHASE 1: LINK ANALYSIS & DEEP RESEARCH")
2. Explain your objective and methodology for that phase in detail
3. Show your detailed work by describing exactly what you're doing step by step
4. Present all findings, analysis, and insights you discover during this phase
5. Do NOT condense or summarize your work - show the complete thinking process
6. When you reach PHASE 5 (final HTML review creation), still show the full planning process before creating the HTML

In the final HTML output, maintain structure with proper headings (H1, H2, H3), but make sure to show all your detailed analysis BEFORE creating the final HTML review. I want to see your complete thought process from beginning to end.

PHASE 1: LINK ANALYSIS & DEEP RESEARCH
Begin by thoroughly analyzing these links and extracting every relevant detail:
${data.offerLink ? `- Offer Link: ${data.offerLink}` : ''}
${data.jvDoc ? `- JV Doc: ${data.jvDoc}` : ''}
${data.affiliateLink ? `- Affiliate Link: ${data.affiliateLink}` : ''}

Based on these links, identify and clearly display your findings for:
1. The product's complete name, creator background, and market positioning
2. The specific niche, market segment, and exact audience pain points addressed
3. Comprehensive list of benefits, features, and unique selling propositions (USPs)
4. Complete pricing structure (front-end offer, OTOs, upsells, downsells, recurring options)
5. Advanced sales techniques and psychological triggers employed on the sales page
6. All special promotions, limited-time offers, guarantees, and risk-reversals
7. Technical specifications, access methods, and delivery mechanisms

PHASE 2: COMPETITIVE LANDSCAPE ANALYSIS
Conduct and clearly display your findings for a thorough market analysis covering:
- Leading competing products in the same category/niche
- Pricing positioning relative to market alternatives
- Feature comparison against top competitors
- Unique advantages and potential disadvantages compared to alternatives
- Market gaps the product addresses that competitors miss
- Specific audience segments where this product excels beyond competitors
- Value proposition analysis in the broader market context

PHASE 3: IN-DEPTH OFFER ANALYSIS & BUYER PSYCHOLOGY
Create and display a detailed breakdown of the product covering:
- Product Creator's Authority Profile & Credibility Factors
- Core Problem-Solution Framework (exact pain points addressed)
- Target Audience Psychographic Profile (beyond demographics: beliefs, values, fears, and aspirations)
- Advanced Persuasion Elements (evidence-based authority, consensus tactics, commitment/consistency appeals, reciprocity triggers)
- Ultimate Transformation Promised (the "after state" for customers)
- Complete Value Stack Analysis (direct & indirect benefits, immediate & long-term advantages)
- Potential Objections Map & Pre-emptive Objection Handling
- Risk Assessment & Uncertainty Reduction Mechanisms
- Customer Success Requirements & Implementation Roadblocks

PHASE 4: STRATEGIC CONTENT ARCHITECTURE
Design and display a sophisticated, conversion-optimized content structure:
- SEO-optimized heading hierarchy with strategic keyword placement
- User experience flow mapping from problem awareness to purchase decision
- Strategic placement of trust elements and credibility markers
- Intentional emotional journey across the content (problem intensity → solution relief)
- Deliberate objection-handling progression throughout the review
- Value demonstration with strategic proof elements (case studies, demonstrations, examples)
- Multi-stage call-to-action sequence with proper psychological priming
- Content segmentation for different buyer awareness levels (problem aware, solution aware, product aware)

PHASE 5: PREMIUM REVIEW CREATION
Based on the comprehensive analysis from Phases 1-4, write an authoritative, expert-level HTML product review with these specifications.
First, summarize the key insights from all previous phases that will inform the review creation:

REVIEW SPECIFICATIONS:
- Length: ${lengthSetting}
- Tone: ${data.toneStyle}
- Target Keywords: ${data.targetKeyword || `${data.productName} review, ${data.productName} reviews, ${data.productName} review 2025`}
- Structure: Professional review format with clear sections

REQUIRED ELEMENTS:
${data.includePricingTable ? '- Include a visually appealing pricing table with front-end and upsell options' : ''}
${data.includeProsConsSection ? '- Include a clearly formatted pros and cons section with balanced analysis' : ''}
${data.includeCtaBanner ? `- Include multiple prominent call-to-action banners with link to ${data.bundleLink || data.affiliateLink || 'the product'}` : ''}
${data.includeFaqSection ? '- Include a comprehensive FAQ section addressing 8-10 common questions' : ''}
${data.includeProductImages ? '- Include placeholders for product screenshots with detailed alt texts' : ''}
${data.includeTableOfContents ? '- Add a clickable table of contents at the beginning' : ''}

${seoSection}

${data.includeComparisonTable || data.includeTestimonials || data.includeProductRating || data.includeBonusSection ? advancedFeaturesSection : ''}

${copywritingSection}

${themeSection}

OUTPUT FORMAT:
1. Produce clean, semantic HTML with proper heading structure (H1, H2, H3)
2. Include schema markup for reviews to enhance SEO
3. Structure the content for maximum readability and engagement
4. Create balanced content that highlights both strengths and limitations
5. Design the review to achieve high rankings for "${data.targetKeyword || `${data.productName} review`}"
6. Use engaging subheadings throughout to maintain reader interest

The final HTML should be publication-ready, optimized for both readers and search engines.
`;
  } else {
    // Standard approach without phases
    return `
You are an expert affiliate marketing copywriter specializing in creating premium-quality, conversion-optimized product reviews. Your reviews consistently rank at the top of Google search results and drive high-converting traffic.

Please create a comprehensive, professional product review for "${data.productName}" using this exact template structure:

${reviewTemplateStructure}

REVIEW SPECIFICATIONS:

PRODUCT DETAILS:
- Product Name: ${data.productName}
${data.productDescription ? `- Product Description: ${data.productDescription}` : ''}
${data.offerLink ? `- JVZoo Offer Link: ${data.offerLink}` : ''}
${data.affiliateLink ? `- Affiliate Link to use: ${data.affiliateLink}` : ''}
${data.bundleLink ? `- Bundle/Premium Offer Link: ${data.bundleLink}` : ''}

REVIEW APPROACH:
1. Research the product thoroughly and analyze its core features
2. Identify the primary target audience and their pain points
3. Evaluate the product's unique selling propositions and value
4. Compare with alternatives available in the market
5. Provide detailed sections on implementation, use cases, and outcomes
6. Balance promotional aspects with genuine critical analysis 
7. Structure content for maximum reader engagement and SEO performance

REVIEW STYLE:
- Length: ${lengthSetting}
- Tone: ${data.toneStyle}
- Purpose: To provide valuable insights while naturally encouraging conversions
- Approach: Educational yet persuasive, building authority and trust

REQUIRED ELEMENTS:
${data.includePricingTable ? '- Include a comprehensive pricing table with front-end offers, OTOs, and value analysis for each tier' : ''}
${data.includeProsConsSection ? '- Include an in-depth pros and cons analysis with meaningful insights beyond surface-level observations' : ''}
${data.includeCtaBanner ? `- Include multiple strategic call-to-action sections with motivating copy linking to ${data.bundleLink || data.affiliateLink || 'the product'}` : ''}
${data.includeFaqSection ? '- Include an extensive FAQ section addressing specific user concerns, implementation questions, and common objections' : ''}
${data.includeProductImages ? '- Include placeholders for strategic product screenshots with detailed alt text optimized for image SEO' : ''}

${seoSection}

${data.includeComparisonTable || data.includeTestimonials || data.includeProductRating || data.includeBonusSection ? advancedFeaturesSection : ''}

${copywritingSection}

${themeSection}

ADVANCED WRITING GUIDELINES:
1. Create an emotionally engaging introduction that hooks the reader immediately
2. Develop a logical flow that guides readers from problem awareness to solution discovery
3. Include specific, tangible examples and use cases that demonstrate practical value
4. Incorporate storytelling elements that help readers envision success with the product
5. Use strategic subheadings that both engage readers and optimize for SEO
6. Balance technical details with clear explanations accessible to all reader knowledge levels
7. Utilize persuasive techniques like future pacing, authority positioning, and social proof
8. Pre-emptively address common objections throughout the review
9. Create a compelling conclusion that summarizes value and naturally leads to action

TECHNICAL REQUIREMENTS:
1. Structure the review with clean, semantic HTML markup optimized for search engines
2. Implement proper heading hierarchy (H1, H2, H3) with keyword-rich titles
3. Create scannable content with bulleted lists, short paragraphs, and highlighted key points
4. Include properly formatted tables and comparison elements where appropriate
5. Optimize all HTML elements for both desktop and mobile reading experiences
6. ${data.includeSeoSchema ? 'Implement complete JSON-LD schema markup for reviews with proper rating structure and rich snippet optimization' : 'Include basic schema markup for reviews to improve search visibility'}
7. Structure content for featured snippet potential where possible

The HTML should be publication-ready, visually appealing, and optimized for both reader engagement and search engine performance. Create content that genuinely helps readers while naturally encouraging affiliate conversions.
`;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session
  const MemoryStore = memoryStoreModule(session);
  app.use(session({
    secret: 'reviewpro-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: process.env.NODE_ENV === 'production',
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    },
    store: new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    })
  }));
  
  // Authentication middleware to check if user is logged in
  const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
    if (req.session && req.session.userId) {
      next();
    } else {
      res.status(401).json({ success: false, message: 'Unauthorized. Please log in.' });
    }
  };
  
  // Authentication routes
  
  // Register new user
  app.post('/api/auth/register', async (req, res) => {
    try {
      // Validate request data
      const validatedData = registerUserSchema.parse(req.body);
      
      // Create user with Firebase
      const firebaseResult = await firebaseAdmin.createUser(
        validatedData.email,
        validatedData.password,
        validatedData.username
      );
      
      if (!firebaseResult.success) {
        return res.status(400).json({ 
          success: false, 
          message: firebaseResult.error || 'Failed to create user account'
        });
      }
      
      // Make sure we have a Firebase user object with UID
      if (!firebaseResult.user || !firebaseResult.user.uid) {
        return res.status(500).json({
          success: false,
          message: 'Failed to create Firebase user account properly'
        });
      }
      
      // Now we know user is defined and has uid
      const firebaseUid = firebaseResult.user.uid;
      
      // Create user data with 3-day trial
      const trialEndsAt = new Date();
      trialEndsAt.setDate(trialEndsAt.getDate() + 3); // 3-day trial
      
      // Create the user in our database with the Firebase UID
      const user = await storage.createUser({
        username: validatedData.username,
        email: validatedData.email,
        password: crypto.randomBytes(16).toString('hex'), // Use random password since auth happens via Firebase
        firebaseUid: firebaseUid
      });
      
      // Get the Free Trial plan
      const subscriptionPlans = await storage.getSubscriptionPlans();
      const freeTrial = subscriptionPlans.find(plan => plan.name === 'Free Trial');
      
      // Set trial info and subscription plan ID
      const subscriptionData: any = {
        trialEndsAt: trialEndsAt,
        subscriptionStatus: 'trial',
        subscriptionPlanId: freeTrial?.id ?? null
      };
      
      // If plan ID is explicitly provided, override with that plan
      if (validatedData.subscriptionPlanId) {
        subscriptionData.subscriptionPlanId = validatedData.subscriptionPlanId;
      }
      
      // Update the user with subscription and trial data
      await storage.updateUserSubscription(user.id, subscriptionData);
      
      // Set user session
      req.session.userId = user.id;
      req.session.username = user.username;
      req.session.firebaseUid = firebaseUid;
      
      // Return success without password
      const { password, ...userWithoutPassword } = user;
      return res.status(201).json({ 
        success: true, 
        message: 'Registration successful!',
        user: userWithoutPassword
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: 'Validation error', 
          errors: formatZodError(error)
        });
      }
      
      console.error('Registration error:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'An error occurred during registration'
      });
    }
  });
  
  // Login user (using Firebase)
  app.post('/api/auth/login', async (req, res) => {
    try {
      // Validate request data
      const validatedData = loginUserSchema.parse(req.body);
      
      // Get email from request to lookup in our database
      const { usernameOrEmail, password } = validatedData;
      
      // Check if user exists in firebase mock
      console.log('Attempting login with:', usernameOrEmail);
      
      // Authenticate using our storage adapter
      let userRecord = await storage.authenticateUser(usernameOrEmail, password);
      
      // If user is not found but they are authenticating through Firebase,
      // automatically create the user in our storage
      if (!userRecord) {
        // This is a special case for Firebase users who are logging in for the first time
        console.log('User not found in local storage. Creating user from Firebase auth');
        
        // Generate a username from the email if it's an email
        const isEmail = usernameOrEmail.includes('@');
        const username = isEmail ? usernameOrEmail.split('@')[0] : usernameOrEmail;
        
        // Create a unique Firebase UID
        const firebaseUid = `firebase-${Math.random().toString(36).substring(2, 15)}`;
        
        // Create the user in our storage
        userRecord = await storage.createUser({
          username: username,
          email: isEmail ? usernameOrEmail : `${usernameOrEmail}@example.com`,
          password: password, // This will be hashed by the storage implementation
          firebaseUid: firebaseUid
        });
        
        console.log('Created new user:', userRecord.id);
      }
      
      if (!userRecord) {
        return res.status(404).json({
          success: false,
          message: 'User not found. Please check your credentials or register a new account.'
        });
      }
      
      // Set user session
      req.session.userId = userRecord.id;
      req.session.username = userRecord.username;
      if (userRecord.firebaseUid) {
        req.session.firebaseUid = userRecord.firebaseUid;
      }
      
      // Return success without password
      const { password: storedPassword, ...userWithoutPassword } = userRecord;
      return res.status(200).json({ 
        success: true, 
        message: 'Login successful!',
        user: userWithoutPassword
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: 'Validation error', 
          errors: formatZodError(error)
        });
      }
      
      console.error('Login error:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'An error occurred during login' 
      });
    }
  });
  
  // Logout user (client also needs to call Firebase signOut)
  app.post('/api/auth/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error('Logout error:', err);
        return res.status(500).json({ 
          success: false, 
          message: 'An error occurred during logout' 
        });
      }
      
      // Clear server-side session cookie
      res.clearCookie('connect.sid');
      
      // Note: Firebase logout must be handled on the client side
      return res.status(200).json({ 
        success: true, 
        message: 'Logout successful' 
      });
    });
  });
  
  // Forgot password - request password reset
  app.post('/api/auth/forgot-password', async (req, res) => {
    try {
      // Validate request data
      const validatedData = forgotPasswordSchema.parse(req.body);
      const { email } = validatedData;
      
      // Check if the email exists in the database (without revealing if it exists)
      let userExists = false;
      try {
        const result = await db.select().from(users).where(eq(users.email, email));
        userExists = result.length > 0;
      } catch (dbError) {
        console.error('Error checking email existence:', dbError);
      }
      
      // Log the result but don't expose it in the response
      if (userExists) {
        console.log(`Password reset requested for existing user with email: ${email}`);
        
        // In a real implementation, we would:
        // 1. Generate a secure random token
        // 2. Store the token with an expiration time
        // 3. Send an email with a reset link
      } else {
        console.log(`Password reset requested for non-existent email: ${email}`);
      }
      
      // Always return the same response regardless of whether the email exists
      // This prevents email enumeration attacks
      return res.status(200).json({
        success: true,
        message: 'If an account with that email exists, a password reset link will be sent.'
      });
    } catch (error) {
      console.error('Forgot password error:', error);
      
      if (error instanceof ZodError) {
        // Return validation error messages
        return res.status(400).json({
          success: false,
          message: 'Validation error',
          errors: formatZodError(error)
        });
      }
      
      return res.status(500).json({
        success: false,
        message: 'An error occurred processing your request'
      });
    }
  });
  
  // Get current user (basic info)
  app.get('/api/auth/me', (req, res) => {
    if (req.session && req.session.userId) {
      return res.status(200).json({ 
        success: true, 
        user: {
          id: req.session.userId,
          username: req.session.username
        }
      });
    } else {
      return res.status(401).json({ 
        success: false, 
        message: 'Not authenticated' 
      });
    }
  });
  
  // Get user profile (detailed info with subscription and trial data)
  app.get('/api/user/profile', isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId as number;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ 
          success: false, 
          message: 'User not found' 
        });
      }
      
      // Get subscription plan details if a plan ID is set
      let subscriptionPlan = null;
      if (user.subscriptionPlanId) {
        subscriptionPlan = await storage.getSubscriptionPlan(user.subscriptionPlanId);
      }
      
      // Omit password when returning user data
      const { password, ...userWithoutPassword } = user;
      
      return res.status(200).json({
        success: true,
        user: {
          ...userWithoutPassword,
          subscriptionPlan: subscriptionPlan
        }
      });
    } catch (error) {
      console.error('Error fetching user profile:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'Failed to fetch user profile' 
      });
    }
  });
  
  // Route to ping and verify the API key
  app.post('/api/verify-api-key', async (req, res) => {
    try {
      const { apiKey, model } = req.body;
      
      if (!apiKey) {
        return res.status(400).json({ success: false, message: 'API key is required' });
      }

      // Validate the model
      const validModels = ['gemini-2.5-pro-exp', 'gemini-2.0-flash', 'gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-1.0-pro'];
      const selectedModel = validModels.includes(model) ? model : 'gemini-2.5-pro-exp';

      try {
        // Make a simple call to verify the API key works with minimal token usage
        const testPrompt = "Respond with 'API key is valid' if you receive this message.";
        await callGoogleAIStudio(apiKey, selectedModel, testPrompt);
        
        return res.status(200).json({ 
          success: true, 
          message: 'API key verified successfully! You can now generate reviews.'
        });
      } catch (apiError) {
        console.error('API key verification failed:', apiError);
        
        // Enhanced error messages for common API issues
        let errorMessage = 'Unable to verify API key';
        
        if (apiError instanceof Error) {
          const errMsg = apiError.message;
          
          if (errMsg.includes('401') || errMsg.includes('403') || errMsg.includes('Authentication') || errMsg.includes('auth')) {
            errorMessage = 'Invalid API key. Please make sure you\'ve copied the correct key from Google AI Studio.';
          } else if (errMsg.includes('429') || errMsg.includes('Rate limit') || errMsg.includes('quota')) {
            errorMessage = 'Rate limit exceeded. Your API key may have reached its quota limit.';
          } else if (errMsg.includes('404') || errMsg.includes('not found')) {
            errorMessage = 'The selected AI model is not available. Try using a different model.';
          } else if (errMsg.includes('timeout')) {
            errorMessage = 'The request timed out. This may indicate heavy API traffic.';
          } else {
            errorMessage = `API error: ${errMsg}`;
          }
        }
        
        return res.status(400).json({ 
          success: false, 
          message: errorMessage
        });
      }
    } catch (error) {
      console.error('API key verification error:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'Server error while verifying API key. Please try again.',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Review Configuration Routes
  
  // Get all review configurations for current user
  app.get('/api/review-configs', isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId as number;
      const configs = await storage.getReviewConfigs(userId);
      
      res.json({
        success: true,
        data: configs
      });
    } catch (error) {
      console.error('Error fetching review configs:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve review configurations',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Get a specific review configuration
  app.get('/api/review-configs/:id', isAuthenticated, async (req, res) => {
    try {
      const configId = parseInt(req.params.id);
      const userId = req.session.userId as number;
      
      if (isNaN(configId)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid review configuration ID'
        });
      }
      
      const config = await storage.getReviewConfig(configId);
      
      if (!config) {
        return res.status(404).json({
          success: false,
          message: 'Review configuration not found'
        });
      }
      
      // Verify ownership
      if (config.userId !== userId) {
        return res.status(403).json({
          success: false,
          message: 'You do not have permission to access this configuration'
        });
      }
      
      res.json({
        success: true,
        data: config
      });
    } catch (error) {
      console.error('Error fetching review config:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve review configuration',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Create a new review configuration
  app.post('/api/review-configs', isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId as number;
      
      // Use the insert schema to validate data
      const configData = req.body;
      
      // Create the configuration
      const newConfig = await storage.createReviewConfig(configData, userId);
      
      res.status(201).json({
        success: true,
        message: 'Review configuration created successfully',
        data: newConfig
      });
    } catch (error) {
      console.error('Error creating review config:', error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({
          success: false,
          message: 'Invalid configuration data',
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: 'Failed to create review configuration',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Update a review configuration
  app.put('/api/review-configs/:id', isAuthenticated, async (req, res) => {
    try {
      const configId = parseInt(req.params.id);
      const userId = req.session.userId as number;
      
      if (isNaN(configId)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid review configuration ID'
        });
      }
      
      // First check if the config exists and belongs to this user
      const existingConfig = await storage.getReviewConfig(configId);
      
      if (!existingConfig) {
        return res.status(404).json({
          success: false,
          message: 'Review configuration not found'
        });
      }
      
      // Verify ownership
      if (existingConfig.userId !== userId) {
        return res.status(403).json({
          success: false,
          message: 'You do not have permission to update this configuration'
        });
      }
      
      // Update the configuration
      const updatedConfig = await storage.updateReviewConfig(configId, req.body);
      
      if (!updatedConfig) {
        return res.status(500).json({
          success: false,
          message: 'Failed to update review configuration'
        });
      }
      
      res.json({
        success: true,
        message: 'Review configuration updated successfully',
        data: updatedConfig
      });
    } catch (error) {
      console.error('Error updating review config:', error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({
          success: false,
          message: 'Invalid configuration data',
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: 'Failed to update review configuration',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Delete a review configuration
  app.delete('/api/review-configs/:id', isAuthenticated, async (req, res) => {
    try {
      const configId = parseInt(req.params.id);
      const userId = req.session.userId as number;
      
      if (isNaN(configId)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid review configuration ID'
        });
      }
      
      // First check if the config exists and belongs to this user
      const existingConfig = await storage.getReviewConfig(configId);
      
      if (!existingConfig) {
        return res.status(404).json({
          success: false,
          message: 'Review configuration not found'
        });
      }
      
      // Verify ownership
      if (existingConfig.userId !== userId) {
        return res.status(403).json({
          success: false,
          message: 'You do not have permission to delete this configuration'
        });
      }
      
      // Delete the configuration
      const success = await storage.deleteReviewConfig(configId);
      
      if (!success) {
        return res.status(500).json({
          success: false,
          message: 'Failed to delete review configuration'
        });
      }
      
      res.json({
        success: true,
        message: 'Review configuration deleted successfully'
      });
    } catch (error) {
      console.error('Error deleting review config:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to delete review configuration',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Route to generate a review
  app.post('/api/generate-review', async (req, res) => {
    try {
      // Validate request body
      const data = generateReviewSchema.parse(req.body);
      
      // Check for required fields
      if (!data.productName) {
        return res.status(400).json({
          success: false,
          message: 'Product name is required to generate a review'
        });
      }
      
      // Generate prompt for the AI
      const prompt = generatePrompt(data);
      
      // Log the start of the generation
      console.log(`Starting review generation for ${data.productName} using model ${data.model || 'default'}`);
      
      // Call Google AI Studio API
      let reviewContent: string;
      try {
        reviewContent = await callGoogleAIStudio(data.apiKey, data.model, prompt);
        
        // Verify the content is not empty and contains proper HTML
        if (!reviewContent || reviewContent.length < 50) {
          throw new Error('Generated review content is too short or empty');
        }
        
        // Verify that it contains at least a basic HTML structure
        if (!reviewContent.includes('<h1') && !reviewContent.includes('<h2') && !reviewContent.includes('<p>')) {
          throw new Error('Generated content does not appear to contain proper HTML structure');
        }
        
        // Extract the final review content if using phased approach
        if (data.usePhaseApproach && (reviewContent.includes('PHASE 1:') || reviewContent.includes('PHASE 1'))) {
          console.log("Detected phased content - extracting final review HTML");
          
          // Find PHASE 5 which contains the final output
          const phase5Regex = /(?:PHASE 5:?|Phase 5:?).*?(?:PREMIUM REVIEW CREATION|Final Review Creation|HTML Review)/i;
          const phase5Match = reviewContent.match(phase5Regex);
          
          if (phase5Match && phase5Match.index) {
            // Get content after Phase 5 heading
            const contentAfterPhase5 = reviewContent.substring(phase5Match.index);
            
            // Find the actual HTML content that follows phase 5 introduction
            // Look for first HTML tag after some explanation text
            const htmlStartRegex = /<(?:h1|div|article|main|section)[^>]*>/i;
            const htmlMatch = contentAfterPhase5.match(htmlStartRegex);
            
            if (htmlMatch && htmlMatch.index) {
              // Start from the first major HTML tag after Phase 5
              reviewContent = contentAfterPhase5.substring(htmlMatch.index);
              console.log("Successfully extracted Phase 5 content");
            }
          }
        }
        
        // Clean up any remaining phase markers or analysis text
        reviewContent = reviewContent.replace(/PHASE \d+:[\s\S]*?(?=<h1|<div|<article|<section)/gi, '');
        reviewContent = reviewContent.replace(/Phase \d+:[\s\S]*?(?=<h1|<div|<article|<section)/gi, '');
        
        // Add critical CSS styles
        const criticalStyles = `
        <style>
          /* Enhanced professional review styles */
          /* Base typography */
          .prose { 
            font-family: system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; 
            line-height: 1.7; 
            color: #374151; 
            max-width: 100%;
            font-size: 16px;
          }
          
          /* Heading hierarchy with improved visual distinction */
          .prose h1, .prose h2, .prose h3, .prose h4 { 
            font-weight: 700; 
            margin-top: 1.8em; 
            margin-bottom: 0.8em; 
            line-height: 1.3;
          }
          
          .prose h1 { 
            font-size: 2.5em; 
            color: #1e3a8a; 
            margin-bottom: 0.8em;
            position: relative;
            padding-bottom: 0.5em;
          }
          
          .prose h1::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            height: 4px;
            width: 80px;
            background: linear-gradient(90deg, #2563eb, #60a5fa);
            border-radius: 2px;
          }
          
          .prose h2 { 
            font-size: 1.85em; 
            color: #1e40af; 
            padding-bottom: 0.3em; 
            border-bottom: 1px solid #e5e7eb; 
            margin-top: 1.8em;
          }
          
          .prose h3 { 
            font-size: 1.5em; 
            color: #2563eb; 
            margin-top: 1.5em;
          }
          
          .prose h4 { 
            font-size: 1.25em; 
            color: #3b82f6; 
          }
          
          /* Content elements with enhanced readability */
          .prose p { 
            margin-top: 1.25em; 
            margin-bottom: 1.25em;
            line-height: 1.8;
          }
          
          .prose ul, .prose ol { 
            margin-top: 1.25em; 
            margin-bottom: 1.25em; 
            padding-left: 1.5em;
          }
          
          .prose li {
            margin-bottom: 0.75em;
            position: relative;
          }
          
          .prose ul > li::before {
            content: "";
            position: absolute;
            left: -1.25em;
            top: 0.75em;
            height: 0.375em;
            width: 0.375em;
            background-color: #3b82f6;
            border-radius: 50%;
          }
          
          /* Enhanced image styling */
          .prose img { 
            max-width: 100%; 
            height: auto; 
            border-radius: 0.5rem; 
            margin: 2rem auto; 
            display: block;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            border: 1px solid #f3f4f6;
          }
          
          /* Better link styling */
          .prose a { 
            color: #2563eb; 
            text-decoration: none; 
            font-weight: 500;
            transition: all 0.2s ease;
            border-bottom: 1px dotted #93c5fd;
          }
          
          .prose a:hover { 
            color: #1e40af;
            border-bottom-color: #2563eb; 
          }
          
          /* Premium pricing table */
          .price-table { 
            width: 100%; 
            border-collapse: separate; 
            border-spacing: 0;
            border-radius: 0.75rem; 
            overflow: hidden; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.08); 
            margin: 2.5rem 0; 
            background: #ffffff;
            border: 1px solid #e5e7eb;
          }
          
          .price-table th { 
            background: linear-gradient(90deg, #2563eb, #3b82f6); 
            color: white; 
            padding: 1.25rem 1rem; 
            text-align: left;
            font-weight: 600;
            font-size: 1.1em;
          }
          
          .price-table th:first-child {
            border-top-left-radius: 0.5rem;
          }
          
          .price-table th:last-child {
            border-top-right-radius: 0.5rem;
          }
          
          .price-table td { 
            padding: 1.25rem 1rem; 
            border-bottom: 1px solid #e5e7eb;
            transition: background 0.2s ease;
          }
          
          .price-table tr:last-child td {
            border-bottom: none;
          }
          
          .price-table tr:hover td {
            background-color: #f8fafc;
          }
          
          .price-table tr:nth-child(odd) { 
            background-color: #f9fafb; 
          }
          
          .price-table .recommended {
            position: relative;
          }
          
          .price-table .recommended::after {
            content: "RECOMMENDED";
            position: absolute;
            top: 0;
            right: 0;
            background: #16a34a;
            color: white;
            font-size: 0.75rem;
            padding: 0.25rem 0.75rem;
            transform: translate(0, -50%);
            border-radius: 9999px;
            font-weight: 600;
            letter-spacing: 0.05em;
          }
          
          /* Enhanced CTA buttons */
          .cta-button { 
            display: inline-block; 
            background: linear-gradient(135deg, #f59e0b, #d97706); 
            color: white !important; 
            font-weight: 700; 
            padding: 1rem 2.5rem; 
            border-radius: 9999px; 
            text-decoration: none !important; 
            transition: all 0.3s;
            font-size: 1.125rem;
            border: none !important;
            box-shadow: 0 4px 10px rgba(217, 119, 6, 0.3);
            text-align: center;
            cursor: pointer;
            letter-spacing: 0.01em;
            position: relative;
          }
          
          .cta-button:hover { 
            transform: translateY(-3px); 
            box-shadow: 0 8px 15px rgba(217, 119, 6, 0.4);
            background: linear-gradient(135deg, #ea580c, #c2410c);
          }
          
          .cta-button::after {
            content: "→";
            margin-left: 0.5rem;
            font-weight: 800;
            display: inline-block;
            transition: transform 0.2s ease;
          }
          
          .cta-button:hover::after {
            transform: translateX(4px);
          }
          
          .cta-container {
            background: linear-gradient(to bottom, rgba(243,244,246,0.8), rgba(249,250,251,0.95));
            padding: 2.5rem 2rem;
            border-radius: 0.75rem;
            margin: 3rem 0;
            position: relative;
            border: 2px solid #e5e7eb;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);
            text-align: center;
          }
          
          .cta-container::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: linear-gradient(90deg, #3b82f6, #60a5fa);
            border-top-left-radius: 0.75rem;
            border-top-right-radius: 0.75rem;
          }
          
          .cta-headline {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1e40af;
            margin-bottom: 1rem;
          }
          
          .cta-description {
            color: #4b5563;
            margin-bottom: 1.5rem;
            font-size: 1.05rem;
          }
          
          /* Premium pros and cons layout */
          .pros-cons { 
            display: grid; 
            grid-template-columns: 1fr; 
            gap: 2rem; 
            margin: 2.5rem 0;
          }
          
          @media (min-width: 768px) { 
            .pros-cons { 
              grid-template-columns: 1fr 1fr; 
            } 
          }
          
          .pros { 
            background-color: #f0fdf4; 
            border: 1px solid #dcfce7; 
            border-radius: 0.75rem; 
            padding: 1.75rem; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.03);
            position: relative;
            overflow: hidden;
          }
          
          .pros::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #16a34a, #22c55e);
          }
          
          .cons { 
            background-color: #fef2f2; 
            border: 1px solid #fee2e2; 
            border-radius: 0.75rem; 
            padding: 1.75rem; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.03);
            position: relative;
            overflow: hidden;
          }
          
          .cons::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #dc2626, #ef4444);
          }
          
          .pros h3, .pros h4 { 
            color: #15803d; 
            font-weight: 700; 
            margin-top: 0; 
            display: flex; 
            align-items: center;
            font-size: 1.35rem;
          }
          
          .cons h3, .cons h4 { 
            color: #dc2626; 
            font-weight: 700; 
            margin-top: 0; 
            display: flex; 
            align-items: center;
            font-size: 1.35rem;
          }
          
          .pros h3::before, .pros h4::before { 
            content: "✓"; 
            margin-right: 0.75rem; 
            font-weight: bold; 
            font-size: 1.25rem;
            color: #16a34a;
          }
          
          .cons h3::before, .cons h4::before { 
            content: "✗"; 
            margin-right: 0.75rem; 
            font-weight: bold; 
            font-size: 1.25rem;
            color: #ef4444;
          }
          
          .pros ul, .cons ul {
            padding-left: 1.25rem;
            margin-top: 1rem;
          }
          
          .pros li, .cons li {
            margin-bottom: 0.75rem;
            padding-left: 1.5rem;
            position: relative;
          }
          
          .pros li::before {
            content: "+";
            position: absolute;
            left: 0;
            color: #16a34a;
            font-weight: 700;
          }
          
          .cons li::before {
            content: "-";
            position: absolute;
            left: 0;
            color: #ef4444;
            font-weight: 700;
          }
          
          /* Responsive table container */
          .table-responsive { 
            overflow-x: auto; 
            margin: 2rem 0;
            border-radius: 0.75rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
          }
          
          /* Product images */
          .product-image { 
            max-width: 100%; 
            height: auto; 
            border-radius: 0.75rem; 
            margin: 2rem auto; 
            display: block;
            box-shadow: 0 8px 20px rgba(0,0,0,0.08);
            border: 1px solid #f3f4f6;
          }
          
          /* Feature box and benefit styles */
          .feature-box {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 0.75rem;
            padding: 1.75rem;
            margin: 1.5rem 0;
            box-shadow: 0 4px 10px rgba(0,0,0,0.03);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
          }
          
          .feature-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
          }
          
          .feature-title {
            font-size: 1.35rem;
            font-weight: 700;
            color: #1e40af;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
          }
          
          .feature-title::before {
            content: "•";
            color: #3b82f6;
            margin-right: 0.75rem;
            font-size: 1.5rem;
          }
          
          /* Rating display */
          .rating-box {
            background: linear-gradient(to bottom, #f9fafb, #f3f4f6);
            border: 1px solid #e5e7eb;
            border-radius: 0.75rem;
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 2rem auto;
            max-width: 300px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.03);
          }
          
          .rating-score {
            font-size: 3rem;
            font-weight: 700;
            color: #1e40af;
            margin: 0.5rem 0;
          }
          
          .rating-stars {
            color: #f59e0b;
            font-size: 1.5rem;
            letter-spacing: 0.1em;
            margin: 0.5rem 0;
          }
          
          .rating-label {
            font-weight: 600;
            color: #4b5563;
            margin-top: 0.5rem;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
          }
          
          /* Testimonial card styles */
          .testimonial-card {
            background-color: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 0.75rem;
            padding: 1.75rem;
            margin: 2rem 0;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            position: relative;
          }
          
          .testimonial-card::before {
            content: """;
            position: absolute;
            top: 0;
            left: 1.25rem;
            font-size: 5rem;
            color: #e5e7eb;
            font-family: Georgia, serif;
            line-height: 1;
            transform: translateY(-50%);
          }
          
          .testimonial-content {
            font-style: italic;
            color: #4b5563;
            line-height: 1.8;
            margin-bottom: 1.25rem;
          }
          
          .testimonial-author {
            display: flex;
            align-items: center;
            margin-top: 1.5rem;
          }
          
          .testimonial-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 1rem;
            background-color: #f3f4f6;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #9ca3af;
            font-weight: 700;
            font-size: 1.25rem;
          }
          
          .testimonial-info {
            display: flex;
            flex-direction: column;
          }
          
          .testimonial-name {
            font-weight: 700;
            color: #1f2937;
          }
          
          .testimonial-role {
            font-size: 0.875rem;
            color: #6b7280;
          }
          
          /* Table of contents styling */
          .table-of-contents {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 0.75rem;
            padding: 1.5rem 2rem;
            margin: 2rem 0;
            box-shadow: 0 4px 10px rgba(0,0,0,0.03);
          }
          
          .table-of-contents h3 {
            margin-top: 0;
            font-size: 1.35rem;
            color: #1e40af;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 0.75rem;
            margin-bottom: 1rem;
          }
          
          .table-of-contents ul {
            list-style: none;
            padding-left: 0;
            margin-bottom: 0;
          }
          
          .table-of-contents li {
            margin: 0.75rem 0;
            padding-left: 1.5rem;
            position: relative;
          }
          
          .table-of-contents li::before {
            content: "";
            position: absolute;
            left: 0;
            top: 0.55rem;
            width: 0.35rem;
            height: 0.35rem;
            border-radius: 50%;
            background: #3b82f6;
          }
          
          .table-of-contents a {
            color: #2563eb;
            text-decoration: none;
            transition: all 0.2s ease;
            border-bottom: none;
          }
          
          .table-of-contents a:hover {
            color: #1e40af;
            padding-left: 0.25rem;
          }
          
          /* FAQ section styling */
          .faq-item {
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            overflow: hidden;
          }
          
          .faq-question {
            padding: 1.25rem;
            background-color: #f9fafb;
            font-weight: 600;
            color: #1f2937;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
          }
          
          .faq-question::after {
            content: "+";
            font-size: 1.5rem;
            color: #6b7280;
          }
          
          .faq-answer {
            padding: 0 1.25rem 1.25rem;
            color: #4b5563;
          }
          
          /* Bonus section styling */
          .bonus-box {
            background: linear-gradient(to bottom, #fffbeb, #fef3c7);
            border: 1px solid #fde68a;
            border-radius: 0.75rem;
            padding: 1.75rem;
            margin: 2rem 0;
            position: relative;
            box-shadow: 0 4px 12px rgba(0,0,0,0.04);
          }
          
          .bonus-value {
            position: absolute;
            top: 0;
            right: 1.5rem;
            background: #d97706;
            color: white;
            font-weight: 700;
            font-size: 0.9rem;
            padding: 0.4rem 1rem;
            border-radius: 0 0 0.5rem 0.5rem;
            transform: translateY(-30%);
            box-shadow: 0 4px 6px rgba(217, 119, 6, 0.2);
          }
          
          .bonus-title {
            font-size: 1.35rem;
            font-weight: 700;
            color: #92400e;
            margin-bottom: 0.75rem;
            padding-right: 5rem;
          }
          
          /* Product comparison styles */
          .comparison-wrapper {
            margin: 2.5rem 0;
            border-radius: 0.75rem;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
          }
          
          .comparison-title {
            background: linear-gradient(90deg, #1e40af, #3b82f6);
            color: white;
            padding: 1.25rem;
            font-size: 1.25rem;
            font-weight: 600;
            text-align: center;
          }
          
          .comparison-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
          }
          
          .comparison-table th {
            background-color: #f1f5f9;
            padding: 1rem;
            font-weight: 600;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
          }
          
          .comparison-table td {
            padding: 1rem;
            border-bottom: 1px solid #e5e7eb;
          }
          
          .comparison-table tr:last-child td {
            border-bottom: none;
          }
          
          .comparison-check {
            color: #16a34a;
            font-weight: 700;
            font-size: 1.25rem;
          }
          
          .comparison-x {
            color: #dc2626;
            font-weight: 700;
            font-size: 1.25rem;
          }
          
          .comparison-highlight {
            background-color: #f0fdf4;
          }
          
          /* Misc utility styles */
          .text-center { text-align: center; }
          .font-bold { font-weight: 700; }
          .text-lg { font-size: 1.125rem; }
          .text-blue { color: #2563eb; }
          .text-green { color: #16a34a; }
          .text-red { color: #dc2626; }
          .mt-4 { margin-top: 1rem; }
          .mb-4 { margin-bottom: 1rem; }
          .my-8 { margin-top: 2rem; margin-bottom: 2rem; }
          .px-4 { padding-left: 1rem; padding-right: 1rem; }
          .py-2 { padding-top: 0.5rem; padding-bottom: 0.5rem; }
          .rounded { border-radius: 0.25rem; }
          .shadow { box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); }
          
          /* Key benefits display */
          .benefits-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
            margin: 2rem 0;
          }
          
          .benefit-card {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 0.75rem;
            padding: 1.5rem;
            box-shadow: 0 4px 10px rgba(0,0,0,0.03);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
          }
          
          .benefit-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 20px rgba(0,0,0,0.08);
          }
          
          .benefit-icon {
            background-color: #eff6ff;
            color: #3b82f6;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 1.25rem;
          }
          
          .benefit-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 0.75rem;
          }
          
          /* Mobile optimizations */
          @media (max-width: 640px) {
            .prose { font-size: 15px; }
            .prose h1 { font-size: 2em; }
            .prose h2 { font-size: 1.5em; }
            .prose h3 { font-size: 1.25em; }
            .cta-button { padding: 0.875rem 1.75rem; font-size: 1rem; }
            .rating-box { padding: 1.25rem; }
            .rating-score { font-size: 2.5rem; }
            .benefits-grid { grid-template-columns: 1fr; }
          }
        </style>
        `;
        
        // Add the critical CSS and proper wrapper
        if (!reviewContent.includes('<style>')) {
          reviewContent = criticalStyles + reviewContent;
        }
        
        // Add class to the main container if needed
        if (!reviewContent.includes('class="prose"')) {
          reviewContent = `<div class="prose">${reviewContent}</div>`;
        }
        
        // Enhance styling for pricing tables
        if (reviewContent.includes('<table')) {
          // Add a container for tables to ensure horizontal scrolling on mobile
          reviewContent = reviewContent.replace(
            /(<table[^>]*>(?:[\s\S]*?)<\/table>)/g,
            '<div class="table-responsive" style="overflow-x:auto; margin:1.5rem 0;">$1</div>'
          );
          
          // Add price-table class to tables if they don't already have a class
          reviewContent = reviewContent.replace(
            /<table(?![^>]*class=)/g, 
            '<table class="price-table" '
          );
        }
        
        // Enhance styling for pros and cons sections
        const prosHeadingPattern = /<h[3-4][^>]*>.*?\b(?:pros|advantages|benefits|positives)\b.*?<\/h[3-4]>/i;
        const consHeadingPattern = /<h[3-4][^>]*>.*?\b(?:cons|disadvantages|drawbacks|negatives)\b.*?<\/h[3-4]>/i;
        
        if (prosHeadingPattern.test(reviewContent) && consHeadingPattern.test(reviewContent)) {
          // Find the complete sections containing pros and cons
          const fullProsConsPattern = new RegExp(
            `(${prosHeadingPattern.source}[\\s\\S]*?)(${consHeadingPattern.source}[\\s\\S]*?(?:<h[2-3]|$))`,
            'i'
          );
          
          // Replace with properly styled containers
          reviewContent = reviewContent.replace(
            fullProsConsPattern,
            (match, prosSection, consSection) => {
              return `<div class="pros-cons" style="display:grid; grid-template-columns:1fr; gap:1.5rem; margin:2rem 0;">
                <div class="pros" style="background-color:#f0fdf4; border:1px solid #dcfce7; border-radius:0.5rem; padding:1.5rem; box-shadow:0 4px 6px rgba(0,0,0,0.05);">
                  ${prosSection}
                </div>
                <div class="cons" style="background-color:#fef2f2; border:1px solid #fee2e2; border-radius:0.5rem; padding:1.5rem; box-shadow:0 4px 6px rgba(0,0,0,0.05);">
                  ${consSection}
                </div>
              </div>`;
            }
          );
        }
        
        // Enhanced CTA buttons with premium styling and better conversion elements
        if (reviewContent.includes('<a')) {
          // Pattern for links that might be CTAs (based on common CTA text)
          const ctaPattern = /<a\s+(?:[^>]*?\s+)?href=["']([^"']*)["'][^>]*>(.*?(?:get|buy|try|check|discover|download|access|click|visit|view|learn|start).*?)<\/a>/gi;
          
          // Replace with styled CTA buttons with enhanced conversion elements
          reviewContent = reviewContent.replace(
            ctaPattern,
            (match, href, text) => {
              // Skip if already styled
              if (match.includes('class="cta-button"') || match.includes('class="cta-container"') || match.includes('style=')) {
                return match;
              }
              
              // Create an enhanced styled CTA button with premium conversion elements
              return `<div class="cta-container" style="background:linear-gradient(to bottom, rgba(243,244,246,0.8), rgba(249,250,251,0.95)); padding:2.5rem 2rem; border-radius:0.75rem; margin:3rem 0; position:relative; border:2px solid #e5e7eb; box-shadow:0 10px 25px -5px rgba(0,0,0,0.05); text-align:center;">
                <div style="position:absolute; top:0; left:0; right:0; height:6px; background:linear-gradient(90deg, #3b82f6, #60a5fa); border-top-left-radius:0.75rem; border-top-right-radius:0.75rem;"></div>
                <h3 class="cta-headline" style="font-size:1.5rem; font-weight:700; color:#1e40af; margin-bottom:1rem;">Ready to Experience the Power of ${data.productName}?</h3>
                <p class="cta-description" style="color:#4b5563; margin-bottom:1.5rem; font-size:1.05rem;">Join thousands of satisfied users who have already transformed their results with this premium solution.</p>
                <a href="${href}" class="cta-button" style="display:inline-block; background:linear-gradient(135deg, #f59e0b, #d97706); color:white !important; font-weight:700; padding:1rem 2.5rem; border-radius:9999px; text-decoration:none !important; transition:all 0.3s; font-size:1.125rem; border:none !important; box-shadow:0 4px 10px rgba(217,119,6,0.3); text-align:center; letter-spacing:0.01em;">
                  ${text} <span style="margin-left:0.5rem; font-weight:800; display:inline-block; transition:transform 0.2s ease;">→</span>
                </a>
                <div style="margin-top:1.25rem; font-size:0.875rem; color:#6b7280;">
                  <span style="display:inline-flex; align-items:center; margin-right:1rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16" style="margin-right:0.375rem;"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                    Secure Checkout
                  </span>
                  <span style="display:inline-flex; align-items:center;">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16" style="margin-right:0.375rem;"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                    Limited-Time Offer
                  </span>
                </div>
              </div>`;
            }
          );
          
          // Add a special final CTA at the end of the review if none exists yet
          if (!reviewContent.includes('class="cta-container"')) {
            const finalCallToAction = `
            <div class="cta-container" style="background:linear-gradient(to bottom, #eff6ff, #dbeafe); padding:3rem 2rem; border-radius:0.75rem; margin:4rem 0 2rem; position:relative; border:2px solid #bfdbfe; box-shadow:0 15px 30px -5px rgba(59,130,246,0.1); text-align:center;">
              <div style="position:absolute; top:0; left:0; right:0; height:6px; background:linear-gradient(90deg, #1e40af, #3b82f6); border-top-left-radius:0.75rem; border-top-right-radius:0.75rem;"></div>
              <h3 style="font-size:1.75rem; font-weight:800; color:#1e40af; margin-bottom:1.25rem;">Final Verdict: ${data.productName} Is Worth It</h3>
              <p style="color:#1f2937; margin-bottom:2rem; font-size:1.125rem; max-width:700px; margin-left:auto; margin-right:auto;">
                After thoroughly reviewing ${data.productName}, it's clear this is a powerful solution that delivers exceptional results for its target audience. Don't miss this opportunity to transform your results today.
              </p>
              <a href="${data.bundleLink || data.affiliateLink || '#'}" class="cta-button" style="display:inline-block; background:linear-gradient(135deg, #f59e0b, #d97706); color:white !important; font-weight:700; padding:1.25rem 3rem; border-radius:9999px; text-decoration:none !important; transition:all 0.3s; font-size:1.25rem; border:none !important; box-shadow:0 4px 15px rgba(217,119,6,0.3); text-align:center; letter-spacing:0.01em;">
                Get ${data.productName} Now <span style="margin-left:0.5rem; font-weight:800; display:inline-block; transition:transform 0.2s ease;">→</span>
              </a>
              <div style="margin-top:1.5rem; display:flex; justify-content:center; align-items:center; flex-wrap:wrap; gap:1.5rem;">
                <span style="display:inline-flex; align-items:center; font-size:0.9rem; color:#4b5563;">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18" style="margin-right:0.5rem; color:#16a34a;"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                  Secure Checkout
                </span>
                <span style="display:inline-flex; align-items:center; font-size:0.9rem; color:#4b5563;">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18" style="margin-right:0.5rem; color:#16a34a;"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                  Instant Access
                </span>
                <span style="display:inline-flex; align-items:center; font-size:0.9rem; color:#4b5563;">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18" style="margin-right:0.5rem; color:#16a34a;"><circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg>
                  30-Day Guarantee
                </span>
              </div>
            </div>`;
            
            // Add the final CTA before the last closing div or at the end
            const endDivPos = reviewContent.lastIndexOf('</div>');
            if (endDivPos !== -1) {
              reviewContent = reviewContent.substring(0, endDivPos) + finalCallToAction + reviewContent.substring(endDivPos);
            } else {
              reviewContent += finalCallToAction;
            }
          }
        }
        
        // Enhanced image styling with premium effects and proper presentation
        if (reviewContent.includes('<img')) {
          // Add responsive premium image styles
          reviewContent = reviewContent.replace(
            /<img(?![^>]*style=)([^>]*?)>/g,
            '<img$1 style="max-width:100%; height:auto; border-radius:0.75rem; margin:2.5rem auto; display:block; box-shadow:0 8px 20px rgba(0,0,0,0.08); border:1px solid #f3f4f6; transition: transform 0.3s ease, box-shadow 0.3s ease;">'
          );
          
          // Add product-image class for additional styling hooks
          reviewContent = reviewContent.replace(
            /<img(?![^>]*class=)/g, 
            '<img class="product-image" '
          );
          
          // Convert images to proper figure elements with captions for better presentation
          // First identify existing figures so we don't double-wrap
          const figurePlaceholders = [];
          let figureMatch;
          const figureRegex = /<figure[^>]*>[\s\S]*?<\/figure>/gi;
          
          // Create a working copy of the content
          let tempContent = reviewContent;
          
          // Replace existing figures with placeholders
          while ((figureMatch = figureRegex.exec(reviewContent)) !== null) {
            const placeholder = `__FIGURE_PLACEHOLDER_${figurePlaceholders.length}__`;
            figurePlaceholders.push(figureMatch[0]);
            tempContent = tempContent.replace(figureMatch[0], placeholder);
          }
          
          // Process standalone images that aren't in figures yet
          tempContent = tempContent.replace(
            /<img([^>]*?)>(?:\s*(?:<br\s*\/?>)?\s*(?:<em>(.*?)<\/em>|<i>(.*?)<\/i>|<small>(.*?)<\/small>|<p>(.*?)<\/p>))?/gi,
            (match, imgAttrs, caption1, caption2, caption3, caption4) => {
              const caption = caption1 || caption2 || caption3 || caption4 || '';
              
              if (caption) {
                return `<figure style="margin:3rem auto; text-align:center; max-width:85%;">
                  <img${imgAttrs} style="max-width:100%; height:auto; border-radius:0.75rem; margin:0 auto 1rem; display:block; box-shadow:0 8px 20px rgba(0,0,0,0.08); border:1px solid #f3f4f6; transition: transform 0.3s ease, box-shadow 0.3s ease;">
                  <figcaption style="font-size:0.95rem; color:#6b7280; font-style:italic; text-align:center; padding:0.5rem 1rem; border-bottom:2px solid #e5e7eb; display:inline-block;">${caption}</figcaption>
                </figure>`;
              }
              
              // For images without captions, still wrap in figure for consistent styling
              return `<figure style="margin:3rem auto; text-align:center; max-width:90%;">
                <img${imgAttrs} style="max-width:100%; height:auto; border-radius:0.75rem; margin:0 auto; display:block; box-shadow:0 8px 20px rgba(0,0,0,0.08); border:1px solid #f3f4f6; transition: transform 0.3s ease, box-shadow 0.3s ease;">
              </figure>`;
            }
          );
          
          // Restore original figures
          figurePlaceholders.forEach((figure, index) => {
            tempContent = tempContent.replace(`__FIGURE_PLACEHOLDER_${index}__`, figure);
          });
          
          // Update the review content with the enhanced image treatment
          reviewContent = tempContent;
          
          // Add image hover effects with a style block if not already present
          if (!reviewContent.includes('.product-image:hover')) {
            const imageHoverStyles = `
            <style>
              .product-image:hover {
                transform: translateY(-5px);
                box-shadow: 0 15px 30px rgba(0,0,0,0.12) !important;
              }
              
              figure {
                position: relative;
                overflow: hidden;
              }
              
              figure::before {
                content: "";
                position: absolute;
                bottom: 0;
                left: 50%;
                width: 0;
                height: 3px;
                background: linear-gradient(90deg, #3b82f6, #60a5fa);
                transition: width 0.4s ease, left 0.4s ease;
                border-radius: 3px;
                opacity: 0;
                z-index: 1;
              }
              
              figure:hover::before {
                width: 80%;
                left: 10%;
                opacity: 1;
              }
            </style>
            `;
            
            // Add the hover styles after any existing style block or at the beginning
            const styleEndPos = reviewContent.lastIndexOf('</style>');
            if (styleEndPos !== -1) {
              reviewContent = reviewContent.substring(0, styleEndPos + 8) + imageHoverStyles + reviewContent.substring(styleEndPos + 8);
            } else {
              reviewContent = imageHoverStyles + reviewContent;
            }
          }
        }
        
      } catch (apiError) {
        console.error('API error during review generation:', apiError);
        return res.status(500).json({
          success: false,
          message: 'Error generating review content from AI service',
          error: apiError instanceof Error ? apiError.message : String(apiError),
          suggestion: 'Try using a different model or check your API key'
        });
      }
      
      console.log(`Successfully generated review for ${data.productName} (${reviewContent.length} characters)`);
      
      // Return the generated review
      return res.status(200).json({ 
        success: true, 
        content: reviewContent,
        stats: {
          characterCount: reviewContent.length,
          approximateWordCount: Math.floor(reviewContent.split(/\s+/).length * 0.7) // Rough estimate accounting for HTML tags
        }
      });
    } catch (error) {
      console.error('Review generation error:', error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: 'Invalid request data',
          errors: error.errors
        });
      }
      
      return res.status(500).json({ 
        success: false, 
        message: 'Failed to generate review',
        error: error instanceof Error ? error.message : String(error),
        suggestion: 'Please check your inputs and try again. Make sure your API key is valid and you have selected an appropriate model.'
      });
    }
  });

  // Payment and subscription routes
  app.get('/api/subscription-plans', async (req, res) => {
    try {
      const plans = await storage.getSubscriptionPlans();
      res.json({
        success: true,
        plans
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve subscription plans',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.get('/api/subscription-plans/:id', async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      const plan = await storage.getSubscriptionPlan(planId);
      
      if (!plan) {
        return res.status(404).json({
          success: false,
          message: 'Subscription plan not found'
        });
      }
      
      res.json({
        success: true,
        plan
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve subscription plan',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.post('/api/process-payment', isAuthenticated, async (req, res) => {
    try {
      // Validate the payment data
      const paymentData = paymentFormSchema.parse(req.body);
      
      // In a real application, we would process the payment with a payment processor
      // like Stripe, PayPal, etc. here
      
      // For now, we'll simulate a successful payment
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }
      
      // Get the subscription plan
      const plan = await storage.getSubscriptionPlan(paymentData.subscriptionPlanId);
      
      if (!plan) {
        return res.status(404).json({
          success: false,
          message: 'Subscription plan not found'
        });
      }
      
      // Extract billing cycle from request and validate
      const billingCycle = req.body.billingCycle || plan.billingCycle;
      if (billingCycle !== 'monthly' && billingCycle !== 'yearly') {
        return res.status(400).json({
          success: false,
          message: 'Invalid billing cycle'
        });
      }
      
      // Calculate subscription dates
      const startDate = new Date();
      const endDate = new Date();
      
      // Set subscription end date based on billing cycle
      if (billingCycle === 'monthly') {
        endDate.setMonth(endDate.getMonth() + 1);
      } else if (billingCycle === 'yearly') {
        endDate.setFullYear(endDate.getFullYear() + 1);
      }
      
      // Set trial end date if applicable
      let trialEndsAt = undefined;
      if (paymentData.includeTrial) {
        trialEndsAt = new Date(startDate.getTime() + (14 * 24 * 60 * 60 * 1000));
      }
      
      // Update user subscription
      const updatedUser = await storage.updateUserSubscription(userId, {
        subscriptionPlanId: plan.id,
        subscriptionStatus: 'active',
        subscriptionStartDate: startDate,
        subscriptionEndDate: endDate,
        trialEndsAt: trialEndsAt
      });
      
      res.json({
        success: true,
        message: 'Payment processed successfully',
        user: updatedUser
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({
          success: false,
          message: 'Invalid payment data',
          errors: formatZodError(error)
        });
      }
      
      res.status(500).json({
        success: false,
        message: 'Failed to process payment',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.post('/api/update-subscription', isAuthenticated, async (req, res) => {
    try {
      // Validate subscription data
      const subscriptionData = subscriptionSchema.parse(req.body);
      
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }
      
      // Get the subscription plan
      const plan = await storage.getSubscriptionPlan(subscriptionData.subscriptionPlanId);
      
      if (!plan) {
        return res.status(404).json({
          success: false,
          message: 'Subscription plan not found'
        });
      }
      
      // Update user subscription
      const updatedUser = await storage.updateUserSubscription(userId, {
        subscriptionPlanId: plan.id,
        subscriptionStatus: subscriptionData.status || 'active'
      });
      
      res.json({
        success: true,
        message: 'Subscription updated successfully',
        user: updatedUser
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({
          success: false,
          message: 'Invalid subscription data',
          errors: formatZodError(error)
        });
      }
      
      res.status(500).json({
        success: false,
        message: 'Failed to update subscription',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.post('/api/cancel-subscription', isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }
      
      // Update user subscription
      const updatedUser = await storage.updateUserSubscription(userId, {
        subscriptionStatus: 'cancelled'
      });
      
      res.json({
        success: true,
        message: 'Subscription cancelled successfully',
        user: updatedUser
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Failed to cancel subscription',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Get a specific subscription plan by ID (the first definition is kept, removing this duplicate)
  app.get('/api/subscription-plans/:id', async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      
      if (isNaN(planId)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid plan ID'
        });
      }
      
      const plan = await storage.getSubscriptionPlan(planId);
      
      if (!plan) {
        return res.status(404).json({
          success: false,
          message: 'Subscription plan not found'
        });
      }
      
      res.json({
        success: true,
        plan
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Failed to fetch subscription plan',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Verify API key
  app.post('/api/verify-api-key', async (req, res) => {
    try {
      const { apiKey, model } = req.body;
      
      if (!apiKey || !model) {
        return res.status(400).json({
          success: false,
          message: 'API key and model are required'
        });
      }
      
      // Since we don't have a real API to verify against, we'll simulate a check
      // In a real app, you would validate against the actual API service
      const isValid = apiKey.length > 10;
      
      res.json({
        success: isValid,
        message: isValid 
          ? 'API key verified successfully' 
          : 'Invalid API key or model'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: 'Failed to verify API key',
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
