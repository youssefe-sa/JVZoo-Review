
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from '@shared/schema';

// Initialize the database connection with pooling and fallback
const connectionString = process.env.DATABASE_URL || 'postgres://postgres:postgres@0.0.0.0:5432/postgres';

// Use connection pooling for better performance
const client = postgres(connectionString, {
  max: 1,
  idle_timeout: 20,
  connect_timeout: 10,
  connection: {
    ssl: process.env.NODE_ENV === 'production'
  },
  onnotice: () => {}, // Suppress notice messages
  onparameter: () => {} // Suppress parameter messages
});

// Test database connection
const testConnection = async () => {
  try {
    await client`SELECT 1`;
    console.log('Database connected successfully');
  } catch (error) {
    console.error('Database connection error:', error);
  }
};

testConnection();

export const db = drizzle(client, { schema });
