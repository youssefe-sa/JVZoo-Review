/**
 * Text utility functions for processing and formatting text
 */

/**
 * Converts multiline text to a single line by replacing newlines and multiple spaces with a single space
 * @param text The text to convert to a single line
 * @returns The text as a single line
 */
export function convertToSingleLine(text: string): string {
  if (!text) return '';
  
  // Replace all newlines and carriage returns with a space
  let singleLine = text.replace(/\r?\n|\r/g, ' ');
  
  // Replace multiple spaces with a single space
  singleLine = singleLine.replace(/\s+/g, ' ');
  
  // Trim leading and trailing whitespace
  return singleLine.trim();
}

/**
 * Removes HTML tags from text
 * @param html Text containing HTML tags
 * @returns Plain text without HTML tags
 */
export function stripHtml(html: string): string {
  if (!html) return '';
  return html.replace(/<[^>]*>/g, '');
}

/**
 * Counts words in text
 * @param text The text to count words in
 * @returns The number of words
 */
export function countWords(text: string): number {
  if (!text) return 0;
  
  // Strip HTML tags if present
  const strippedText = stripHtml(text);
  
  // Split by whitespace and filter out empty strings
  const words = strippedText.split(/\s+/).filter(word => word.length > 0);
  return words.length;
}