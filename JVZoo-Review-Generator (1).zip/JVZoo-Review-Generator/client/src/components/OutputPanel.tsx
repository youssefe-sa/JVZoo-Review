import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ReviewResponse } from "@/lib/types";
import { AlertCircle, AlertTriangle, ExternalLink, Loader2 } from "lucide-react";

/**
 * Extract only the final HTML review from the phase-by-phase analysis content
 * This finds the final review content after Phase 5
 */
/**
 * Extract only the final HTML review from the phase-by-phase analysis content
 * This properly isolates just the final review HTML for display and export
 */
/**
 * Extracts just the final review HTML from the AI-generated content, 
 * filtering out any analysis or intermediate content from the phased approach.
 * 
 * @param content The original generated content from the AI
 * @returns Only the final review HTML with proper styling
 */
function extractFinalReviewContent(content: string): string {
  // The server should have already done most of the extraction work,
  // but we'll add a safety layer here to ensure we only get the final review
  
  try {
    // Early return if content is empty or doesn't appear to be HTML
    if (!content || content.length < 50 || (!content.includes('<') && !content.includes('>'))) {
      console.warn("Content appears to be invalid or empty");
      return content;
    }
    
    let extractedContent = content;
    
    // Final cleanup of any phase markers that might still be present
    if (content.includes('PHASE') || content.includes('Phase')) {
      console.log('Client-side cleanup of any remaining phased content');
      
      // Remove all phase headers and explanations
      extractedContent = extractedContent.replace(/PHASE \d+[\s\S]*?(?=<h1|<div class="prose|<article|<section)/gi, '');
      extractedContent = extractedContent.replace(/Phase \d+[\s\S]*?(?=<h1|<div class="prose|<article|<section)/gi, '');
      
      // If we've removed too much and lost our HTML structure, revert to original
      if (!extractedContent.includes('<')) {
        console.warn("Extraction removed all HTML content - reverting to original");
        extractedContent = content;
      }
      
      // Look specifically for HTML content if we still have phase references
      if (extractedContent.includes('PHASE') || extractedContent.includes('Phase')) {
        // Find any complete HTML structure
        const htmlPattern = /<(?:html|body|div\s+class=["']prose["']|article|main|section)[^>]*>[\s\S]*?<\/(?:html|body|div|article|main|section)>/i;
        const htmlMatch = extractedContent.match(htmlPattern);
        
        if (htmlMatch) {
          console.log("Found complete HTML structure - using that");
          extractedContent = htmlMatch[0];
        } else {
          // Find any significant HTML starting point like a heading
          const startPattern = /<h1[^>]*>.*?<\/h1>/i;
          const startMatch = extractedContent.match(startPattern);
          
          if (startMatch && startMatch.index !== undefined) {
            console.log("Found heading - starting from there");
            extractedContent = extractedContent.substring(startMatch.index);
          }
        }
      }
    }
    
    // Apply CSS classes and styling enhancement
    return enhanceReviewStyling(extractedContent);
  } catch (error) {
    console.error('Error extracting final review content:', error);
    return content; // Return original if extraction fails
  }
}

/**
 * Enhance the styling of review content by adding proper CSS classes
 * optimized for WordPress, Blogger, and other platforms
 */
function enhanceReviewStyling(content: string): string {
  try {
    let enhancedContent = content;
    
    // Clean up any irregular whitespace or control characters
    enhancedContent = enhancedContent.replace(/[\u0000-\u001F\u007F-\u009F\u2000-\u200F\u2028-\u202F]/g, ' ');
    
    // Make sure we have at least a basic HTML structure
    if (!enhancedContent.includes('<html') && !enhancedContent.includes('<body')) {
      // First, ensure the content is wrapped in a proper prose container
      if (!enhancedContent.includes('class="prose"')) {
        enhancedContent = `<div class="review-content prose max-w-none">${enhancedContent}</div>`;
      }
    }
    
    // Process special content elements with responsive styling
    
    // 1. Price Tables - make them responsive and well-styled
    if (enhancedContent.includes('<table')) {
      // Add a container for tables to ensure horizontal scrolling on mobile
      enhancedContent = enhancedContent.replace(
        /(<table[^>]*>(?:[\s\S]*?)<\/table>)/g,
        '<div class="table-responsive" style="overflow-x:auto; margin:1.5rem 0;">$1</div>'
      );
      
      // Add price-table class to tables if they don't already have a class
      enhancedContent = enhancedContent.replace(
        /<table(?![^>]*class=)/g, 
        '<table class="price-table" '
      );
      
      // Add responsive styling attributes
      enhancedContent = enhancedContent.replace(
        /<table[^>]*class=["']([^"']*)["']/g,
        '<table class="$1" style="width:100%; border-collapse:collapse; margin:0; border-radius:0.5rem; overflow:hidden;"'
      );
      
      // Style table headers
      enhancedContent = enhancedContent.replace(
        /<th(?![^>]*style=)/g,
        '<th style="background-color:#2563eb; color:white; font-weight:600; text-align:left; padding:1rem; border:none;"'
      );
      
      // Style table cells
      enhancedContent = enhancedContent.replace(
        /<td(?![^>]*style=)/g,
        '<td style="padding:1rem; border:1px solid #e5e7eb;"'
      );
    }
    
    // 2. Pros and Cons Sections - make them visually distinct and responsive
    // Identify pros and cons sections by their headings
    const prosHeadingPattern = /<h[3-4][^>]*>.*?\b(?:pros|advantages|benefits|positives)\b.*?<\/h[3-4]>/i;
    const consHeadingPattern = /<h[3-4][^>]*>.*?\b(?:cons|disadvantages|drawbacks|negatives)\b.*?<\/h[3-4]>/i;
    
    // Check if both pros and cons sections exist
    if (prosHeadingPattern.test(enhancedContent) && consHeadingPattern.test(enhancedContent)) {
      // Find the full pattern from pros to cons
      const fullProsConsPattern = new RegExp(
        `(${prosHeadingPattern.source}[\\s\\S]*?)(${consHeadingPattern.source}[\\s\\S]*?(?:<h[2-3]|<div|$))`,
        'i'
      );
      
      // Replace with styled containers
      enhancedContent = enhancedContent.replace(
        fullProsConsPattern,
        (match, prosSection, consSection) => {
          return `<div class="pros-cons" style="display:grid; grid-template-columns:1fr; gap:1.5rem; margin:2rem 0; max-width:100%;">
            <div class="pros" style="background-color:#f0fdf4; border:1px solid #dcfce7; border-radius:0.5rem; padding:1.5rem; box-shadow:0 4px 6px rgba(0,0,0,0.05);">
              ${prosSection.replace(/<h[3-4]([^>]*)>/, '<h3$1 style="color:#15803d; font-weight:700; margin-top:0; display:flex; align-items:center;">')}
            </div>
            <div class="cons" style="background-color:#fef2f2; border:1px solid #fee2e2; border-radius:0.5rem; padding:1.5rem; box-shadow:0 4px 6px rgba(0,0,0,0.05);">
              ${consSection.replace(/<h[3-4]([^>]*)>/, '<h3$1 style="color:#dc2626; font-weight:700; margin-top:0; display:flex; align-items:center;">')}
            </div>
          </div>
          <style>
            @media (min-width: 768px) {
              .pros-cons { grid-template-columns: 1fr 1fr; }
            }
            .pros h3::before, .pros h4::before {
              content: "✓";
              margin-right: 0.5rem;
              font-weight: bold;
              color: #16a34a;
            }
            .cons h3::before, .cons h4::before {
              content: "✗";
              margin-right: 0.5rem;
              font-weight: bold;
              color: #ef4444;
            }
            .pros ul, .cons ul {
              padding-left: 1rem;
              margin-top: 0.75rem;
            }
            .pros li, .cons li {
              margin-bottom: 0.5rem;
              position: relative;
              padding-left: 1.5rem;
            }
            .pros li::before {
              content: "+";
              position: absolute;
              left: 0;
              color: #16a34a;
              font-weight: bold;
            }
            .cons li::before {
              content: "-";
              position: absolute;
              left: 0;
              color: #ef4444;
              font-weight: bold;
            }
          </style>`;
        }
      );
    }
    
    // 3. Call to Action Buttons - make them stand out with inline styles
    if (enhancedContent.includes('<a')) {
      // Pattern for links that might be CTAs (based on common CTA text)
      const ctaPattern = /<a\s+(?:[^>]*?\s+)?href=["']([^"']*)["'][^>]*>(.*?(?:get|buy|try|check|discover|download|access|click|visit|view|learn|start).*?)<\/a>/gi;
      
      // Replace with styled CTA buttons
      enhancedContent = enhancedContent.replace(
        ctaPattern,
        (match, href, text) => {
          // Skip if already styled
          if (match.includes('class="cta-button"') || match.includes('style=')) {
            return match;
          }
          
          // Create a styled CTA button with inline styles for maximum compatibility
          return `<div style="text-align:center; background:linear-gradient(to bottom, rgba(243,244,246,0.7), rgba(249,250,251,0.9)); padding:2rem 1.5rem; border-radius:0.75rem; margin:2.5rem 0; position:relative; border:2px solid #e5e7eb;">
            <a href="${href}" class="cta-button" style="display:inline-block; background:linear-gradient(135deg, #3b82f6, #2563eb); color:white !important; font-weight:700; padding:0.875rem 2rem; border-radius:9999px; text-decoration:none !important; transition:all 0.3s; box-shadow:0 4px 10px rgba(37,99,235,0.3); border:none !important; margin:0; font-size:1.125rem; letter-spacing:0.025em; text-align:center;">
              ${text} <span style="margin-left:0.5rem; font-weight:800;">&rarr;</span>
            </a>
          </div>`;
        }
      );
    }
    
    // 4. Image Handling - make images responsive with proper styling
    if (enhancedContent.includes('<img')) {
      // Add responsive image classes with inline styles
      enhancedContent = enhancedContent.replace(
        /<img(?![^>]*style=)([^>]*?)>/g,
        '<img$1 style="max-width:100%; height:auto; border-radius:0.5rem; margin:1.5rem auto; display:block; box-shadow:0 2px 8px rgba(0,0,0,0.1);">'
      );
      
      // Wrap images in figure elements if they're not already in a figure
      // First identify existing figures so we don't double-wrap images
      const figures: string[] = [];
      let figureMatch;
      const figureRegex = /<figure[^>]*>[\s\S]*?<\/figure>/gi;
      while ((figureMatch = figureRegex.exec(enhancedContent)) !== null) {
        figures.push(figureMatch[0]);
      }
      
      // Create a placeholder for figures we find
      let tempContent = enhancedContent;
      figures.forEach((figure, index) => {
        tempContent = tempContent.replace(figure, `___FIGURE_PLACEHOLDER_${index}___`);
      });
      
      // Now process standalone images with a simple regex
      tempContent = tempContent.replace(
        /(<img[^>]*>)(?:\s*<br\s*\/?>?\s*<em>(.*?)<\/em>)?/gi,
        (match, img, caption) => {
          if (caption) {
            return `<figure style="margin:2rem auto; text-align:center;">
              ${img}
              <figcaption style="font-size:0.875rem; color:#64748b; margin-top:0.5rem; font-style:italic;">${caption}</figcaption>
            </figure>`;
          }
          return `<figure style="margin:2rem auto; text-align:center;">${img}</figure>`;
        }
      );
      
      // Put back the original figures
      figures.forEach((figure, index) => {
        tempContent = tempContent.replace(`___FIGURE_PLACEHOLDER_${index}___`, figure);
      });
      
      enhancedContent = tempContent;
    }
    
    // 5. Add table of contents if it seems to be a longer article with multiple headings
    const h2Count = (enhancedContent.match(/<h2[^>]*>/g) || []).length;
    if (h2Count >= 3 && !enhancedContent.includes('table-of-contents')) {
      // Extract all h2 headings
      const headings: string[] = [];
      let headingMatch;
      const headingRegex = /<h2[^>]*>(.*?)<\/h2>/g;
      
      while ((headingMatch = headingRegex.exec(enhancedContent)) !== null) {
        headings.push(headingMatch[1].replace(/<[^>]*>/g, '').trim());
      }
      
      if (headings.length >= 3) {
        // Generate table of contents HTML
        let tocHtml = `
          <div class="table-of-contents" style="background:#f9fafb; border:1px solid #e5e7eb; border-radius:0.5rem; padding:1.5rem; margin:2rem 0;">
            <h3 style="margin-top:0; font-size:1.25rem; color:#1e40af;">Table of Contents</h3>
            <ul style="list-style:none; padding-left:0; margin-bottom:0;">
        `;
        
        headings.forEach((heading, index) => {
          // Create a slug for the heading
          const slug = heading
            .toLowerCase()
            .replace(/[^\w\s-]/g, '')
            .replace(/[\s_-]+/g, '-');
          
          tocHtml += `
            <li style="margin:0.5rem 0; padding-left:1rem; position:relative;">
              <span style="position:absolute; left:0; top:0.45rem; width:0.35rem; height:0.35rem; border-radius:50%; background:#3b82f6;"></span>
              <a href="#${slug}" style="color:#2563eb; text-decoration:none; transition:all 0.2s ease;">${heading}</a>
            </li>
          `;
          
          // Add id to the corresponding heading in the content
          enhancedContent = enhancedContent.replace(
            new RegExp(`(<h2[^>]*)>(${heading.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})<\/h2>`, 'i'),
            `$1 id="${slug}">$2</h2>`
          );
        });
        
        tocHtml += `
            </ul>
          </div>
        `;
        
        // Find the first h2 tag and insert the TOC before it
        const firstH2Match = /<h2[^>]*>/i.exec(enhancedContent);
        if (firstH2Match && firstH2Match.index) {
          enhancedContent = 
            enhancedContent.substring(0, firstH2Match.index) + 
            tocHtml + 
            enhancedContent.substring(firstH2Match.index);
        }
      }
    }
    
    // 6. Final touch - add a style block with critical CSS for better third-party platform compatibility
    if (!enhancedContent.includes('<style>')) {
      const criticalCss = `
      <style>
        /* Critical CSS for the review */
        .prose { font-family: system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; line-height: 1.7; color: #374151; }
        .prose h1, .prose h2, .prose h3, .prose h4 { font-weight: 700; margin-top: 1.5em; margin-bottom: 0.8em; line-height: 1.3; }
        .prose h1 { font-size: 2.25em; color: #1e3a8a; }
        .prose h2 { font-size: 1.75em; color: #1e40af; padding-bottom: 0.3em; border-bottom: 1px solid #e5e7eb; }
        .prose h3 { font-size: 1.5em; color: #2563eb; }
        .prose h4 { font-size: 1.25em; color: #3b82f6; }
        .prose p, .prose ul, .prose ol { margin-top: 1em; margin-bottom: 1em; }
        .prose img { max-width: 100%; height: auto; border-radius: 0.5rem; margin: 1.5rem auto; display: block; }
        .prose a { color: #2563eb; text-decoration: none; }
        .prose a:hover { text-decoration: underline; }
        .price-table { width: 100%; border-collapse: collapse; border-radius: 0.5rem; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin: 2rem 0; }
        .price-table th { background-color: #2563eb; color: white; padding: 1rem; text-align: left; }
        .price-table td { padding: 1rem; border: 1px solid #e5e7eb; }
        .price-table tr:nth-child(odd) { background-color: #f9fafb; }
        .cta-button { display: inline-block; background: linear-gradient(135deg, #3b82f6, #2563eb); color: white !important; font-weight: 700; padding: 0.875rem 2rem; border-radius: 9999px; text-decoration: none !important; transition: all 0.3s; }
        .cta-button:hover { transform: translateY(-3px); box-shadow: 0 8px 15px rgba(37,99,235,0.4); }
        .pros-cons { display: grid; grid-template-columns: 1fr; gap: 1.5rem; margin: 2rem 0; }
        @media (min-width: 768px) { .pros-cons { grid-template-columns: 1fr 1fr; } }
        .table-responsive { overflow-x: auto; margin: 1.5rem 0; }
        
        /* Print styles */
        @media print {
          .prose { max-width: 100%; }
          .prose a { text-decoration: underline; color: #2563eb; }
          .price-table { border: 1px solid #e5e7eb; box-shadow: none; }
          .pros, .cons { box-shadow: none; border: 1px solid #e5e7eb; }
        }
      </style>
      `;
      
      // Add the critical CSS to the content
      if (enhancedContent.includes('<head>')) {
        enhancedContent = enhancedContent.replace('<head>', `<head>${criticalCss}`);
      } else if (enhancedContent.includes('<html>')) {
        enhancedContent = enhancedContent.replace('<html>', `<html><head>${criticalCss}</head>`);
      } else {
        // Just prepend it for partial HTML fragments
        enhancedContent = `${criticalCss}${enhancedContent}`;
      }
    }
    
    return enhancedContent;
  } catch (error) {
    console.error('Error enhancing review styling:', error);
    // Return original content in case of error
    if (!content.includes('class="prose"')) {
      return `<div class="prose">${content}</div>`;
    }
    return content;
  }
}


interface OutputPanelProps {
  reviewContent: ReviewResponse | null;
  isGenerating: boolean;
  activeTab: "review" | "html";
  setActiveTab: (tab: "review" | "html") => void;
  error?: string; // Added error prop
}

export default function OutputPanel({ 
  reviewContent, 
  isGenerating, 
  activeTab,
  setActiveTab,
  error
}: OutputPanelProps) {
  const { toast } = useToast();

  // Track if we're showing phased content 
  const isPhaseBasedContent = useMemo(() => {
    if (!reviewContent || !reviewContent.content) return false;
    return reviewContent.content.includes('PHASE') || reviewContent.content.includes('Phase');
  }, [reviewContent]);
  
  // Process content once to avoid multiple extractions
  const finalContent = useMemo(() => {
    if (!reviewContent || !reviewContent.content) return '';
    
    // Log content type to help with debugging
    if (isPhaseBasedContent) {
      console.log('Processing multi-phase content, extracting final review output');
    }
    
    return extractFinalReviewContent(reviewContent.content);
  }, [reviewContent, isPhaseBasedContent]);

  const handleCopyToClipboard = () => {
    if (!finalContent) return;
    
    navigator.clipboard.writeText(finalContent).then(() => {
      toast({
        title: "Copied!",
        description: "Final review copied to clipboard",
      });
    }).catch(err => {
      toast({
        title: "Copy failed",
        description: "Failed to copy review to clipboard",
        variant: "destructive",
      });
    });
  };

  const handleDownload = () => {
    if (!finalContent) return;

    // Create full HTML document for non-HTML tabs
    const htmlContent = activeTab === "html" 
      ? finalContent
      : `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generated Review</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
      /* Enhanced styling for the review output */
      .prose {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        line-height: 1.7;
        color: #374151;
      }
      
      .prose h1 {
        font-size: 2.5rem;
        font-weight: 800;
        color: #1e3a8a;
        margin-top: 2.5rem;
        margin-bottom: 1.5rem;
        line-height: 1.2;
      }
      
      .prose h2 {
        font-size: 1.875rem;
        font-weight: 700;
        color: #1e40af;
        margin-top: 2rem;
        margin-bottom: 1rem;
        border-bottom: 1px solid #e5e7eb;
        padding-bottom: 0.5rem;
      }
      
      .prose h3 {
        font-size: 1.5rem;
        font-weight: 600;
        color: #2563eb;
        margin-top: 1.5rem;
        margin-bottom: 0.75rem;
      }
      
      .prose h4 {
        font-size: 1.25rem;
        font-weight: 600;
        color: #3b82f6;
        margin-top: 1.25rem;
        margin-bottom: 0.5rem;
      }
      
      .prose p {
        margin-top: 1rem;
        margin-bottom: 1rem;
      }
      
      .prose ul, .prose ol {
        margin-top: 1rem;
        margin-bottom: 1rem;
        padding-left: 1.5rem;
      }
      
      .prose li {
        margin-top: 0.5rem;
        margin-bottom: 0.5rem;
      }
      
      .prose blockquote {
        border-left: 4px solid #3b82f6;
        padding-left: 1rem;
        font-style: italic;
        color: #4b5563;
        background-color: #f3f4f6;
        padding: 1rem;
        border-radius: 0.375rem;
        margin: 1.5rem 0;
      }
      
      .prose table {
        border-collapse: collapse;
        width: 100%;
        margin: 1.5rem 0;
        overflow: hidden;
        border-radius: 0.375rem;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      }
      
      .prose th {
        background-color: #f9fafb;
        font-weight: 600;
        text-align: left;
        padding: 0.75rem 1rem;
        border: 1px solid #e5e7eb;
      }
      
      .prose td {
        padding: 0.75rem 1rem;
        border: 1px solid #e5e7eb;
      }
      
      .prose tr:nth-child(even) {
        background-color: #f9fafb;
      }
      
      .prose img {
        border-radius: 0.5rem;
        margin: 1.5rem auto;
        max-width: 100%;
        height: auto;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        display: block;
      }
      
      /* Product Images specific styling */
      .prose .product-image {
        margin: 2rem auto;
        max-width: 85%;
        border: 1px solid #e5e7eb;
        padding: 0.5rem;
        background: white;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
      }
      
      /* Image captions */
      .prose figure {
        margin: 2rem auto;
        text-align: center;
      }
      
      .prose figcaption {
        font-size: 0.875rem;
        color: #64748b;
        margin-top: 0.5rem;
        font-style: italic;
      }
      
      .prose a {
        color: #2563eb;
        text-decoration: none;
        border-bottom: 1px dotted #2563eb;
        transition: all 0.2s ease;
      }
      
      .prose a:hover {
        color: #1d4ed8;
        border-bottom: 1px solid #1d4ed8;
      }
      
      /* Styling for specific elements often found in reviews */
      .prose .pros-cons {
        display: grid;
        grid-template-columns: 1fr;
        gap: 1.5rem;
        margin: 1.5rem 0;
      }
      
      @media (min-width: 768px) {
        .prose .pros-cons {
          grid-template-columns: 1fr 1fr;
        }
      }
      
      .prose .pros, .prose .cons {
        padding: 1.5rem;
        border-radius: 0.5rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        position: relative;
      }
      
      .prose .pros {
        background-color: #f0fdf4;
        border: 1px solid #dcfce7;
      }
      
      .prose .cons {
        background-color: #fef2f2;
        border: 1px solid #fee2e2;
      }
      
      .prose .pros h3, .prose .pros h4 {
        color: #15803d;
        font-weight: 700;
        margin-top: 0;
        display: flex;
        align-items: center;
        font-size: 1.25rem;
      }
      
      .prose .cons h3, .prose .cons h4 {
        color: #dc2626;
        font-weight: 700;
        margin-top: 0;
        display: flex;
        align-items: center;
        font-size: 1.25rem;
      }
      
      .prose .pros h3::before, .prose .pros h4::before {
        content: "✓";
        margin-right: 0.5rem;
        font-weight: bold;
        color: #16a34a;
        font-size: 1.25rem;
      }
      
      .prose .cons h3::before, .prose .cons h4::before {
        content: "✗";
        margin-right: 0.5rem;
        font-weight: bold;
        color: #ef4444;
        font-size: 1.25rem;
      }
      
      /* Better styling for lists inside pros/cons */
      .prose .pros ul, .prose .cons ul {
        padding-left: 1rem;
        margin-top: 0.75rem;
      }
      
      .prose .pros li, .prose .cons li {
        margin-bottom: 0.5rem;
        position: relative;
        padding-left: 1.5rem;
      }
      
      .prose .pros li::before {
        content: "+";
        position: absolute;
        left: 0;
        color: #16a34a;
        font-weight: bold;
      }
      
      .prose .cons li::before {
        content: "-";
        position: absolute;
        left: 0;
        color: #ef4444;
        font-weight: bold;
      }
      
      .prose .product-info {
        background-color: #f3f4f6;
        border-radius: 0.375rem;
        padding: 1rem;
        margin: 1.5rem 0;
      }
      
      /* Enhanced CTA buttons with better visibility */
      .prose .cta-button {
        display: inline-block;
        background: linear-gradient(135deg, #3b82f6, #2563eb);
        color: white !important;
        font-weight: 700;
        padding: 0.875rem 2rem;
        border-radius: 9999px;
        text-decoration: none !important;
        transition: all 0.3s;
        box-shadow: 0 4px 10px rgba(37, 99, 235, 0.3);
        border: none !important;
        margin: 1.5rem 0;
        font-size: 1.125rem;
        letter-spacing: 0.025em;
        text-align: center;
        position: relative;
        z-index: 10;
      }
      
      .prose .cta-button:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 15px rgba(37, 99, 235, 0.4);
        background: linear-gradient(135deg, #2563eb, #1d4ed8);
      }
      
      /* Add icon to CTA buttons */
      .prose .cta-button::after {
        content: " →";
        font-family: system-ui, sans-serif;
        margin-left: 0.5rem;
        font-weight: 800;
        transition: transform 0.2s ease;
        display: inline-block;
      }
      
      .prose .cta-button:hover::after {
        transform: translateX(4px);
      }
      
      /* CTA Banner for more visibility */
      .prose p:has(a.cta-button) {
        text-align: center;
        background: linear-gradient(to bottom, rgba(243, 244, 246, 0.7), rgba(249, 250, 251, 0.9));
        padding: 2rem 1.5rem;
        border-radius: 0.75rem;
        margin: 2.5rem 0;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        position: relative;
      }
      
      .prose p:has(a.cta-button)::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 0.75rem;
        border: 2px solid #e5e7eb;
        box-sizing: border-box;
        z-index: 0;
        pointer-events: none;
        background: repeating-linear-gradient(
          -45deg,
          transparent,
          transparent 10px,
          rgba(59, 130, 246, 0.03) 10px,
          rgba(59, 130, 246, 0.03) 20px
        );
      }
      
      .prose .rating {
        display: flex;
        align-items: center;
        margin: 1rem 0;
      }
      
      .prose .stars {
        color: #f59e0b;
        font-size: 1.25rem;
        margin-right: 0.5rem;
      }
      
      .prose .highlight-box {
        background-color: #eff6ff;
        border: 1px solid #dbeafe;
        border-radius: 0.375rem;
        padding: 1.25rem;
        margin: 1.5rem 0;
      }
      
      .prose .feature-list {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 1rem;
        margin: 1.5rem 0;
      }
      
      .prose .feature-item {
        background-color: #f9fafb;
        border: 1px solid #e5e7eb;
        border-radius: 0.375rem;
        padding: 1rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
      }
      
      .prose .feature-icon {
        font-size: 2rem;
        color: #3b82f6;
        margin-bottom: 0.5rem;
      }
      
      /* Price table styling */
      .prose .price-table {
        margin: 2rem 0;
        border-collapse: collapse;
        width: 100%;
        overflow: hidden;
        border-radius: 0.5rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      }
      
      .prose .price-table th {
        background-color: #2563eb;
        color: white;
        font-weight: 600;
        text-align: left;
        padding: 1rem;
        border: none;
      }
      
      .prose .price-table td {
        padding: 1rem;
        border: 1px solid #e5e7eb;
      }
      
      .prose .price-table tr:nth-child(odd) {
        background-color: #f9fafb;
      }
      
      .prose .price-table tr:nth-child(even) {
        background-color: white;
      }
      
      .prose .price-table .highlight {
        background-color: #eff6ff;
        font-weight: 600;
      }
      
      /* FAQ styling */
      .prose .faq-section {
        margin: 2rem 0;
      }
      
      .prose .faq-item {
        border: 1px solid #e5e7eb;
        border-radius: 0.375rem;
        margin-bottom: 1rem;
        overflow: hidden;
      }
      
      .prose .faq-question {
        background-color: #f9fafb;
        padding: 1rem;
        font-weight: 600;
        color: #1e40af;
        cursor: pointer;
      }
      
      .prose .faq-answer {
        padding: 1rem;
        border-top: 1px solid #e5e7eb;
      }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <div class="bg-white p-8 rounded-lg shadow-md prose max-w-none">
            ${finalContent}
        </div>
    </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "generated-review.html";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Downloaded!",
      description: "Review downloaded as HTML",
    });
  };

  // Word count calculation helper
  const calculateWordCount = (content: string): number => {
    // Remove HTML tags and count words
    const text = content.replace(/<[^>]*>/g, ' ');
    const words = text.trim().split(/\s+/).filter(word => word.length > 0);
    return words.length;
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="p-5 border-b border-gray-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
        <div className="flex items-center">
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-indigo-50 text-indigo-600 mr-3">
            <i className="ri-article-line text-xl"></i>
          </div>
          <div>
            <h2 className="text-lg font-semibold text-gray-800">Generated Review</h2>
            {reviewContent && (
              <p className="text-xs text-gray-500 mt-0.5">
                {calculateWordCount(finalContent).toLocaleString()} words
                {reviewContent.seoScore && ` • SEO Score: ${reviewContent.seoScore}/100`}
              </p>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-2 w-full md:w-auto">
          {isGenerating && (
            <div className="text-sm text-indigo-600 flex items-center gap-2 bg-indigo-50 py-1.5 px-3 rounded-lg">
              <svg className="animate-spin h-4 w-4 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <span className="font-medium">Generating review...</span>
            </div>
          )}
          
          {reviewContent && !isGenerating && (
            <div className="flex items-center gap-1 w-full md:w-auto justify-end">
              <button 
                onClick={handleCopyToClipboard}
                className="flex items-center gap-1 px-3 py-1.5 text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg transition-all text-sm"
                title="Copy to clipboard"
                disabled={!reviewContent}
              >
                <i className="ri-file-copy-line"></i>
                <span className="hidden sm:inline">Copy</span>
              </button>
              <button 
                onClick={handleDownload}
                className="flex items-center gap-1 px-3 py-1.5 text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg transition-all text-sm"
                title="Download as HTML"
                disabled={!reviewContent}
              >
                <i className="ri-download-line"></i>
                <span className="hidden sm:inline">Download</span>
              </button>
              {reviewContent && reviewContent.content && (
                <button 
                  onClick={() => {
                    const blogContent = encodeURIComponent(finalContent);
                    const title = encodeURIComponent("Generated Product Review");
                    window.open(`https://www.blogger.com/blog-this.g?n=${title}&u=about:blank&t=${blogContent}`, "_blank")
                  }}
                  className="flex items-center gap-1 px-3 py-1.5 text-green-600 bg-green-50 hover:bg-green-100 rounded-lg transition-all text-sm"
                  title="Publish to Blogger"
                >
                  <i className="ri-external-link-line"></i>
                  <span className="hidden sm:inline">Publish</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-gray-50 px-5 py-3 border-b border-gray-100">
        <div className="flex space-x-2">
          <button 
            onClick={() => setActiveTab("review")}
            className={`flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-all ${
              activeTab === "review" 
                ? "bg-indigo-600 text-white shadow-sm" 
                : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
            }`}
          >
            <i className={`ri-file-text-line mr-1.5 ${activeTab === "review" ? "text-indigo-200" : "text-indigo-400"}`}></i>
            Review
          </button>
          <button 
            onClick={() => setActiveTab("html")}
            className={`flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-all ${
              activeTab === "html" 
                ? "bg-indigo-600 text-white shadow-sm" 
                : "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50"
            }`}
          >
            <i className={`ri-code-line mr-1.5 ${activeTab === "html" ? "text-indigo-200" : "text-indigo-400"}`}></i>
            HTML Code
          </button>
        </div>
      </div>

      {/* Review Content */}
      <div className="p-5 h-[600px] overflow-y-auto">
        {error && !isGenerating && (
          <div className="h-full flex flex-col items-center justify-center text-gray-500">
            <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mb-4 border border-red-100">
              <AlertTriangle className="h-10 w-10 text-red-500" />
            </div>
            <p className="text-lg font-medium text-gray-700">Error Generating Review</p>
            <div className="mt-4 bg-red-50 border border-red-100 rounded-lg p-4 max-w-xl w-full">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-red-800">Generation failed</h3>
                  <div className="mt-2 text-sm text-red-700">
                    <p>{error}</p>
                  </div>
                  <div className="mt-4">
                    <div className="-mx-2 -my-1.5 flex">
                      <Button
                        variant="outline"
                        className="bg-red-50 border-red-200 text-red-700 hover:bg-red-100 px-3 py-1.5 rounded text-xs"
                        onClick={() => window.location.reload()}
                      >
                        <i className="ri-refresh-line mr-1.5"></i>
                        Reload Page
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-6 bg-amber-50 rounded-lg p-3 max-w-md">
              <div className="flex">
                <div className="shrink-0 text-amber-600">
                  <i className="ri-lightbulb-line mt-0.5 text-lg"></i>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-amber-800">Troubleshooting Tips</h3>
                  <ul className="text-sm text-amber-700 mt-0.5 list-disc pl-4 space-y-1">
                    <li>Verify your API key is valid and has necessary permissions</li>
                    <li>Try using a different model (Gemini 1.5 Pro or Gemini 1.0 Pro)</li>
                    <li>Reduce the complexity of your review by disabling advanced features</li>
                    <li>Check for any rate limiting or quota issues with your API key</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {!reviewContent && !isGenerating && !error && (
          <div className="h-full flex flex-col items-center justify-center text-gray-500">
            <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mb-4 border border-gray-200">
              <i className="ri-file-text-line text-5xl text-gray-300"></i>
            </div>
            <p className="text-lg font-medium text-gray-600">Your generated review will appear here</p>
            <p className="text-sm mt-2 max-w-md text-center text-gray-500">
              Configure your product details, SEO keywords, and review options, then click "Generate Review" to create your professional product review
            </p>
            <div className="mt-6 bg-blue-50 rounded-lg p-3 max-w-md">
              <div className="flex">
                <div className="shrink-0 text-blue-500">
                  <i className="ri-lightbulb-line mt-0.5 text-lg"></i>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-blue-800">Pro Tip</h3>
                  <div className="text-sm text-blue-700 mt-0.5">
                    For best results, select the Gemini 2.5 Pro model and enable the "Use 5-Phase Approach" option in the Review Options panel.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {isGenerating && !reviewContent && (
          <div className="h-full flex flex-col items-center justify-center text-gray-500">
            <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center mb-6 border border-indigo-100">
              <Loader2 className="h-12 w-12 text-indigo-600 animate-spin" />
            </div>
            <p className="text-lg font-medium text-gray-700">Generating your professional review...</p>
            <p className="text-sm mt-2 max-w-md text-center text-gray-500">
              This may take 1-2 minutes depending on the options selected and the complexity of the product
            </p>
            
            <div className="mt-5 bg-blue-50 border border-blue-100 rounded-md p-4 max-w-md">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <AlertCircle className="h-5 w-5 text-blue-600" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-blue-800">Phase-by-Phase Analysis Process</h3>
                  <div className="mt-2 text-sm text-blue-700">
                    <p>If you enabled "Advanced Multi-Phase Analysis", the AI will show you its complete work through each phase:</p>
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>PHASE 1: Link Analysis & Deep Research</li>
                      <li>PHASE 2: Competitive Landscape Analysis</li>
                      <li>PHASE 3: In-Depth Offer Analysis</li>
                      <li>PHASE 4: Strategic Content Architecture</li>
                      <li>PHASE 5: Premium Review Creation</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6 max-w-md w-full">
              <div className="w-full bg-gray-100 rounded-full h-2.5">
                <div className="bg-indigo-600 h-2.5 rounded-full animate-pulse" style={{ width: "70%" }}></div>
              </div>
              <p className="text-xs text-gray-500 mt-1.5 text-center">Crafting premium content with your selected features</p>
            </div>
          </div>
        )}

        {reviewContent && activeTab === "review" && (
          <>
            {isPhaseBasedContent && (
              <div className="mb-4 p-4 bg-blue-50 border border-blue-100 rounded-md">
                <h3 className="text-blue-800 font-semibold mb-1 flex items-center">
                  <i className="ri-information-line text-blue-600 mr-1.5"></i>
                  Final Review Content
                </h3>
                <p className="text-sm text-blue-700 mb-2">
                  The review below is the final output from the 5-phase analysis process. Only the final review content is shown.
                </p>
                <p className="text-xs text-blue-600 mt-2">
                  The complete 5-phase analysis process is still being used, but only the final result is displayed for clarity.
                </p>
              </div>
            )}
            <div className="prose max-w-none" dangerouslySetInnerHTML={{ 
              __html: finalContent
            }}></div>
          </>
        )}

        {reviewContent && activeTab === "html" && (
          <div className="font-mono text-sm whitespace-pre-wrap bg-gray-50 p-6 rounded-lg border border-gray-200 h-full overflow-auto">
            <div className="flex justify-end mb-2">
              <button
                onClick={handleCopyToClipboard}
                className="flex items-center gap-1 text-xs bg-white border border-gray-200 px-2 py-1 rounded text-gray-600 hover:bg-gray-50"
              >
                <i className="ri-file-copy-line"></i> Copy HTML
              </button>
            </div>
            <pre className="text-gray-800">
              {finalContent}
            </pre>
          </div>
        )}

      </div>
    </div>
  );
}
