import { useState, useEffect, useRef } from "react";
import ConfigPanel from "@/components/ConfigPanel";
import ProductInfoPanel from "@/components/ProductInfoPanel";
import ReviewOptionsPanel from "@/components/ReviewOptionsPanel";
import OutputPanel from "@/components/OutputPanel";
import ElementsPanel from "@/components/ElementsPanel";
import SeoOptionsPanel from "@/components/SeoOptionsPanel";
import ThemeSelectionPanel from "@/components/ThemeSelectionPanel";
import AdvancedFeaturesPanel from "@/components/AdvancedFeaturesPanel";
import TemplateManagerPanel from "@/components/TemplateManagerPanel";
import SeoAnalysisPanel from "@/components/SeoAnalysisPanel";
import ProductImagesPanel from "@/components/ProductImagesPanel";
import { ChatDialog } from "@/components/ChatDialog";
import { useToast } from "@/hooks/use-toast";
import { FormData, ReviewResponse, ProductImage } from "@/lib/types";
import { useLocalStorage } from "@/lib/storage";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";

export default function Home() {
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  const [reviewContent, setReviewContent] = useState<ReviewResponse | null>(null);
  const [activeTab, setActiveTab] = useState<"review" | "html">("review");
  const [activeSettingsTab, setActiveSettingsTab] = useState<"basic" | "advanced" | "templates">("basic");
  const [showSeoOptions, setShowSeoOptions] = useState(false);
  const [showThemeOptions, setShowThemeOptions] = useState(false);
  const [showConfigOptions, setShowConfigOptions] = useState(false);
  const [showProductDetails, setShowProductDetails] = useState(false);
  const [showReviewSettings, setShowReviewSettings] = useState(false);
  const [error, setError] = useState<string | undefined>();
  const [isChatOpen, setIsChatOpen] = useState(false);
  
  // Welcome tour states
  const [showWelcomeTour, setShowWelcomeTour] = useState(false);
  const [tourStep, setTourStep] = useState(0);
  const [hasSeenWelcomeTour, setHasSeenWelcomeTour] = useState(() => {
    return localStorage.getItem('hasSeenWelcomeTour') === 'true';
  });
  
  // Tour animation references
  const configPanelRef = useRef<HTMLDivElement>(null);
  const productDetailsRef = useRef<HTMLDivElement>(null);
  const reviewSettingsRef = useRef<HTMLDivElement>(null);
  const chatButtonRef = useRef<HTMLButtonElement>(null);
  
  // Tour steps content
  const tourSteps = [
    {
      title: "Welcome to JVZoo Review Generator PRO",
      description: "Let's take a quick tour of the key features to help you get started creating professional product reviews!",
      target: null
    },
    {
      title: "Setup Your API Key",
      description: "First, enter your Google AI Studio API key in the Configuration panel. This lets you connect to AI services that power your review generation.",
      target: configPanelRef
    },
    {
      title: "Enter Product Details",
      description: "Add your product information in the Product Details panel. Include name, description, offer link, and JV doc for more accurate and relevant reviews.",
      target: productDetailsRef
    },
    {
      title: "Choose Basic Content Options",
      description: "Select your review style, tone, and customize which sections to include in your review (pricing tables, pros/cons, etc.).",
      target: reviewSettingsRef
    },
    {
      title: "Explore Advanced Features",
      description: "Try advanced options like comparison tables, testimonials, and bonus sections to create more compelling reviews.",
      target: reviewSettingsRef
    },
    {
      title: "Save Templates for Later",
      description: "Save your favorite configuration as a template to quickly generate similar reviews in the future.",
      target: reviewSettingsRef
    },
    {
      title: "Optimize for SEO",
      description: "Add target keywords and SEO options to make your review more visible in search engines.",
      target: reviewSettingsRef
    },
    {
      title: "Theme Selection",
      description: "Choose from different visual themes to customize the appearance of your generated review.",
      target: reviewSettingsRef
    },
    {
      title: "Generate and Preview",
      description: "After configuring options, click 'Generate Professional Review' to create your review, then preview it in both visual and HTML formats.",
      target: null
    },
    {
      title: "Need Help Anytime?",
      description: "Click this chat button whenever you need assistance or have questions about the platform. Our smart assistant is ready to help!",
      target: chatButtonRef
    }
  ];
  
  // Show the welcome tour for new users
  useEffect(() => {
    if (!hasSeenWelcomeTour) {
      // Short delay to ensure UI is fully loaded
      const timer = setTimeout(() => {
        setShowWelcomeTour(true);
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [hasSeenWelcomeTour]);
  
  // Mark welcome tour as completed
  const completeTour = () => {
    setShowWelcomeTour(false);
    setHasSeenWelcomeTour(true);
    localStorage.setItem('hasSeenWelcomeTour', 'true');
  };
  
  // Navigate through tour steps
  const nextTourStep = () => {
    if (tourStep < tourSteps.length - 1) {
      setTourStep(tourStep + 1);
    } else {
      completeTour();
    }
  };
  
  const prevTourStep = () => {
    if (tourStep > 0) {
      setTourStep(tourStep - 1);
    }
  };
  
  // Load initial form data from local storage
  const [savedApiKey, setSavedApiKey] = useLocalStorage<string>("apiKey", "");
  const [savedModel, setSavedModel] = useLocalStorage<string>("aiModel", "gemini-2.5-pro-exp");
  
  // Form data state that will be used to generate the review
  const [formData, setFormData] = useState<FormData>({
    apiKey: savedApiKey,
    model: savedModel,
    productName: "",
    productDescription: "",
    offerLink: "",
    jvDoc: "",
    affiliateLink: "",
    bundleLink: "",
    reviewStyle: "balanced",
    toneStyle: "professional",
    includePricingTable: true,
    includeProsConsSection: true,
    includeCtaBanner: true,
    includeProductImages: true,
    includeFaqSection: false,
    
    // SEO and Keyword Options
    targetKeyword: "",
    secondaryKeywords: "",
    includeTableOfContents: true,
    
    // Theme Configuration
    reviewTheme: "classic",
    
    // Enhanced Content Elements 
    includeComparisonTable: false,
    includeTestimonials: false,
    includeProductRating: true,
    productRatingScore: "4.5",
    competingProducts: "",
    includeBonusSection: false,
    bonusContent: "",
    
    // Product Images
    productImagesList: [],
    
    // Advanced Professional Features (New)
    usePhaseApproach: false,
    useMarketingCopywriting: false,
    extendedWordCount: false,
    includeSeoSchema: false
  });

  // Update form data handler
  const updateFormData = (data: Partial<FormData>) => {
    setFormData({
      ...formData,
      ...data,
    });
  };

  // Save API configuration
  const saveApiConfig = () => {
    setSavedApiKey(formData.apiKey);
    setSavedModel(formData.model);
    toast({
      title: "Configuration saved",
      description: "Your API configuration has been saved",
    });
  };

  // Handle loading a template
  const handleLoadTemplate = (templateData: Partial<FormData>) => {
    setFormData({
      ...formData,
      ...templateData
    });
  };
  
  // Handle product images update
  const updateProductImages = (images: ProductImage[]) => {
    setFormData({
      ...formData,
      productImagesList: images
    });
  };

  // Handle generate review
  const handleGenerateReview = async () => {
    try {
      // Clear any previous errors and content
      setError(undefined);
      setIsGenerating(true);
      
      // Enhanced validation with clear field requirements
      const requiredFields = [
        { field: 'apiKey', label: 'API Key', message: 'Please enter your Google AI Studio API key in the configuration panel.' },
        { field: 'productName', label: 'Product Name', message: 'Please enter a name for the product you want to review.' },
      ];
      
      for (const { field, label, message } of requiredFields) {
        if (!formData[field as keyof FormData]) {
          toast({
            title: `${label} Required`,
            description: message,
            variant: "destructive",
          });
          setError(`${label} is required. ${message}`);
          setIsGenerating(false);
          return;
        }
      }
      
      // Advanced validation for conditional fields
      if (formData.includeComparisonTable && !formData.competingProducts) {
        toast({
          title: "Competing Products Required",
          description: "Please enter competing products for comparison table or disable the comparison table option.",
          variant: "destructive",
        });
        setError("Competing Products are required when Comparison Table is enabled.");
        setIsGenerating(false);
        return;
      }
      
      if (formData.includeBonusSection && !formData.bonusContent) {
        toast({
          title: "Bonus Content Required",
          description: "Please enter bonus content details or disable the bonus section option.",
          variant: "destructive",
        });
        setError("Bonus Content details are required when Bonus Section is enabled.");
        setIsGenerating(false);
        return;
      }

      const response = await fetch("/api/generate-review", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        const errorMessage = errorData.message || "Failed to generate review"; 
        const errorDetails = errorData.error || "";
        const errorSuggestion = errorData.suggestion || "";
        
        // Create a comprehensive error message
        const fullErrorMessage = [
          errorMessage,
          errorDetails ? `Details: ${errorDetails}` : "",
          errorSuggestion ? `Suggestion: ${errorSuggestion}` : ""
        ].filter(Boolean).join("\n\n");
        
        throw new Error(fullErrorMessage);
      }

      const data = await response.json();
      
      // Validate the response
      if (!data.success || !data.content) {
        throw new Error("The API response was successful but did not contain valid review content. Please try again.");
      }
      
      // Set the review content and clear any errors
      setReviewContent(data);
      setError(undefined);
      
      // Auto-switch to the review tab after generation
      setActiveTab("review");
      
      toast({
        title: "Review Generated",
        description: "Your review has been successfully generated",
      });
    } catch (error) {
      // Set the error state for display in the OutputPanel
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
      setError(errorMessage);
      
      // Show a toast notification
      toast({
        title: "Generation Failed",
        description: "Review generation failed. See details in the output panel.",
        variant: "destructive",
      });
      
      // Clear any previous review content as it might be partial or invalid
      setReviewContent(null);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-0 max-w-7xl">
      {/* Floating Chat Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <button
          ref={chatButtonRef}
          onClick={() => setIsChatOpen(true)}
          className="w-14 h-14 bg-indigo-600 hover:bg-indigo-700 rounded-full shadow-lg flex items-center justify-center text-white transition-all hover:scale-105 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          aria-label="Open chat"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
        </button>
      </div>
      
      {/* Chat Dialog */}
      <ChatDialog isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
      
      <div className="flex flex-col lg:flex-row gap-6 mt-6">
        {/* Left sidebar matching the provided designs */}
        <div className="lg:w-1/3 w-full">
          <div className="sticky top-4 overflow-auto max-h-[calc(100vh-2rem)]">
            {/* API Configuration */}
            <div ref={configPanelRef} className="mb-4 bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="p-3 bg-indigo-600 text-white flex items-center justify-between">
                <div className="flex items-center">
                  <div className="h-6 w-6 bg-white rounded-md flex items-center justify-center mr-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <span className="font-medium text-sm">Configuration</span>
                </div>
                <button 
                  onClick={() => setShowConfigOptions(!showConfigOptions)}
                  className="text-xs text-white font-medium flex items-center"
                >
                  {showConfigOptions ? 'Hide' : 'Show'}
                  <svg 
                    className={`h-4 w-4 ml-1 transition-transform ${showConfigOptions ? 'rotate-180' : ''}`} 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
              {showConfigOptions && (
                <div className="p-4">
                  <ConfigPanel 
                    apiKey={formData.apiKey}
                    model={formData.model}
                    updateFormData={updateFormData}
                    saveConfig={saveApiConfig}
                  />
                </div>
              )}
            </div>

            {/* Product Information */}
            <div ref={productDetailsRef} className="mb-4 bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="p-3 bg-indigo-600 text-white flex items-center justify-between">
                <div className="flex items-center">
                  <div className="h-6 w-6 bg-white rounded-md flex items-center justify-center mr-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                  </div>
                  <span className="font-medium text-sm">Product Details</span>
                </div>
                <button 
                  onClick={() => setShowProductDetails(!showProductDetails)}
                  className="text-xs text-white font-medium flex items-center"
                >
                  {showProductDetails ? 'Hide' : 'Show'}
                  <svg 
                    className={`h-4 w-4 ml-1 transition-transform ${showProductDetails ? 'rotate-180' : ''}`} 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
              {showProductDetails && (
                <div className="p-4">
                  <ProductInfoPanel
                    productName={formData.productName}
                    productDescription={formData.productDescription}
                    offerLink={formData.offerLink}
                    jvDoc={formData.jvDoc}
                    affiliateLink={formData.affiliateLink}
                    bundleLink={formData.bundleLink}
                    updateFormData={updateFormData}
                  />
                </div>
              )}
            </div>

            {/* Review Settings Panel with Tab Navigation */}
            <div ref={reviewSettingsRef} className="mb-4 bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="p-3 bg-indigo-600 text-white flex items-center justify-between">
                <div className="flex items-center">
                  <div className="h-6 w-6 bg-white rounded-md flex items-center justify-center mr-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                    </svg>
                  </div>
                  <span className="font-medium text-sm">Review Settings</span>
                </div>
                <button 
                  onClick={() => setShowReviewSettings(!showReviewSettings)}
                  className="text-xs text-white font-medium flex items-center"
                >
                  {showReviewSettings ? 'Hide' : 'Show'}
                  <svg 
                    className={`h-4 w-4 ml-1 transition-transform ${showReviewSettings ? 'rotate-180' : ''}`} 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>
              {showReviewSettings && (
                <div>
                {/* Clean horizontal tabs matching the provided design */}
                <div className="flex border-b border-gray-200 bg-gray-50">
                  <button
                    className={`flex-1 py-2 px-4 text-sm font-medium ${activeSettingsTab === "basic" ? "text-indigo-600 border-b-2 border-indigo-600 bg-white" : "text-gray-500"}`}
                    onClick={() => setActiveSettingsTab("basic")}
                  >
                    Basic
                  </button>
                  <button
                    className={`flex-1 py-2 px-4 text-sm font-medium ${activeSettingsTab === "advanced" ? "text-indigo-600 border-b-2 border-indigo-600 bg-white" : "text-gray-500"}`}
                    onClick={() => setActiveSettingsTab("advanced")}
                  >
                    Advanced
                  </button>
                  <button
                    className={`flex-1 py-2 px-4 text-sm font-medium ${activeSettingsTab === "templates" ? "text-indigo-600 border-b-2 border-indigo-600 bg-white" : "text-gray-500"}`}
                    onClick={() => setActiveSettingsTab("templates")}
                  >
                    Templates
                  </button>
                </div>
                
                {/* Basic Tab Content - Based on screenshot */}
                {activeSettingsTab === "basic" && (
                  <div className="p-4">
                    <div className="mb-4">
                      <h4 className="text-sm font-medium text-gray-800 mb-3">Content Options</h4>
                      
                      <div className="mb-3">
                        <label className="flex items-center justify-between text-sm font-medium text-gray-700 mb-1">
                          Review Style
                        </label>
                        <ReviewOptionsPanel
                          reviewStyle={formData.reviewStyle}
                          toneStyle={formData.toneStyle}
                          includePricingTable={formData.includePricingTable}
                          includeProsConsSection={formData.includeProsConsSection}
                          includeCtaBanner={formData.includeCtaBanner}
                          includeProductImages={formData.includeProductImages}
                          includeFaqSection={formData.includeFaqSection}
                          includeIntroduction={formData.includeIntroduction}
                          includeCaseStudy={formData.includeCaseStudy}
                          includeConclusion={formData.includeConclusion}
                          usePhaseApproach={formData.usePhaseApproach || false}
                          useMarketingCopywriting={formData.useMarketingCopywriting || false}
                          extendedWordCount={formData.extendedWordCount || false}
                          includeSeoSchema={formData.includeSeoSchema || false}
                          productImagesList={formData.productImagesList}
                          updateFormData={updateFormData}
                          handleGenerateReview={handleGenerateReview}
                          isGenerating={isGenerating}
                        />
                      </div>
                    </div>
                    
                    {/* Theme Selection Panel - Based on screenshot */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium text-gray-800">Theme Selection</h4>
                        <button 
                          onClick={() => setShowThemeOptions(!showThemeOptions)}
                          className="text-xs text-indigo-600 font-medium flex items-center"
                        >
                          {showThemeOptions ? 'Hide Options' : 'Show Options'}
                          <svg 
                            className={`h-4 w-4 ml-1 transition-transform ${showThemeOptions ? 'rotate-180' : ''}`} 
                            fill="none" 
                            viewBox="0 0 24 24" 
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                          </svg>
                        </button>
                      </div>
                      {showThemeOptions && (
                        <ThemeSelectionPanel
                          reviewTheme={formData.reviewTheme || "classic"}
                          updateFormData={updateFormData}
                        />
                      )}
                    </div>
                    
                    {/* SEO Options - Clean design as in the screenshot */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-sm font-medium text-gray-800">SEO Options</h4>
                        <button 
                          onClick={() => setShowSeoOptions(!showSeoOptions)}
                          className="text-xs text-indigo-600 font-medium flex items-center"
                        >
                          {showSeoOptions ? 'Hide Options' : 'Show Options'}
                          <svg 
                            className={`h-4 w-4 ml-1 transition-transform ${showSeoOptions ? 'rotate-180' : ''}`} 
                            fill="none" 
                            viewBox="0 0 24 24" 
                            stroke="currentColor"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                          </svg>
                        </button>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3 flex items-start">
                        <div className="h-5 w-5 rounded-full bg-indigo-100 flex-shrink-0 flex items-center justify-center text-indigo-600 mt-0.5 mr-2">
                          <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        </div>
                        <div>
                          <h5 className="text-sm font-medium text-gray-800">SEO Optimization</h5>
                          <p className="text-xs text-gray-500">Automatically optimize for search engines</p>
                        </div>
                      </div>
                      
                      {showSeoOptions && (
                        <div className="mt-3 p-3 border border-gray-200 rounded-lg bg-white">
                          <SeoOptionsPanel
                            targetKeyword={formData.targetKeyword || ""}
                            secondaryKeywords={formData.secondaryKeywords || ""}
                            includeTableOfContents={formData.includeTableOfContents || false}
                            metaDescription={formData.metaDescription || ""}
                            focusKeyphrase={formData.focusKeyphrase || ""}
                            includeSeoMetaTags={formData.includeSeoMetaTags || true}
                            includeStructuredData={formData.includeStructuredData || true}
                            includeOpenGraph={formData.includeOpenGraph || true}
                            includeTwitterCard={formData.includeTwitterCard || true}
                            includeCanonicalUrl={formData.includeCanonicalUrl || true}
                            optimizeSlugs={formData.optimizeSlugs || true}
                            optimizeImages={formData.optimizeImages || true}
                            keywordSynonyms={formData.keywordSynonyms || ""}
                            includeFaq={formData.includeFaq || false}
                            includeHowTo={formData.includeHowTo || false}
                            longTailKeywords={formData.longTailKeywords || ""}
                            keywordPosition={formData.keywordPosition || "balanced"}
                            keywordDensity={formData.keywordDensity || 1.5}
                            targetSearchIntent={formData.targetSearchIntent || "informational"}
                            targetFeaturedSnippet={formData.targetFeaturedSnippet || true}
                            updateFormData={updateFormData}
                          />
                        </div>
                      )}
                    </div>
                    
                    {/* Generate Review Button - Placed below SEO Options */}
                    <div className="mt-6 mb-2">
                      <Button
                        onClick={handleGenerateReview}
                        disabled={isGenerating}
                        className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 shadow-sm flex items-center justify-center gap-2"
                      >
                        {isGenerating ? (
                          <>
                            <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Generating...
                          </>
                        ) : (
                          <>
                            <i className="ri-magic-line"></i>
                            <span>Generate Professional Review</span>
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                )}
                
                {/* Advanced Settings Tab */}
                {activeSettingsTab === "advanced" && (
                  <div className="p-4">
                    <div className="mb-4">
                      <AdvancedFeaturesPanel
                        includeComparisonTable={formData.includeComparisonTable || false}
                        competingProducts={formData.competingProducts || ""}
                        includeTestimonials={formData.includeTestimonials || false}
                        includeProductRating={formData.includeProductRating || true}
                        productRatingScore={formData.productRatingScore || "4.5"}
                        includeBonusSection={formData.includeBonusSection || false}
                        bonusContent={formData.bonusContent || ""}
                        updateFormData={updateFormData}
                      />
                    </div>
                  </div>
                )}
                
                {/* Templates Tab */}
                {activeSettingsTab === "templates" && (
                  <div className="p-4">
                    <TemplateManagerPanel
                      formData={formData}
                      onLoadTemplate={handleLoadTemplate}
                    />
                  </div>
                )}
              </div>
              )}
            </div>
            
          </div>
        </div>
        
        {/* Main content area */}
        <div className="flex-1">
          <div className="space-y-6">
            {/* Review Output Panel */}
            <div className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-blue-600 to-indigo-700 flex justify-between items-center">
                <h2 className="text-lg font-bold text-white flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                  </svg>
                  Review Preview
                </h2>
                
                {/* View options */}
                <div className="flex bg-blue-700 p-1 rounded-lg">
                  <button 
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${activeTab === "review" ? "bg-white text-blue-700" : "text-white hover:bg-blue-600"}`}
                    onClick={() => setActiveTab("review")}
                  >
                    Preview
                  </button>
                  <button 
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${activeTab === "html" ? "bg-white text-blue-700" : "text-white hover:bg-blue-600"}`}
                    onClick={() => setActiveTab("html")}
                  >
                    HTML
                  </button>
                </div>
              </div>
              
              <OutputPanel
                reviewContent={reviewContent}
                isGenerating={isGenerating}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                error={error}
              />
            </div>
            
            {/* SEO Analysis Panel (only shown when review is generated) */}
            {reviewContent && (
              <div className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
                <div className="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-blue-600 to-indigo-700">
                  <h2 className="text-lg font-bold text-white flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="11" cy="11" r="8"></circle>
                      <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                    SEO Analysis
                  </h2>
                </div>
                <div className="p-6">
                  <SeoAnalysisPanel
                    reviewContent={reviewContent.content}
                    targetKeyword={formData.targetKeyword || ""}
                    focusKeyphrase={formData.focusKeyphrase || ""}
                    keywordSynonyms={formData.keywordSynonyms || ""}
                    secondaryKeywords={formData.secondaryKeywords || ""}
                    longTailKeywords={formData.longTailKeywords || ""}
                    metaDescription={formData.metaDescription || ""}
                    includeStructuredData={formData.includeStructuredData || true}
                  />
                </div>
              </div>
            )}
            
            {/* Review Elements Panel */}
            <div className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-blue-600 to-indigo-700">
                <h2 className="text-lg font-bold text-white flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="3" y1="9" x2="21" y2="9"></line>
                    <line x1="9" y1="21" x2="9" y2="9"></line>
                  </svg>
                  Review Elements
                </h2>
              </div>
              <div className="p-6">
                <ElementsPanel />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Welcome Tour Dialog */}
      <Dialog open={showWelcomeTour} onOpenChange={completeTour}>
        <DialogContent className="sm:max-w-[500px] p-0 overflow-hidden">
          <div className="bg-gradient-to-r from-indigo-600 to-indigo-800 p-6">
            <DialogHeader>
              <DialogTitle className="text-xl text-white flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                {tourSteps[tourStep].title}
              </DialogTitle>
              <DialogDescription className="text-indigo-100 mt-2">
                {tourSteps[tourStep].description}
              </DialogDescription>
            </DialogHeader>
          </div>
          
          <div className="p-6">
            <div className="h-12 flex items-center">
              {/* Tour progress indicator */}
              <div className="flex-1 flex space-x-1">
                {tourSteps.map((_, index) => (
                  <div 
                    key={index} 
                    className={`h-1.5 rounded-full flex-1 ${index <= tourStep ? 'bg-indigo-600' : 'bg-gray-200'}`}
                  />
                ))}
              </div>
            </div>
          </div>
          
          <DialogFooter className="px-6 pb-6 pt-0">
            <div className="flex w-full justify-between">
              <Button
                variant="outline"
                onClick={prevTourStep}
                disabled={tourStep === 0}
                className={tourStep === 0 ? 'opacity-50 cursor-not-allowed' : ''}
              >
                Previous
              </Button>
              <Button onClick={nextTourStep}>
                {tourStep < tourSteps.length - 1 ? 'Next' : 'Get Started'}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Adding bottom padding */}
      <div className="pb-16"></div>
    </div>
  );
}
