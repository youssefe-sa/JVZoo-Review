import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { verifyApiKey } from "@/lib/api";

interface ConfigPanelProps {
  apiKey: string;
  model: string;
  updateFormData: (data: { apiKey?: string; model?: string }) => void;
  saveConfig: () => void;
}

export default function ConfigPanel({ apiKey, model, updateFormData, saveConfig }: ConfigPanelProps) {
  // When component mounts, ensure the model is set to the recommended default
  useEffect(() => {
    if (!model || model !== "gemini-2.5-pro-exp") {
      updateFormData({ model: "gemini-2.5-pro-exp" });
    }
  }, []);
  const { toast } = useToast();
  const [showApiKey, setShowApiKey] = useState(false);
  const [isTestingConnection, setIsTestingConnection] = useState(false);

  const handleToggleApiKey = () => {
    setShowApiKey(!showApiKey);
  };

  const handleTestConnection = async () => {
    if (!apiKey) {
      toast({
        title: "API Key Required",
        description: "Please enter your Google AI Studio API key",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsTestingConnection(true);
      const result = await verifyApiKey(apiKey, model);
      
      if (result.success) {
        toast({
          title: "Connection Successful",
          description: "Your API key is valid and working",
        });
      } else {
        toast({
          title: "Connection Failed",
          description: result.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Connection Test Failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsTestingConnection(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="p-5 border-b border-gray-100">
        <div className="flex items-center">
          <i className="ri-key-2-line text-lg text-indigo-600 mr-2"></i>
          <h2 className="text-lg font-semibold text-gray-800">API Configuration</h2>
        </div>
      </div>
      
      <div className="p-5">
        {/* API Key Input */}
        <div className="mb-5">
          <div className="flex items-center justify-between mb-1">
            <label htmlFor="apiKey" className="block text-sm font-medium text-gray-700">
              Google AI Studio API Key
            </label>
            <a 
              href="https://aistudio.google.com/app/apikey" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-xs text-indigo-600 hover:text-indigo-800 flex items-center transition-all"
            >
              <i className="ri-external-link-line mr-1"></i>
              Get API Key
            </a>
          </div>
          <div className="relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <i className="ri-key-2-line text-gray-400"></i>
            </div>
            <input 
              type={showApiKey ? "text" : "password"}
              id="apiKey"
              value={apiKey}
              onChange={(e) => updateFormData({ apiKey: e.target.value })}
              className="w-full pl-10 pr-10 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
              placeholder="Enter your Google AI Studio API key"
            />
            <button 
              type="button"
              onClick={handleToggleApiKey}
              className="absolute right-3 top-2.5 text-gray-500 hover:text-gray-700 transition-all"
            >
              <i className={`ri-${showApiKey ? 'eye-off' : 'eye'}-line`}></i>
            </button>
          </div>
          <div className="mt-2 bg-blue-50 text-blue-800 text-xs p-2 rounded-md flex items-start">
            <i className="ri-information-line mr-1.5 mt-0.5"></i>
            <div className="flex-1">
              <p className="font-medium">Your API key:</p>
              <ul className="mt-1 list-disc list-inside">
                <li>Is stored only in your browser</li>
                <li>Is required to generate reviews</li>
                <li>Can be obtained from Google AI Studio for free</li>
              </ul>
            </div>
          </div>
        </div>

        {/* AI Model Selection */}
        <div className="mb-4">
          <label htmlFor="aiModel" className="block text-sm font-medium text-gray-700 mb-1">
            Google AI Studio Model
          </label>
          <div className="relative">
            <select 
              id="aiModel"
              value={model}
              onChange={(e) => updateFormData({ model: e.target.value })}
              className="w-full appearance-none bg-white px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
            >
              <option value="gemini-2.5-pro-exp">Gemini 2.5 Pro Experimental - Most Advanced (Default)</option>
              <option value="gemini-2.0-flash">Gemini 2.0 Flash - Fast Performance</option>
              <option value="gemini-1.5-pro">Gemini 1.5 Pro - Good Performance</option>
              <option value="gemini-1.5-flash">Gemini 1.5 Flash - Balanced Performance</option>
              <option value="gemini-1.0-pro">Gemini Pro Vision - Standard Quality</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-gray-500">
              <i className="ri-arrow-down-s-line"></i>
            </div>
          </div>
          <div className="mt-1">
            <div className="flex items-center mb-1">
              <div className="h-2 w-2 rounded-full bg-green-500 mr-2"></div>
              <p className="text-xs text-gray-700">
                <strong>Pro Tip:</strong> Gemini 2.5 Pro Experimental provides the most detailed and comprehensive reviews
              </p>
            </div>
            <div className="flex items-center">
              <div className="h-2 w-2 rounded-full bg-yellow-500 mr-2"></div>
              <p className="text-xs text-gray-600">For advanced options like 5-phase analysis, the Gemini 2.5 Pro Experimental model is set as the default</p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-100 pt-4 mt-4">
          <div className="bg-gray-50 rounded-lg p-3 mb-4 flex items-start">
            <i className="ri-lightbulb-line text-amber-500 mt-0.5 mr-2 text-lg"></i>
            <p className="text-xs text-gray-700 leading-relaxed">
              <strong className="font-medium">Getting Started:</strong> Enter your Google AI Studio API key. The Gemini 2.5 Pro Experimental model is already selected by default for the best results. Click "Test Connection" to verify your API key is working properly, then save your configuration.
            </p>
          </div>
          <div className="flex items-center justify-between gap-3">
            <button 
              onClick={saveConfig}
              className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all shadow-sm flex-1 whitespace-nowrap"
            >
              <i className="ri-save-line"></i>Save Configuration
            </button>
            <button 
              onClick={handleTestConnection}
              disabled={isTestingConnection}
              className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-gray-100 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-all flex-1 whitespace-nowrap"
            >
              {isTestingConnection ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-gray-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Testing...
                </>
              ) : (
                <>
                  <i className="ri-check-double-line"></i>Test Connection
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
