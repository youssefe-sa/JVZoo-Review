import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { 
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Tabs,
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { apiRequest } from '../../lib/api';
import { CheckIcon } from '@heroicons/react/24/outline';

interface Plan {
  id: number;
  name: string;
  description: string;
  price: string;
  billingCycle: 'monthly' | 'yearly';
  features: string[];
}

export default function PlanSelect() {
  const [, setLocation] = useLocation();
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [plans, setPlans] = useState<Plan[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Handle URL parameters for pre-selecting plans and billing cycle
  useEffect(() => {
    // Parse URL query parameters
    const params = new URLSearchParams(window.location.search);
    const cycleParam = params.get('cycle');
    const planParam = params.get('plan');
    
    // Set billing cycle from URL if available
    if (cycleParam === 'monthly' || cycleParam === 'yearly') {
      setBillingCycle(cycleParam);
    }
    
    // Store the plan name to select after loading
    if (planParam) {
      // We'll match this with plan names after loading
      sessionStorage.setItem('preSelectedPlan', planParam);
    }
  }, []);

  // Fetch subscription plans from the server
  useEffect(() => {
    const fetchPlans = async () => {
      try {
        setIsLoading(true);
        const response = await apiRequest('/api/subscription-plans');
        
        if (response.success) {
          // Process the plans data
          const planData = response.plans.map((plan: any) => ({
            id: plan.id,
            name: plan.name,
            description: plan.description,
            price: plan.price,
            billingCycle: plan.billingCycle,
            features: typeof plan.features === 'string' 
              ? JSON.parse(plan.features) 
              : plan.features
          }));
          setPlans(planData);
        } else {
          console.error('Failed to load plans:', response.message);
          
          // Fallback plans if API fails
          setPlans([
            // Monthly plans
            {
              id: 1,
              name: 'Basic Plan',
              description: 'Essential features for small businesses and individual creators',
              price: '49.99',
              billingCycle: 'monthly',
              features: [
                'Generate up to 5 reviews per month',
                'Basic SEO optimization',
                'Standard templates',
                'Email support'
              ]
            },
            {
              id: 2,
              name: 'Pro Plan',
              description: 'Advanced features for growing businesses and professional marketers',
              price: '99.99',
              billingCycle: 'monthly',
              features: [
                'Generate up to 20 reviews per month',
                'Advanced SEO optimization',
                'Premium templates',
                'Priority email support',
                'Review analytics',
                'Multi-platform publishing'
              ]
            },
            {
              id: 3,
              name: 'Agency Plan',
              description: 'Complete solution for agencies and enterprise clients',
              price: '249.99',
              billingCycle: 'monthly',
              features: [
                'Generate unlimited reviews',
                'Enterprise-grade SEO optimization',
                'Custom templates',
                'Dedicated account manager',
                'Advanced analytics dashboard',
                'White-label options',
                'API access',
                'Multi-user accounts'
              ]
            },
            // Yearly plans (with discount)
            {
              id: 4,
              name: 'Basic Plan',
              description: 'Essential features for small businesses and individual creators',
              price: '499.99',
              billingCycle: 'yearly',
              features: [
                'Generate up to 5 reviews per month',
                'Basic SEO optimization',
                'Standard templates',
                'Email support',
                'Save 16% compared to monthly billing'
              ]
            },
            {
              id: 5,
              name: 'Pro Plan',
              description: 'Advanced features for growing businesses and professional marketers',
              price: '999.99',
              billingCycle: 'yearly',
              features: [
                'Generate up to 20 reviews per month',
                'Advanced SEO optimization',
                'Premium templates',
                'Priority email support',
                'Review analytics',
                'Multi-platform publishing',
                'Save 16% compared to monthly billing'
              ]
            },
            {
              id: 6,
              name: 'Agency Plan',
              description: 'Complete solution for agencies and enterprise clients',
              price: '2499.99',
              billingCycle: 'yearly',
              features: [
                'Generate unlimited reviews',
                'Enterprise-grade SEO optimization',
                'Custom templates',
                'Dedicated account manager',
                'Advanced analytics dashboard',
                'White-label options',
                'API access',
                'Multi-user accounts',
                'Save 16% compared to monthly billing'
              ]
            }
          ]);
        }
      } catch (error) {
        console.error('Error fetching plans:', error);
        // Add fallback plans here (same as above)
      } finally {
        setIsLoading(false);
      }
    };

    fetchPlans();
  }, []);
  
  // Navigate to payment page for the selected plan
  const selectPlan = (plan: Plan) => {
    // Store plan details in session storage for the payment page
    sessionStorage.setItem('selectedPlan', JSON.stringify({
      id: plan.id,
      name: plan.name,
      price: plan.price,
      billingCycle: plan.billingCycle,
      description: plan.description,
      features: plan.features
    }));
    
    // Navigate to the payment page
    setLocation(`/payment/${plan.billingCycle}/${plan.id}`);
  };
  
  // Auto-select plan from URL parameters
  useEffect(() => {
    if (!isLoading && plans.length > 0) {
      // Check if there's a pre-selected plan from URL parameters
      const preSelectedPlan = sessionStorage.getItem('preSelectedPlan');
      if (preSelectedPlan) {
        // Find the matching plan by name (case-insensitive)
        const planName = preSelectedPlan.toLowerCase();
        const matchingPlan = plans.find(plan => 
          plan.name.toLowerCase().includes(planName) || 
          planName.includes(plan.name.toLowerCase())
        );
        
        if (matchingPlan) {
          // Auto-select this plan
          selectPlan(matchingPlan);
          // Clear the pre-selection
          sessionStorage.removeItem('preSelectedPlan');
        }
      }
    }
  }, [isLoading, plans]);

  // Filter plans by billing cycle
  const filteredPlans = plans.filter(plan => plan.billingCycle === billingCycle);

  // Get the most popular plan (middle one, index 1)
  const getPopularPlanIndex = () => {
    if (filteredPlans.length <= 1) return -1;
    if (filteredPlans.length === 2) return 0;
    return 1; // Middle plan for 3 or more plans
  };

  // Calculate yearly savings percentage
  const calculateYearlySavings = () => {
    const monthlyPlans = plans.filter(plan => plan.billingCycle === 'monthly');
    const yearlyPlans = plans.filter(plan => plan.billingCycle === 'yearly');
    
    if (monthlyPlans.length > 0 && yearlyPlans.length > 0) {
      const monthlyPlan = monthlyPlans[0];
      const yearlyPlan = yearlyPlans[0];
      
      const monthlyCost = parseFloat(monthlyPlan.price) * 12;
      const yearlyCost = parseFloat(yearlyPlan.price);
      
      return Math.round(((monthlyCost - yearlyCost) / monthlyCost) * 100);
    }
    
    return 16; // Default savings percentage
  };

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Choose Your Plan</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Select the perfect plan for your needs and start creating professional product reviews instantly
        </p>
      </div>
      
      {/* Billing Cycle Selector */}
      <Tabs 
        defaultValue="monthly" 
        value={billingCycle}
        onValueChange={(value) => setBillingCycle(value as 'monthly' | 'yearly')}
        className="w-full max-w-md mx-auto mb-12"
      >
        <TabsList className="grid w-full grid-cols-2 bg-gray-100">
          <TabsTrigger value="monthly">Monthly Billing</TabsTrigger>
          <TabsTrigger value="yearly">
            Yearly Billing 
            <span className="ml-2 text-xs font-medium bg-green-100 text-green-800 py-0.5 px-1.5 rounded-full">
              Save {calculateYearlySavings()}%
            </span>
          </TabsTrigger>
        </TabsList>
      </Tabs>
      
      {isLoading ? (
        <div className="flex justify-center py-20">
          <div className="animate-pulse text-center">
            <div className="h-4 bg-gray-200 rounded w-32 mb-4 mx-auto"></div>
            <div className="h-10 bg-gray-200 rounded w-48 mb-6 mx-auto"></div>
            <div className="h-40 bg-gray-200 rounded-lg w-full max-w-sm mx-auto"></div>
          </div>
        </div>
      ) : (
        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {filteredPlans.map((plan, index) => {
            const isPopular = index === getPopularPlanIndex();
            
            return (
              <div key={plan.id} className={`flex ${isPopular ? '-mt-4 mb-4' : ''}`}>
                <Card className={`flex flex-col border w-full ${isPopular ? 'border-primary shadow-lg' : ''} relative`}>
                  {isPopular && (
                    <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-primary text-white px-4 py-1 rounded-full text-sm font-medium">
                      Most Popular
                    </div>
                  )}
                  
                  <CardHeader>
                    <CardTitle className="text-2xl">{plan.name}</CardTitle>
                    <CardDescription>{plan.description}</CardDescription>
                    <div className="mt-4">
                      <span className="text-4xl font-bold">${plan.price}</span>
                      <span className="text-gray-500 ml-2">
                        /{plan.billingCycle === 'monthly' ? 'mo' : 'yr'}
                      </span>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="flex-grow">
                    <ul className="space-y-2">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start">
                          <CheckIcon className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  
                  <CardFooter>
                    <Button 
                      className={`w-full ${isPopular ? 'bg-primary hover:bg-primary/90' : ''}`}
                      onClick={() => selectPlan(plan)}
                    >
                      {isPopular ? 'Get Started Now' : 'Select Plan'}
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            );
          })}
        </div>
      )}
      
      <div className="mt-16 text-center">
        <p className="text-gray-600 mb-4">Need a custom solution for your business?</p>
        <Button variant="outline" onClick={() => setLocation('/contact')}>
          Contact Sales
        </Button>
      </div>
    </div>
  );
}