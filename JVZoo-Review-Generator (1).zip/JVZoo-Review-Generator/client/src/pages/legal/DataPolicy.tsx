import React from 'react';

export default function DataPolicy() {
  return (
    <div className="bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-10">
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl mb-4">Data Policy</h1>
          <p className="text-gray-500">Last updated: {new Date().toLocaleDateString()}</p>
        </div>

        <div className="prose prose-indigo max-w-none">
          <h2>1. Data Collection and Processing</h2>
          <p>
            At ReviewPro, we're committed to being transparent about how we collect and process your data. This Data Policy explains our practices regarding the collection, use, storage, and protection of your information.
          </p>
          
          <h2>2. Categories of Data We Process</h2>
          <p>
            We process the following categories of data:
          </p>
          <ul>
            <li><strong>Account Data:</strong> Information provided during registration (name, email, etc.)</li>
            <li><strong>Profile Data:</strong> Information you add to your profile</li>
            <li><strong>Content Data:</strong> Reviews, templates, and other content you create using our platform</li>
            <li><strong>Usage Data:</strong> Information about how you interact with our service</li>
            <li><strong>Technical Data:</strong> IP address, browser type, device information</li>
            <li><strong>Marketing Data:</strong> Your preferences in receiving marketing and communications</li>
          </ul>
          
          <h2>3. How We Process Your Data</h2>
          <p>
            We process your data for the following purposes:
          </p>
          <ul>
            <li>Providing and maintaining our service</li>
            <li>Improving and personalizing your experience</li>
            <li>Communicating with you about our services</li>
            <li>Managing your account and subscription</li>
            <li>Ensuring the security of our platform</li>
            <li>Complying with legal obligations</li>
            <li>Detecting and preventing fraudulent activities</li>
          </ul>
          
          <h2>4. Legal Basis for Processing</h2>
          <p>
            We process your data based on the following legal grounds:
          </p>
          <ul>
            <li><strong>Contract:</strong> Processing necessary for the performance of our contract with you</li>
            <li><strong>Consent:</strong> Processing based on your specific consent</li>
            <li><strong>Legitimate Interests:</strong> Processing necessary for our legitimate business interests</li>
            <li><strong>Legal Obligation:</strong> Processing necessary to comply with our legal obligations</li>
          </ul>
          
          <h2>5. Data Retention</h2>
          <p>
            We retain your data for as long as necessary to provide our services and fulfill the purposes outlined in this policy. We also retain and use your data as necessary to comply with legal obligations, resolve disputes, and enforce our agreements.
          </p>
          <p>
            The criteria used to determine our retention periods include:
          </p>
          <ul>
            <li>The duration of your user account</li>
            <li>The nature and sensitivity of the data</li>
            <li>Our legal and contractual obligations</li>
            <li>Industry standards and practices</li>
          </ul>
          
          <h2>6. Data Security</h2>
          <p>
            We implement appropriate security measures to protect your data against unauthorized access, alteration, disclosure, or destruction. These measures include:
          </p>
          <ul>
            <li>Encryption of data in transit and at rest</li>
            <li>Regular security assessments and audits</li>
            <li>Access controls and authentication procedures</li>
            <li>Staff training on data protection and security</li>
            <li>Physical and technical safeguards</li>
          </ul>
          
          <h2>7. Cross-Border Data Transfers</h2>
          <p>
            Your data may be transferred to, and processed in, countries other than the country in which you reside. These countries may have data protection laws that are different from the laws of your country.
          </p>
          <p>
            We ensure that any cross-border data transfers comply with applicable data protection laws and that appropriate safeguards are in place to protect your data.
          </p>
          
          <h2>8. Your Data Protection Rights</h2>
          <p>
            Depending on your location, you may have the following rights regarding your data:
          </p>
          <ul>
            <li><strong>Access:</strong> The right to access your personal data</li>
            <li><strong>Rectification:</strong> The right to correct inaccurate personal data</li>
            <li><strong>Erasure:</strong> The right to have your personal data deleted</li>
            <li><strong>Restriction:</strong> The right to restrict the processing of your personal data</li>
            <li><strong>Data Portability:</strong> The right to receive your personal data in a structured format</li>
            <li><strong>Objection:</strong> The right to object to the processing of your personal data</li>
            <li><strong>Automated Decision-Making:</strong> The right not to be subject to automated decision-making</li>
          </ul>
          
          <h2>9. Data Protection Officer</h2>
          <p>
            We have appointed a Data Protection Officer (DPO) responsible for overseeing our data protection strategy and implementation. You can contact our DPO at:
          </p>
          <p>
            Email: dpo@reviewpro.com<br />
            Address: 123 Review Street, Content City, CA 94000
          </p>
          
          <h2>10. Changes to This Data Policy</h2>
          <p>
            We may update this Data Policy from time to time. We will notify you of any changes by posting the new Data Policy on this page and updating the "Last updated" date.
          </p>
          <p>
            We encourage you to review this Data Policy periodically for any changes.
          </p>
        </div>
      </div>
    </div>
  );
}