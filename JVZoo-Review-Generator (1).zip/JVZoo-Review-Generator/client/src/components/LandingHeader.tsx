import React, { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { AuthDialog } from '@/components/AuthDialog';
import { useAuth } from '@/lib/AuthContext';

export default function LandingHeader() {
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  // Only login is available now
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { isAuthenticated } = useAuth();

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex-shrink-0 flex items-center">
            <Link href="/" className="flex items-center hover:opacity-80 transition-opacity">
              <svg viewBox="0 0 32 32" className="h-8 w-8 text-indigo-600 mr-2" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M27 14.8889C27 20.7981 21.1797 25.6667 14 25.6667C6.82031 25.6667 1 20.7981 1 14.8889C1 8.97969 6.82031 4.11111 14 4.11111" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                <path d="M19.6667 5.44444L17 8.11111L19.6667 10.7778" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14 4.11111C21.1797 4.11111 27 8.97969 27 14.8889" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                <circle cx="23.5" cy="6.5" r="6.5" fill="currentColor" fillOpacity="0.3"/>
              </svg>
              <div className="flex flex-col">
                <div className="flex items-center">
                  <span className="font-bold text-xl text-indigo-800">ReviewPro</span>
                  <span className="ml-1 text-xs px-1.5 py-0.5 bg-indigo-100 text-indigo-800 rounded font-medium">PRO</span>
                </div>
                <span className="text-[10px] text-gray-500">Professional JVZoo Review Generator</span>
              </div>
            </Link>
          </div>
          
          {/* Premium menu with floating pills */}
          <div className="hidden sm:flex flex-1 justify-center">
            <div className="flex items-center space-x-2">
              <Link href="/" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                Home
              </Link>
              <a href="#features" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                Features
              </a>
              <a href="#pricing" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                Pricing
              </a>
              <a href="#templates" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                Templates
              </a>
              <a href="#testimonials" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                Testimonials
              </a>
              <a href="#faq" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                FAQ
              </a>
              <Link href="/support/contact" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                Contact
              </Link>
            </div>
          </div>
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            {isAuthenticated ? (
              <div className="flex items-center space-x-3">
                <Link href="/app">
                  <Button className="bg-indigo-600 hover:bg-indigo-700">
                    Dashboard
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Button variant="outline" 
                  className="text-indigo-600 border-indigo-600"
                  onClick={() => setIsAuthOpen(true)}>
                  Log in
                </Button>
                <a href="#pricing">
                  <Button 
                    className="bg-indigo-600 hover:bg-indigo-700">
                    Sign up
                  </Button>
                </a>
              </div>
            )}
          </div>
          <div className="-mr-2 flex items-center sm:hidden">
            {/* Mobile menu button */}
            <button 
              type="button" 
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500" 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-expanded={mobileMenuOpen}
            >
              <span className="sr-only">{mobileMenuOpen ? 'Close menu' : 'Open main menu'}</span>
              {/* Icon when menu is closed */}
              {!mobileMenuOpen ? (
                <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              ) : (
                <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1 bg-white shadow-lg rounded-b-lg border-t border-gray-200">
            <Link href="/" className="block px-4 py-2 text-base font-medium text-indigo-700 border-l-4 border-indigo-500 bg-indigo-50">
              Home
            </Link>
            <a href="#features" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-base font-medium text-gray-600 hover:text-indigo-700 hover:bg-indigo-50 hover:border-indigo-500 border-l-4 border-transparent">
              Features
            </a>
            <a href="#pricing" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-base font-medium text-gray-600 hover:text-indigo-700 hover:bg-indigo-50 hover:border-indigo-500 border-l-4 border-transparent">
              Pricing
            </a>
            <a href="#templates" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-base font-medium text-gray-600 hover:text-indigo-700 hover:bg-indigo-50 hover:border-indigo-500 border-l-4 border-transparent">
              Templates
            </a>
            <a href="#testimonials" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-base font-medium text-gray-600 hover:text-indigo-700 hover:bg-indigo-50 hover:border-indigo-500 border-l-4 border-transparent">
              Testimonials
            </a>
            <a href="#faq" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-base font-medium text-gray-600 hover:text-indigo-700 hover:bg-indigo-50 hover:border-indigo-500 border-l-4 border-transparent">
              FAQ
            </a>
            <Link href="/support/contact" className="block px-4 py-2 text-base font-medium text-gray-600 hover:text-indigo-700 hover:bg-indigo-50 hover:border-indigo-500 border-l-4 border-transparent">
              Contact
            </Link>
          </div>
          <div className="pt-4 pb-3 border-t border-gray-200 bg-white">
            <div className="flex items-center px-4">
              {isAuthenticated ? (
                <Link href="/app" className="w-full">
                  <Button className="bg-indigo-600 hover:bg-indigo-700 w-full">
                    Go to Dashboard
                  </Button>
                </Link>
              ) : (
                <div className="flex flex-col w-full space-y-2">
                  <Button variant="outline" 
                    className="text-indigo-600 border-indigo-600"
                    onClick={() => {
                      setIsAuthOpen(true);
                      setMobileMenuOpen(false);
                    }}>
                    Log in
                  </Button>
                  <a href="#pricing" onClick={() => setMobileMenuOpen(false)}>
                    <Button 
                      className="bg-indigo-600 hover:bg-indigo-700 w-full">
                      Sign up
                    </Button>
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Auth Dialog */}
      <AuthDialog isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </header>
  );
}