import React from 'react';
import Layout from '@/components/Layout';
import { PaymentForm } from '@/components/PaymentForm';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import { Link } from 'wouter';

export default function AgencyPlan() {
  // Plan details
  const planDetails = {
    name: 'Agency',
    price: '99',
    billingCycle: 'monthly' as const,
    description: 'Unlimited access for agencies and power users',
    features: [
      'Unlimited AI-generated reviews',
      'Advanced SEO optimization with competitive analysis',
      'All design themes + exclusive agency themes',
      'Premium and custom review templates',
      'Priority email & chat support with dedicated account manager',
      'Advanced conversion features with A/B testing',
      'Full template library access with custom template creation',
      'API access for integration with your systems',
      'White-labeling capabilities',
      '14-day money-back guarantee',
    ],
  };

  return (
    <Layout variant="landing">
      <div className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <Link href="/#pricing" className="inline-flex items-center text-indigo-600 hover:text-indigo-700">
              <ArrowLeftIcon className="h-4 w-4 mr-2" />
              Back to Pricing
            </Link>
            <h1 className="text-3xl font-bold mt-4 mb-2">Complete Your Agency Plan Purchase</h1>
            <p className="text-gray-600">
              You're just a step away from unlimited review capabilities with our comprehensive Agency plan.
            </p>
          </div>
          
          <PaymentForm plan={planDetails} />
        </div>
      </div>
    </Layout>
  );
}