import admin from 'firebase-admin';

// Mode simulé pour Firebase Admin
// Cette approche fournit des mocks pour Firebase Admin SDK
// pour éviter les problèmes d'authentification dans l'environnement de développement

type MockUserRecord = {
  uid: string;
  email: string;
  displayName?: string;
  emailVerified: boolean;
  disabled: boolean;
  metadata: {
    creationTime: string;
    lastSignInTime: string;
  };
  toJSON: () => any;
};

// Créons un mock de l'application Firebase Admin
let app: admin.app.App; // Added let to declare app

// Mock Firestore
const db = {
  collection: () => ({
    doc: () => ({
      set: async () => {},
      get: async () => ({ exists: true, data: () => ({}) }),
      update: async () => {}
    })
  })
} as unknown as admin.firestore.Firestore;


// For simplicity, we're using a mock approach for Firebase Admin
// Since we're using a mock setup anyway, let's not try to initialize Firebase Admin
console.log('Using mock Firebase Admin setup for development');
app = {
  name: '[DEFAULT]',
  options: {
    projectId: 'jvzoo-70137'
  }
} as unknown as admin.app.App;


export { app, db };

// Mock de fonctions Firebase Admin pour le développement
export const getUserById = async (uid: string) => {
  console.log(`[MOCK] Getting user with uid: ${uid}`);
  try {
    // Retourne un utilisateur simulé
    const mockUser: MockUserRecord = {
      uid,
      email: `user-${uid}@example.com`,
      displayName: `User ${uid}`,
      emailVerified: true,
      disabled: false,
      metadata: {
        creationTime: new Date().toISOString(),
        lastSignInTime: new Date().toISOString()
      },
      toJSON: () => ({
        uid,
        email: `user-${uid}@example.com`,
        displayName: `User ${uid}`
      })
    };
    return { success: true, user: mockUser };
  } catch (error: any) {
    console.error('[MOCK] Error getting user:', error);
    return { 
      success: false, 
      error: error.message || 'User not found'
    };
  }
};

export const createUser = async (email: string, password: string, displayName?: string) => {
  console.log(`[MOCK] Creating user with email: ${email}, displayName: ${displayName}`);
  try {
    // Génère un identifiant utilisateur aléatoire
    const uid = Math.random().toString(36).substring(2, 15);

    // Crée un utilisateur simulé
    const mockUser: MockUserRecord = {
      uid,
      email,
      displayName,
      emailVerified: false,
      disabled: false,
      metadata: {
        creationTime: new Date().toISOString(),
        lastSignInTime: new Date().toISOString()
      },
      toJSON: () => ({
        uid,
        email,
        displayName
      })
    };

    return { success: true, user: mockUser };
  } catch (error: any) {
    console.error('[MOCK] Error creating user:', error);
    return { 
      success: false, 
      error: error.message || 'Failed to create user'
    };
  }
};

export const updateUser = async (uid: string, updates: admin.auth.UpdateRequest) => {
  console.log(`[MOCK] Updating user with uid: ${uid}`, updates);
  try {
    // Récupère l'utilisateur simulé
    const { user } = await getUserById(uid);

    // Applique les mises à jour
    const updatedUser = {
      ...user,
      ...updates
    };

    return { success: true, user: updatedUser };
  } catch (error: any) {
    console.error('[MOCK] Error updating user:', error);
    return { 
      success: false, 
      error: error.message || 'Failed to update user'
    };
  }
};

export const deleteUser = async (uid: string) => {
  console.log(`[MOCK] Deleting user with uid: ${uid}`);
  try {
    return { success: true };
  } catch (error: any) {
    console.error('[MOCK] Error deleting user:', error);
    return { 
      success: false, 
      error: error.message || 'Failed to delete user'
    };
  }
};