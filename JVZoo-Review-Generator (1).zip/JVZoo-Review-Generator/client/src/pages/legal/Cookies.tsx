import React from 'react';

export default function CookiesPolicy() {
  return (
    <div className="bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-10">
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl mb-4">Cookies Policy</h1>
          <p className="text-gray-500">Last updated: {new Date().toLocaleDateString()}</p>
        </div>

        <div className="prose prose-indigo max-w-none">
          <h2>1. Introduction</h2>
          <p>
            This Cookies Policy explains how ReviewPro ("we," "us," "our") uses cookies and similar technologies on our website and application. It explains what these technologies are and why we use them, as well as your rights to control our use of them.
          </p>
          
          <h2>2. What Are Cookies?</h2>
          <p>
            Cookies are small text files that are placed on your computer or mobile device when you visit a website. They are widely used to make websites work more efficiently and provide information to the owners of the site.
          </p>
          <p>
            Cookies set by the website owner (in this case, ReviewPro) are called "first-party cookies." Cookies set by parties other than the website owner are called "third-party cookies." Third-party cookies enable third-party features or functionality to be provided on or through the website (e.g., advertising, interactive content, and analytics).
          </p>
          
          <h2>3. Types of Cookies We Use</h2>
          <p>
            We use the following types of cookies:
          </p>
          <ul>
            <li>
              <strong>Essential Cookies:</strong> These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in, or filling in forms.
            </li>
            <li>
              <strong>Performance Cookies:</strong> These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move around the site.
            </li>
            <li>
              <strong>Functionality Cookies:</strong> These cookies enable the website to provide enhanced functionality and personalization. They may be set by us or by third-party providers whose services we have added to our pages.
            </li>
            <li>
              <strong>Targeting Cookies:</strong> These cookies may be set through our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant advertisements on other sites.
            </li>
          </ul>
          
          <h2>4. Specific Cookies We Use</h2>
          <table className="border-collapse border border-gray-300 w-full">
            <thead>
              <tr className="bg-gray-100">
                <th className="border border-gray-300 px-4 py-2">Cookie Name</th>
                <th className="border border-gray-300 px-4 py-2">Purpose</th>
                <th className="border border-gray-300 px-4 py-2">Duration</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-300 px-4 py-2">session_id</td>
                <td className="border border-gray-300 px-4 py-2">Used to identify your session</td>
                <td className="border border-gray-300 px-4 py-2">Session</td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">user_preferences</td>
                <td className="border border-gray-300 px-4 py-2">Stores your preferences</td>
                <td className="border border-gray-300 px-4 py-2">1 year</td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">_ga</td>
                <td className="border border-gray-300 px-4 py-2">Used by Google Analytics to distinguish users</td>
                <td className="border border-gray-300 px-4 py-2">2 years</td>
              </tr>
              <tr>
                <td className="border border-gray-300 px-4 py-2">_gid</td>
                <td className="border border-gray-300 px-4 py-2">Used by Google Analytics to distinguish users</td>
                <td className="border border-gray-300 px-4 py-2">24 hours</td>
              </tr>
            </tbody>
          </table>
          
          <h2>5. How to Control Cookies</h2>
          <p>
            You can set or amend your web browser controls to accept or refuse cookies. If you choose to reject cookies, you may still use our website though your access to some functionality and areas may be restricted.
          </p>
          <p>
            The specific ways to manage cookies through different web browsers can be found at the following links:
          </p>
          <ul>
            <li><a href="https://support.google.com/chrome/answer/95647" target="_blank" rel="noopener noreferrer">Google Chrome</a></li>
            <li><a href="https://support.mozilla.org/en-US/kb/cookies-information-websites-store-on-your-computer" target="_blank" rel="noopener noreferrer">Mozilla Firefox</a></li>
            <li><a href="https://support.apple.com/guide/safari/manage-cookies-and-website-data-sfri11471/mac" target="_blank" rel="noopener noreferrer">Apple Safari</a></li>
            <li><a href="https://support.microsoft.com/en-us/help/17442/windows-internet-explorer-delete-manage-cookies" target="_blank" rel="noopener noreferrer">Microsoft Internet Explorer</a></li>
            <li><a href="https://support.microsoft.com/en-us/help/4027947/microsoft-edge-delete-cookies" target="_blank" rel="noopener noreferrer">Microsoft Edge</a></li>
          </ul>
          
          <h2>6. What About Other Tracking Technologies?</h2>
          <p>
            Cookies are not the only way to recognize or track visitors to a website. We may use other, similar technologies from time to time, like web beacons (sometimes called "tracking pixels" or "clear gifs"). These are tiny graphics files that contain a unique identifier that enable us to recognize when someone has visited our website. This allows us, for example, to monitor the traffic patterns of users from one page within our website to another, to deliver or communicate with cookies, to understand whether you have come to our website from an online advertisement displayed on a third-party website, to improve site performance, and to measure the success of email marketing campaigns.
          </p>
          
          <h2>7. Updates to This Cookies Policy</h2>
          <p>
            We may update this Cookies Policy from time to time in order to reflect, for example, changes to the cookies we use or for other operational, legal, or regulatory reasons. We will notify you of any changes by posting the new Cookies Policy on this page and updating the "Last updated" date.
          </p>
          <p>
            We encourage you to periodically review this Cookies Policy to stay informed about how we use cookies.
          </p>
          
          <h2>8. Contact Us</h2>
          <p>
            If you have any questions about our use of cookies or this Cookies Policy, please contact us at:
          </p>
          <p>
            Email: privacy@reviewpro.com<br />
            Address: 123 Review Street, Content City, CA 94000
          </p>
        </div>
      </div>
    </div>
  );
}