import React, { useState } from 'react';
import { Helmet } from "react-helmet";
import Layout from "@/components/Layout";
import { Search, BookOpen, FileText, Video, MessagesSquare, Sparkles, ArrowRight, ChevronRight } from "lucide-react";

export default function HelpCenter() {
  const [searchQuery, setSearchQuery] = useState("");
  
  // Popular help categories
  const helpCategories = [
    {
      title: "Getting Started",
      icon: <Sparkles className="h-6 w-6 text-indigo-600" />,
      description: "New to ReviewPro? Learn the basics and set up your account.",
      articles: [
        "Creating your first review",
        "Understanding AI-powered features",
        "Setting up your profile",
        "Importing product data"
      ]
    },
    {
      title: "Review Creation",
      icon: <FileText className="h-6 w-6 text-indigo-600" />,
      description: "Master the review creation process and templates.",
      articles: [
        "Using review templates",
        "Customizing review sections",
        "Adding product images",
        "Creating comparison tables"
      ]
    },
    {
      title: "SEO Optimization",
      icon: <BookOpen className="h-6 w-6 text-indigo-600" />,
      description: "Improve your reviews for better search engine visibility.",
      articles: [
        "Keyword optimization tips",
        "Using the SEO analyzer",
        "Schema markup for reviews",
        "Optimizing review headings"
      ]
    },
    {
      title: "Publishing",
      icon: <Video className="h-6 w-6 text-indigo-600" />,
      description: "Learn how to publish reviews to various platforms.",
      articles: [
        "WordPress integration guide",
        "Publishing to Medium",
        "HTML export options",
        "Publishing workflow best practices"
      ]
    },
    {
      title: "Account Management",
      icon: <MessagesSquare className="h-6 w-6 text-indigo-600" />,
      description: "Manage your subscription, teams, and account settings.",
      articles: [
        "Updating billing information",
        "Managing team members",
        "API key management",
        "Subscription plans and upgrades"
      ]
    }
  ];
  
  // Popular articles
  const popularArticles = [
    {
      title: "How to generate your first AI-powered review",
      views: 12583,
      category: "Getting Started",
      link: "#"
    },
    {
      title: "Optimizing product reviews for Google's algorithm",
      views: 9742,
      category: "SEO Optimization",
      link: "#"
    },
    {
      title: "Creating effective comparison tables",
      views: 8651,
      category: "Review Creation",
      link: "#"
    },
    {
      title: "Publishing reviews directly to WordPress",
      views: 7438,
      category: "Publishing",
      link: "#"
    },
    {
      title: "Understanding ReviewPro's AI content generation",
      views: 6295,
      category: "Getting Started",
      link: "#"
    }
  ];
  
  // FAQ items
  const faqItems = [
    {
      question: "How does ReviewPro's AI write product reviews?",
      answer: "ReviewPro's artificial intelligence analyzes the product information you provide, including specifications, features, and target audience. It then generates high-quality review content based on this data, your selected tone preference, and our library of conversion-optimized review patterns. The AI has been trained on thousands of successful product reviews to understand what drives engagement and conversions."
    },
    {
      question: "Can I customize the AI-generated content?",
      answer: "Absolutely! While our AI creates a complete review draft, you have full editing capabilities to customize any aspect of the content. You can modify sections, add your personal experiences, adjust the tone, or include additional product details. Our platform provides an intuitive editor that makes it easy to refine the AI-generated content to match your specific needs."
    },
    {
      question: "How does the WordPress integration work?",
      answer: "Our WordPress integration allows you to publish reviews directly to your WordPress site with just a few clicks. After connecting your WordPress site in the ReviewPro dashboard, you can select any review and publish it as a draft or live post. The integration preserves all formatting, images, comparison tables, and SEO metadata. We also offer custom settings to match your site's design and categories."
    },
    {
      question: "What SEO features does ReviewPro offer?",
      answer: "ReviewPro includes comprehensive SEO tools designed specifically for product reviews. These include keyword density analysis, readability scoring, schema markup generation for rich snippets, meta description optimization, and automatic header structure optimization. The platform also provides actionable suggestions to improve your content's search engine visibility based on current best practices."
    },
    {
      question: "Can I import existing reviews into ReviewPro?",
      answer: "Yes, we offer an import feature that allows you to bring existing reviews into the platform. You can import content from WordPress, CSV files, or direct copy-paste. Once imported, you can apply ReviewPro's optimization tools to improve SEO, formatting, and conversion elements of your existing content."
    }
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real implementation, this would search through help documentation
    console.log("Searching for:", searchQuery);
  };

  return (
    <Layout variant="landing">
      <Helmet>
        <title>Help Center | ReviewPro</title>
        <meta name="description" content="Find answers to your questions about ReviewPro with our comprehensive help resources, tutorials, and documentation." />
      </Helmet>
      
      <div className="bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Help Center Header */}
          <div className="text-center">
            <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl lg:text-5xl">How can we help you?</h1>
            <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
              Find answers, tutorials, and solutions to common questions
            </p>
          </div>
          
          {/* Search Bar */}
          <div className="mt-12 max-w-3xl mx-auto">
            <form onSubmit={handleSearch} className="sm:flex">
              <div className="min-w-0 flex-1">
                <label htmlFor="search" className="sr-only">Search</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    id="search"
                    className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 pr-12 py-4 sm:text-lg border-gray-300 rounded-md"
                    placeholder="Search for help articles, tutorials, FAQs..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              <div className="mt-3 sm:mt-0 sm:ml-3">
                <button
                  type="submit"
                  className="block w-full rounded-md border border-transparent px-5 py-4 bg-indigo-600 text-base font-medium text-white shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:px-10"
                >
                  Search
                </button>
              </div>
            </form>
          </div>
          
          {/* Help Categories */}
          <div className="mt-24">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">Popular Help Categories</h2>
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {helpCategories.map((category, index) => (
                <div key={index} className="bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden hover:shadow-xl transition-shadow duration-300">
                  <div className="p-6">
                    <div className="flex items-center mb-4">
                      <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                        {category.icon}
                      </div>
                      <h3 className="ml-4 text-xl font-semibold text-gray-900">{category.title}</h3>
                    </div>
                    <p className="text-gray-600 mb-6">{category.description}</p>
                    <ul className="space-y-3 text-gray-700">
                      {category.articles.map((article, idx) => (
                        <li key={idx} className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-indigo-500 flex-shrink-0 mt-0.5" />
                          <a href="#" className="ml-2 hover:text-indigo-600">
                            {article}
                          </a>
                        </li>
                      ))}
                    </ul>
                    <div className="mt-6">
                      <a
                        href="#"
                        className="inline-flex items-center text-indigo-600 hover:text-indigo-500 font-medium"
                      >
                        View all articles
                        <ArrowRight className="ml-1 h-4 w-4" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Popular Articles */}
          <div className="mt-24">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">Most Popular Articles</h2>
            <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200">
              <ul className="divide-y divide-gray-200">
                {popularArticles.map((article, index) => (
                  <li key={index}>
                    <a href={article.link} className="block hover:bg-gray-50">
                      <div className="px-6 py-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <FileText className="h-5 w-5 text-indigo-500" />
                            <p className="ml-3 text-lg font-medium text-gray-900">{article.title}</p>
                          </div>
                          <div className="flex items-center">
                            <span className="text-sm text-gray-500 mr-4">{article.category}</span>
                            <span className="text-xs text-gray-400">{article.views.toLocaleString()} views</span>
                            <ChevronRight className="ml-4 h-5 w-5 text-gray-400" />
                          </div>
                        </div>
                      </div>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-6 text-center">
              <a
                href="#"
                className="inline-flex items-center text-indigo-600 hover:text-indigo-500 font-medium"
              >
                View all help articles
                <ArrowRight className="ml-1 h-4 w-4" />
              </a>
            </div>
          </div>
          
          {/* FAQs */}
          <div className="mt-24">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">Frequently Asked Questions</h2>
            <div className="max-w-3xl mx-auto divide-y divide-gray-200">
              {faqItems.map((item, index) => (
                <div key={index} className="py-6">
                  <h3 className="text-lg font-medium text-gray-900">{item.question}</h3>
                  <p className="mt-3 text-gray-600">{item.answer}</p>
                </div>
              ))}
            </div>
            <div className="mt-10 text-center">
              <a
                href="#"
                className="inline-flex items-center text-indigo-600 hover:text-indigo-500 font-medium"
              >
                View all FAQs
                <ArrowRight className="ml-1 h-4 w-4" />
              </a>
            </div>
          </div>
          
          {/* Contact Support CTA */}
          <div className="mt-24 bg-indigo-50 rounded-lg py-12 px-6 sm:py-16 sm:px-12 lg:flex lg:items-center lg:p-16">
            <div className="lg:w-0 lg:flex-1">
              <h2 className="text-3xl font-extrabold tracking-tight text-gray-900">
                Didn't find what you're looking for?
              </h2>
              <p className="mt-4 max-w-3xl text-lg text-gray-500">
                Our support team is ready to assist you with any questions or issues you might have.
              </p>
            </div>
            <div className="mt-12 sm:w-full sm:max-w-md lg:mt-0 lg:ml-8 lg:flex-1">
              <a
                href="/support/contact"
                className="w-full flex items-center justify-center px-6 py-4 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 md:text-lg"
              >
                Contact Support
              </a>
              <div className="mt-3 text-center text-sm text-gray-500">
                We typically respond within 24 hours
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}