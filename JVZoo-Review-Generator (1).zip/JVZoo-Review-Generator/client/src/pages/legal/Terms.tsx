import React from 'react';

export default function TermsOfService() {
  return (
    <div className="bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-10">
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl mb-4">Terms of Service</h1>
          <p className="text-gray-500">Last updated: {new Date().toLocaleDateString()}</p>
        </div>

        <div className="prose prose-indigo max-w-none">
          <h2>1. Acceptance of Terms</h2>
          <p>
            By accessing or using ReviewPro, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this site.
          </p>
          
          <h2>2. Use License</h2>
          <p>
            Permission is granted to temporarily use ReviewPro for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:
          </p>
          <ul>
            <li>Modify or copy the materials;</li>
            <li>Use the materials for any commercial purpose;</li>
            <li>Attempt to decompile or reverse engineer any software contained on ReviewPro;</li>
            <li>Remove any copyright or other proprietary notations from the materials; or</li>
            <li>Transfer the materials to another person or "mirror" the materials on any other server.</li>
          </ul>
          <p>
            This license shall automatically terminate if you violate any of these restrictions and may be terminated by ReviewPro at any time. Upon terminating your viewing of these materials or upon the termination of this license, you must destroy any downloaded materials in your possession.
          </p>
          
          <h2>3. User Accounts</h2>
          <p>
            When you create an account with us, you must provide information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account.
          </p>
          <p>
            You are responsible for safeguarding the password that you use to access the service and for any activities or actions under your password. We encourage you to use "strong" passwords (passwords that use a combination of upper and lower case letters, numbers, and symbols) with your account.
          </p>
          
          <h2>4. Subscription and Payment</h2>
          <p>
            Some features of ReviewPro require a paid subscription. By subscribing to our service, you agree to pay the subscription fees as described at the time of purchase. We may change the fees for subscriptions from time to time with notice to you.
          </p>
          <p>
            All payments are processed through secure third-party payment processors. We do not store your payment information directly.
          </p>
          
          <h2>5. Content Ownership</h2>
          <p>
            ReviewPro does not claim ownership of the content you create using our platform. However, you grant us a non-exclusive, worldwide, royalty-free license to use, reproduce, adapt, publish, translate, and distribute your content in any existing or future media.
          </p>
          <p>
            You retain all rights to your content, and you are responsible for the content you create and publish using our service.
          </p>
          
          <h2>6. Disclaimer</h2>
          <p>
            The materials on ReviewPro are provided on an 'as is' basis. ReviewPro makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
          </p>
          
          <h2>7. Limitations</h2>
          <p>
            In no event shall ReviewPro or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use ReviewPro, even if ReviewPro or a ReviewPro authorized representative has been notified orally or in writing of the possibility of such damage.
          </p>
          
          <h2>8. Governing Law</h2>
          <p>
            These Terms shall be governed and construed in accordance with the laws applicable in your jurisdiction, without regard to its conflict of law provisions. Any legal suit, action, or proceeding arising out of or related to these Terms or the use of our service shall be brought exclusively in the courts of your jurisdiction.
          </p>
          
          <h2>9. Changes to Terms</h2>
          <p>
            ReviewPro reserves the right, at its sole discretion, to modify or replace these Terms at any time. What constitutes a material change will be determined at our sole discretion. By continuing to access or use our service after those revisions become effective, you agree to be bound by the revised terms.
          </p>
          
          <h2>10. Contact Us</h2>
          <p>
            If you have any questions about these Terms, please contact us at:
          </p>
          <p>
            Email: terms@reviewpro.com<br />
            Address: 123 Review Street, Content City, CA 94000
          </p>
        </div>
      </div>
    </div>
  );
}