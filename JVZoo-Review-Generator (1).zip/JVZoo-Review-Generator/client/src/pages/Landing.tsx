import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { AuthDialog } from '@/components/AuthDialog';
import { useAuth } from '@/lib/AuthContext';
import { 
  Check as CheckIcon, 
  X as XIcon, 
  ArrowRight as ArrowRightIcon, 
  Star as StarIcon, 
  Sparkles as SparklesIcon,
  Zap as LightningBoltIcon,
  ShieldCheck as ShieldCheckIcon,
  FileText as DocumentTextIcon,
  Search as SearchIcon,
  Settings as AdjustmentsIcon,
  LayoutTemplate as TemplateIcon,
  LineChart as PresentationChartLineIcon,
  BarChart as PresentationChartBarIcon,
  PieChart as ChartPieIcon,
  Cpu as ChipIcon,
  Image as PuzzleIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon
} from 'lucide-react';

// Import screenshots
import homeImg from "@assets/home.png";
import dashboardImg from "@assets/dashboard.png";
import reviewSettingsImg from "@assets/03.png";
import seoOptimizationImg from "@assets/05.png";
import productDetailsImg from "@assets/02.png";
import productImagesImg from "@assets/04.png";

// Feature showcase component
const FeatureCard = ({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) => (
  <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
    <div className="flex items-start">
      <div className="flex-shrink-0 mt-1">
        <div className="bg-indigo-100 rounded-md p-2 text-indigo-700">
          {icon}
        </div>
      </div>
      <div className="ml-4">
        <h3 className="text-lg font-medium text-gray-900">{title}</h3>
        <p className="mt-2 text-sm text-gray-500">{description}</p>
      </div>
    </div>
  </div>
);

// Pricing tier component
const PricingTier = ({ 
  name, 
  price, 
  description, 
  features, 
  popularBadge = false, 
  ctaText,
  priceInterval = 'month',
  discount = '',
  originalPrice = '',
  buttonVariant = 'default'
}: { 
  name: string; 
  price: string; 
  description: string; 
  features: {text: string; included: boolean}[];
  popularBadge?: boolean;
  ctaText: string;
  priceInterval?: string;
  discount?: string;
  originalPrice?: string;
  buttonVariant?: 'default' | 'secondary' | 'outline' | 'destructive';
}) => (
  <div className={`rounded-2xl shadow-xl overflow-hidden ${popularBadge ? 'border-2 border-indigo-500 transform scale-105' : ''}`}>
    {popularBadge && (
      <div className="bg-indigo-500 py-1 text-center">
        <p className="text-xs font-medium text-white uppercase tracking-wide">Most Popular</p>
      </div>
    )}
    <div className="bg-white p-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">{name}</h3>
        {discount && (
          <span className="px-2 py-1 text-xs font-semibold text-white bg-indigo-500 rounded">
            {discount}
          </span>
        )}
      </div>
      <div className="mt-4 flex items-baseline">
        <span className="text-4xl font-extrabold text-gray-900">${price}</span>
        <span className="ml-1 text-xl font-medium text-gray-500">/{priceInterval}</span>
      </div>
      {originalPrice && (
        <div className="mt-1">
          <span className="text-base text-gray-500 line-through">${originalPrice}/{priceInterval}</span>
        </div>
      )}
      <p className="mt-5 text-sm text-gray-500">{description}</p>
      
      <div className="mt-6">
        <Button 
          className="w-full" 
          variant={buttonVariant as "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"}
        >
          {ctaText}
        </Button>
      </div>
    </div>
    <div className="px-6 pt-6 pb-8 bg-gray-50">
      <h4 className="text-sm font-medium text-gray-900 tracking-wide uppercase">What's included</h4>
      <ul className="mt-6 space-y-4">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start">
            <div className="flex-shrink-0">
              {feature.included ? (
                <CheckIcon className="h-5 w-5 text-indigo-500" />
              ) : (
                <XIcon className="h-5 w-5 text-gray-400" />
              )}
            </div>
            <p className={`ml-3 text-sm ${feature.included ? 'text-gray-700' : 'text-gray-500'}`}>
              {feature.text}
            </p>
          </li>
        ))}
      </ul>
    </div>
  </div>
);

// Testimonial component
const Testimonial = ({ 
  quote, 
  author, 
  role, 
  rating = 5,
  avatarUrl = 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80' 
}: { 
  quote: string; 
  author: string; 
  role: string; 
  rating?: number;
  avatarUrl?: string;
}) => (
  <div className="bg-white rounded-lg shadow-md p-5 hover:shadow-lg transition-shadow border border-gray-100 h-full flex flex-col">
    <div className="flex space-x-1 mb-2">
      {[...Array(5)].map((_, i) => (
        <StarIcon 
          key={i} 
          className={`h-4 w-4 ${i < rating ? 'text-yellow-400' : 'text-gray-300'}`} 
        />
      ))}
    </div>
    <blockquote className="text-gray-700 italic mb-4 text-sm flex-grow">&ldquo;{quote}&rdquo;</blockquote>
    <div className="flex items-center mt-auto">
      <img 
        src={avatarUrl}
        alt={author}
        className="w-8 h-8 rounded-full mr-2"
      />
      <div>
        <div className="font-medium text-gray-900 text-sm">{author}</div>
        <div className="text-gray-500 text-xs">{role}</div>
      </div>
    </div>
  </div>
);

// FAQ component
const FAQItem = ({ question, answer }: { question: string; answer: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className={`mb-4 rounded-lg border ${isOpen ? 'border-indigo-200 bg-indigo-50' : 'border-gray-200 hover:border-indigo-100 hover:bg-gray-50'} transition-all duration-200`}>
      <button
        className="flex justify-between items-center w-full text-left p-5"
        onClick={() => setIsOpen(!isOpen)}
      >
        <h3 className={`text-lg font-medium ${isOpen ? 'text-indigo-700' : 'text-gray-900'}`}>{question}</h3>
        <span className="ml-6 flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-white shadow-sm border border-gray-100">
          {isOpen ? (
            <svg className="h-4 w-4 text-indigo-500" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M5 10a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1z" clipRule="evenodd" />
            </svg>
          ) : (
            <svg className="h-4 w-4 text-indigo-500" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
            </svg>
          )}
        </span>
      </button>
      {isOpen && (
        <div className="px-5 pb-5">
          <div className="border-t border-indigo-100 pt-4">
            <p className="text-base text-gray-600">{answer}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default function Landing() {
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authTab, setAuthTab] = useState<'login' | 'register'>('login');
  // Only login is available now
  const { isAuthenticated } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  
  // State for dynamic stats
  const [timeSavedStat, setTimeSavedStat] = useState(0);
  const [conversionStat, setConversionStat] = useState(0);
  const [usersStat, setUsersStat] = useState(0);
  const [reviewsStat, setReviewsStat] = useState(0);
  
  // Animation effect for stats
  useEffect(() => {
    const timeSavedTarget = 85;
    const conversionTarget = 42;
    const usersTarget = 12;
    const reviewsTarget = 25;
    
    let frameCount = 0;
    const animationDuration = 1500; // ms
    const framesPerSecond = 60;
    const totalFrames = animationDuration / 1000 * framesPerSecond;
    
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        const timer = setInterval(() => {
          frameCount++;
          const progress = Math.min(frameCount / totalFrames, 1);
          // Easing function for smoother animation
          const easeOutQuad = (t: number) => t * (2 - t);
          const easedProgress = easeOutQuad(progress);
          
          setTimeSavedStat(Math.floor(easedProgress * timeSavedTarget));
          setConversionStat(Math.floor(easedProgress * conversionTarget));
          setUsersStat(Math.floor(easedProgress * usersTarget));
          setReviewsStat(Math.floor(easedProgress * reviewsTarget));
          
          if (frameCount >= totalFrames) {
            clearInterval(timer);
            setTimeSavedStat(timeSavedTarget);
            setConversionStat(conversionTarget);
            setUsersStat(usersTarget);
            setReviewsStat(reviewsTarget);
          }
        }, 1000 / framesPerSecond);
      }
    }, { threshold: 0.2 });
    
    const statsSection = document.querySelector('#stats-section');
    if (statsSection) {
      observer.observe(statsSection);
    }
    
    return () => {
      if (statsSection) {
        observer.unobserve(statsSection);
      }
    };
  }, []);
  


  // Features data
  const features = [
    {
      icon: <DocumentTextIcon className="h-6 w-6" />,
      title: "Professional Review Generation",
      description: "Generate comprehensive, well-structured product reviews with perfect formatting, persuasive copy, and SEO-optimized content in seconds."
    },
    {
      icon: <SearchIcon className="h-6 w-6" />,
      title: "Advanced SEO Optimization",
      description: "Automatically optimize reviews for search engines with keyword targeting, schema markup, meta descriptions, and semantic structure."
    },
    {
      icon: <AdjustmentsIcon className="h-6 w-6" />,
      title: "Customizable Content Structure",
      description: "Choose which sections to include: pricing tables, pros/cons, testimonials, comparison tables, FAQs, and more."
    },
    {
      icon: <TemplateIcon className="h-6 w-6" />,
      title: "Template Management",
      description: "Save your favorite review configurations as templates to streamline your workflow and maintain consistent formatting."
    },
    {
      icon: <PresentationChartLineIcon className="h-6 w-6" />,
      title: "Multiple Design Themes",
      description: "Select from various professional themes and styles to match your brand or product niche perfectly."
    },
    {
      icon: <ChartPieIcon className="h-6 w-6" />,
      title: "Conversion Optimization",
      description: "Strategic placement of call-to-action buttons, trust elements, and persuasive techniques to maximize conversion rates."
    },
    {
      icon: <ChipIcon className="h-6 w-6" />,
      title: "AI-Powered Content Quality",
      description: "Leverage cutting-edge AI models to ensure well-researched, accurate, and engaging reviews that convert."
    },
    {
      icon: <PuzzleIcon className="h-6 w-6" />,
      title: "Image Integration",
      description: "Seamlessly incorporate product images with proper formatting, captions, and alt text for enhanced visual appeal."
    },
  ];

  // Pricing tiers data
  const pricingTiers = [
    {
      name: "Basic",
      price: "29",
      originalPrice: "49",
      discount: "SAVE 40%",
      description: "Essential tools for creating professional product reviews",
      features: [
        { text: "20 AI-generated reviews per month", included: true },
        { text: "Basic SEO optimization", included: true },
        { text: "3 design themes", included: true },
        { text: "Standard review templates", included: true },
        { text: "Email support", included: true },
        { text: "Advanced conversion features", included: false },
        { text: "Template library access", included: false },
        { text: "Priority support", included: false },
      ],
      ctaText: "Get Started",
      buttonVariant: "outline",
    },
    {
      name: "Pro",
      price: "49",
      originalPrice: "79",
      discount: "MOST POPULAR",
      description: "Advanced features for marketers and affiliate professionals",
      features: [
        { text: "50 AI-generated reviews per month", included: true },
        { text: "Advanced SEO optimization", included: true },
        { text: "All design themes", included: true },
        { text: "Premium review templates", included: true },
        { text: "Priority email support", included: true },
        { text: "Advanced conversion features", included: true },
        { text: "Template library access", included: true },
        { text: "API access", included: false },
      ],
      popularBadge: true,
      ctaText: "Choose Pro",
      buttonVariant: "default",
    },
    {
      name: "Agency",
      price: "99",
      originalPrice: "149",
      discount: "SAVE 33%",
      description: "Unlimited access for agencies and power users",
      features: [
        { text: "Unlimited AI-generated reviews", included: true },
        { text: "Advanced SEO optimization", included: true },
        { text: "All design themes + exclusives", included: true },
        { text: "Premium review templates", included: true },
        { text: "Priority email & chat support", included: true },
        { text: "Advanced conversion features", included: true },
        { text: "Template library access", included: true },
        { text: "API access & white-labeling", included: true },
      ],
      ctaText: "Choose Agency",
      buttonVariant: "outline",
    }
  ];

  // Testimonials data
  const testimonials = [
    {
      quote: "This review generator has completely transformed how I create content for my affiliate sites. The AI produces quality reviews that convert, and the SEO optimization is excellent.",
      author: "Sarah Johnson",
      role: "Affiliate Marketer",
      rating: 5,
      avatarUrl: "https://randomuser.me/api/portraits/women/52.jpg"
    },
    {
      quote: "The time I save using this tool is incredible. What used to take me hours now takes minutes, and the quality is consistently better than what I was producing manually.",
      author: "David Chen",
      role: "Product Reviewer",
      rating: 5,
      avatarUrl: "https://randomuser.me/api/portraits/men/32.jpg"
    },
    {
      quote: "Our agency has seen a 40% increase in conversion rates since we started using these AI-generated reviews. The structured format and persuasive elements really work.",
      author: "Michael Rodriguez",
      role: "Marketing Agency Owner",
      rating: 4,
      avatarUrl: "https://randomuser.me/api/portraits/men/75.jpg"
    },
    {
      quote: "I've tried several AI writing tools, but ReviewPro is in a league of its own for product reviews. The templates are perfect for different product categories, and the SEO analysis helps ensure my content ranks well.",
      author: "Emma Thompson",
      role: "E-commerce Blogger",
      rating: 5,
      avatarUrl: "https://randomuser.me/api/portraits/women/33.jpg"
    },
    {
      quote: "The multi-platform publishing feature saves me hours of reformatting work. I can create one review and publish it across all my channels with a single click. Absolute game-changer!",
      author: "James Wilson",
      role: "Content Creator",
      rating: 5,
      avatarUrl: "https://randomuser.me/api/portraits/men/45.jpg"
    },
    {
      quote: "As someone who reviews tech products, I need accurate, detailed content that sounds authentic. ReviewPro delivers exactly that, with customizable sections for technical specifications and comparisons.",
      author: "Priya Patel",
      role: "Tech Reviewer",
      rating: 4,
      avatarUrl: "https://randomuser.me/api/portraits/women/65.jpg"
    },
  ];

  // FAQ data
  const faqs = [
    {
      question: "How does the AI review generator work?",
      answer: "Our AI review generator uses advanced natural language processing to create professional, persuasive product reviews based on the information you provide. Simply enter your product details, select your desired content options, and our AI will generate a comprehensive review with perfect formatting and SEO optimization in seconds."
    },
    {
      question: "Do I need technical skills to use this platform?",
      answer: "No technical skills required! Our platform is designed with a user-friendly interface that makes it easy for anyone to generate professional reviews. Simply fill in your product information, select your preferences, and the system handles all the technical aspects of creating properly structured, SEO-optimized content."
    },
    {
      question: "Can I edit the reviews after they're generated?",
      answer: "Yes! All generated reviews can be fully edited. You can make changes directly in our editor or export the HTML to use in your own content management system. This gives you the perfect balance of AI efficiency and human customization."
    },
    {
      question: "How do subscription plans work?",
      answer: "Our subscription plans are billed monthly and provide a set number of review generations per month based on your plan tier. You can upgrade, downgrade, or cancel your subscription at any time. All plans include core features, with higher tiers offering more generations and advanced functionality."
    },
    {
      question: "Is there a free trial available?",
      answer: "Yes, we offer a 7-day free trial with access to our Pro plan features. This allows you to experience the full power of our review generator before committing to a subscription. No credit card is required to start your trial."
    },
    {
      question: "How do I connect my Google AI Studio API key?",
      answer: "In your account dashboard, navigate to the 'Configuration' section. There, you'll find a field to enter your Google AI Studio API key. Once entered and saved, our system will use this key to generate your reviews. Don't worry - we provide full instructions on how to obtain this key if you don't already have one."
    },
  ];

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Navigation */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <Link href="/" className="flex items-center hover:opacity-80 transition-opacity">
                  <svg viewBox="0 0 32 32" className="h-8 w-8 text-indigo-600 mr-2" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M27 14.8889C27 20.7981 21.1797 25.6667 14 25.6667C6.82031 25.6667 1 20.7981 1 14.8889C1 8.97969 6.82031 4.11111 14 4.11111" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <path d="M19.6667 5.44444L17 8.11111L19.6667 10.7778" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M14 4.11111C21.1797 4.11111 27 8.97969 27 14.8889" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                    <circle cx="23.5" cy="6.5" r="6.5" fill="currentColor" fillOpacity="0.3"/>
                  </svg>
                  <div className="flex flex-col">
                    <div className="flex items-center">
                      <span className="font-bold text-xl text-indigo-800">ReviewPro</span>
                      <span className="ml-1 text-xs px-1.5 py-0.5 bg-indigo-100 text-indigo-800 rounded font-medium">PRO</span>
                    </div>
                    <span className="text-[10px] text-gray-500">Professional JVZoo Review Generator</span>
                  </div>
                </Link>
              </div>
            </div>
            
            {/* Premium menu with floating pills */}
            <div className="hidden sm:flex flex-1 justify-center">
              <div className="flex items-center space-x-2">
                <a href="#features" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                  Features
                </a>
                <a href="#pricing" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                  Pricing
                </a>
                <a href="#templates" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                  Templates
                </a>
                <a href="#resources" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                  Resources
                </a>
                <a href="#testimonials" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                  Testimonials
                </a>
                <a href="#faq" className="border border-indigo-500 text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-md text-sm font-medium transition-colors">
                  FAQ
                </a>
              </div>
            </div>
            <div className="flex items-center">
              {isAuthenticated ? (
                <Link href="/app">
                  <Button className="ml-4">
                    Go to Dashboard
                    <ArrowRightIcon className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              ) : (
                <>
                  <Button 
                    variant="outline" 
                    className="border-indigo-500 text-indigo-600 hover:bg-indigo-50"
                    onClick={() => setIsAuthOpen(true)}
                  >
                    Sign In
                  </Button>
                  <a href="#pricing">
                    <Button 
                      className="ml-4 bg-indigo-600 hover:bg-indigo-700"
                    >
                      Sign Up
                    </Button>
                  </a>
                </>
              )}
            </div>
          </div>
          
          {/* Mobile menu */}
          <div className="sm:hidden flex items-center py-4">
            <div className="relative">
              <button 
                type="button"
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                <span className="sr-only">{mobileMenuOpen ? 'Close menu' : 'Open menu'}</span>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  {mobileMenuOpen ? (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  ) : (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                  )}
                </svg>
              </button>
              
              {/* Mobile navigation menu */}
              {mobileMenuOpen && (
                <div className="absolute top-12 -left-4 w-screen bg-white shadow-lg rounded-b-lg z-50">
                  <div className="py-2 px-4 divide-y divide-gray-100">
                    <div className="py-2">
                      <a href="#features" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-md">
                        Features
                      </a>
                      <a href="#pricing" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-md">
                        Pricing
                      </a>
                      <a href="#templates" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-md">
                        Templates
                      </a>
                      <a href="#resources" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-md">
                        Resources
                      </a>
                      <a href="#testimonials" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-md">
                        Testimonials
                      </a>
                      <a href="#faq" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-md">
                        FAQ
                      </a>
                      <Link href="/support/contact" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-md">
                        Contact
                      </Link>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="ml-auto flex space-x-2">
              <Button 
                size="sm" 
                variant="outline" 
                className="text-xs border-indigo-500 text-indigo-600"
                onClick={() => {
                  setAuthTab('login');
                  setIsAuthOpen(true);
                }}
              >
                Sign In
              </Button>
              <Button 
                size="sm" 
                className="text-xs bg-indigo-600"
                onClick={() => {
                  setAuthTab('register');
                  setIsAuthOpen(true);
                }}
              >
                Sign Up
              </Button>
            </div>
          </div>
        </nav>
      </header>

      {/* Hero section - Modern Professional Design */}
      <div className="relative overflow-hidden bg-gradient-to-r from-indigo-800 via-indigo-700 to-indigo-600">
        {/* Geometric Pattern Background */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{ 
            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3Cpath d='M6 5V0H5v5H0v1h5v94h1V6h94V5H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            backgroundSize: '50px 50px'
          }}></div>
        </div>

        {/* Light glows and accents */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-1/3 w-64 h-64 bg-indigo-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20"></div>
          <div className="absolute bottom-0 right-1/3 w-80 h-80 bg-purple-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center justify-between pt-16 pb-24 lg:py-24 gap-12">
            
            {/* Content Side */}
            <div className="lg:w-1/2 text-white z-10 text-center lg:text-left">
              <div className="inline-flex items-center rounded-full py-1 px-3 mb-6 bg-white/10 backdrop-blur-sm">
                <span className="inline-block w-2 h-2 rounded-full bg-indigo-300 animate-pulse mr-2"></span>
                <span className="text-xs font-semibold tracking-wide uppercase text-indigo-100">AI-Powered</span>
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight mb-6">
                <span className="block text-white">Create Reviews That</span>
                <span className="block text-white">
                  <span className="relative inline-block mr-3">
                    <span className="relative z-10">Convert</span>
                    <span className="absolute -bottom-2 left-0 right-0 h-3 bg-indigo-400 opacity-30 -skew-y-3"></span>
                  </span>
                </span>
              </h1>
              
              <p className="text-lg sm:text-xl leading-relaxed text-indigo-100 mb-10 max-w-xl lg:max-w-none mx-auto lg:mx-0">
                Generate SEO-optimized product reviews with high conversion rates in minutes using our advanced AI technology.
              </p>
              
              {/* Features in cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
                <div className="bg-white/10 backdrop-blur-sm px-4 py-5 rounded-lg border border-white/5 hover:bg-white/15 hover:border-indigo-300/30 transition-all group">
                  <div className="flex items-center mb-2">
                    <div className="w-8 h-8 rounded-md bg-indigo-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <CheckIcon className="h-5 w-5 text-white" />
                    </div>
                    <h3 className="ml-3 font-bold text-white">SEO Optimized</h3>
                  </div>
                  <p className="text-sm text-indigo-100 opacity-80">Rank higher in search engines</p>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm px-4 py-5 rounded-lg border border-white/5 hover:bg-white/15 hover:border-indigo-300/30 transition-all group">
                  <div className="flex items-center mb-2">
                    <div className="w-8 h-8 rounded-md bg-indigo-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <CheckIcon className="h-5 w-5 text-white" />
                    </div>
                    <h3 className="ml-3 font-bold text-white">Pro Templates</h3>
                  </div>
                  <p className="text-sm text-indigo-100 opacity-80">Professional ready-to-use designs</p>
                </div>
                
                <div className="bg-white/10 backdrop-blur-sm px-4 py-5 rounded-lg border border-white/5 hover:bg-white/15 hover:border-indigo-300/30 transition-all group">
                  <div className="flex items-center mb-2">
                    <div className="w-8 h-8 rounded-md bg-indigo-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <CheckIcon className="h-5 w-5 text-white" />
                    </div>
                    <h3 className="ml-3 font-bold text-white">High Conversion</h3>
                  </div>
                  <p className="text-sm text-indigo-100 opacity-80">Increase your conversion rates</p>
                </div>
              </div>
              
              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-16">
                {isAuthenticated ? (
                  <Link href="/app">
                    <Button size="lg" className="w-full sm:w-auto px-8 bg-white hover:bg-indigo-50 text-indigo-700 shadow-md font-medium rounded-lg">
                      Go to Dashboard
                      <ArrowRightIcon className="ml-2 h-5 w-5" />
                    </Button>
                  </Link>
                ) : (
                  <>
                    <a href="#pricing">
                      <Button 
                        size="lg"
                        className="w-full sm:w-auto bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-md font-medium px-8 rounded-lg"
                      >
                        Start 3-Day Free Trial
                        <SparklesIcon className="ml-2 h-5 w-5" />
                      </Button>
                    </a>
                    <Button 
                      size="lg" 
                      variant="outline" 
                      className="w-full sm:w-auto border-white/30 bg-[#2e3192]/5 hover:bg-[#2e3192]/10 text-white rounded-lg"
                      onClick={() => {
                        setAuthTab('login');
                        setIsAuthOpen(true);
                      }}
                    >
                      Sign In
                    </Button>
                  </>
                )}
              </div>
            </div>
            
            {/* Image Side with App Preview */}
            <div className="lg:w-1/2 z-10">
              <div className="relative mx-auto max-w-lg">
                {/* Main browser window with screenshot */}
                <div className="p-2 bg-gradient-to-r from-indigo-900 to-indigo-800 rounded-2xl shadow-2xl relative">
                  <div className="rounded-xl overflow-hidden bg-white">
                    {/* Browser toolbar */}
                    <div className="h-8 bg-gray-100 flex items-center px-3 border-b border-gray-200">
                      <div className="flex space-x-1.5">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
                      </div>
                      <div className="ml-4 flex-1 h-4 bg-gray-200 mx-16 rounded-full"></div>
                    </div>
                    
                    {/* Main app screenshot */}
                    <div className="relative">
                      <img
                        src={dashboardImg}
                        alt="ReviewPro Dashboard"
                        className="w-full object-cover"
                      />
                      
                      {/* Interactive hover overlay */}
                      <div className="absolute inset-0 flex items-center justify-center bg-indigo-800/70 backdrop-blur-sm opacity-0 hover:opacity-100 transition-opacity duration-300">
                        <div className="text-center p-4">
                          <div className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center mx-auto mb-4">
                            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                          </div>
                          <h3 className="text-2xl font-bold text-white mb-2">Intuitive Interface</h3>
                          <p className="text-indigo-100">Create professional reviews in just a few clicks</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Floating UI Elements */}
                <div className="absolute -top-14 -right-14 bg-white rounded-lg shadow-lg p-4 rotate-6 animate-bounce-slow">
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center">
                      <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-xs font-bold text-gray-900">Instant Generation</h3>
                      <p className="text-xs text-gray-500">Content ready in seconds</p>
                    </div>
                  </div>
                </div>
                
                <div className="absolute -bottom-6 -left-10 bg-white rounded-lg shadow-lg p-4 -rotate-3 animate-pulse-slow">
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center">
                      <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 11.5V14m0-2.5v-6a1.5 1.5 0 113 0m-3 6a1.5 1.5 0 00-3 0v2a7.5 7.5 0 0015 0v-5a1.5 1.5 0 00-3 0m-6-3V11m0-5.5v-1a1.5 1.5 0 013 0v1m0 0V11m0-5.5a1.5 1.5 0 013 0v3m0 0V11" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-gray-900">Custom Style</h3>
                      <p className="text-xs text-gray-500">Tailored to your brand</p>
                    </div>
                  </div>
                </div>
                
                <div className="absolute top-1/2 -right-16 bg-white rounded-lg shadow-lg p-4 rotate-3 hover:scale-110 transition-transform">
                  <div className="flex flex-col">
                    <h3 className="text-sm font-bold text-gray-900 mb-1">SEO Score</h3>
                    <div className="w-32 h-2 bg-gray-100 rounded-full overflow-hidden mb-2">
                      <div className="h-full bg-indigo-600 w-[99%]"></div>
                    </div>
                    <p className="text-xl font-bold text-indigo-600">99%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Wave separator */}
        <div className="absolute -bottom-1 left-0 right-0">
          <svg viewBox="0 0 1440 120" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto fill-gray-100">
            <path d="M0,0 C240,40 480,60 720,60 C960,60 1200,40 1440,0 L1440,120 L0,120 Z" />
          </svg>
        </div>
      </div>
      
      {/* Custom animations */}
      <style>{`
        .animate-bounce-slow {
          animation: bounce-slow 5s infinite;
        }
        
        .animate-pulse-slow {
          animation: pulse-slow 4s infinite;
        }
        
        @keyframes bounce-slow {
          0%, 100% {
            transform: translateY(0) rotate(6deg);
          }
          50% {
            transform: translateY(-15px) rotate(6deg);
          }
        }
        
        @keyframes pulse-slow {
          0%, 100% {
            opacity: 1;
            transform: scale(1) rotate(-3deg);
          }
          50% {
            opacity: 0.8;
            transform: scale(1.05) rotate(-3deg);
          }
        }
      `}</style>
      
      {/* Animation classes définies directement dans Tailwind */}
      
      {/* Client logos */}
      <div className="bg-gray-100 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm font-medium text-gray-500 uppercase tracking-wide mb-4">
            Powering the web's most successful product reviews
          </p>
          <div className="grid grid-cols-2 gap-8 md:grid-cols-8">
            <div className="col-span-1 flex justify-center items-center opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition">
              <span className="text-gray-500 font-bold flex items-center">
                <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-2 16h-2v-6h2v6zm-1-6.891c-.607 0-1.1-.496-1.1-1.109 0-.612.492-1.109 1.1-1.109s1.1.497 1.1 1.109c0 .613-.493 1.109-1.1 1.109zm8 6.891h-1.998v-2.861c0-1.881-2.002-1.722-2.002 0v2.861h-2v-6h2v1.093c.872-1.616 4-1.736 4 1.548v3.359z"/>
                </svg>
                LinkedIn
              </span>
            </div>
            <div className="col-span-1 flex justify-center items-center opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition">
              <span className="text-gray-500 font-bold flex items-center">
                <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19.099 10.979c-1.021-.256-2.05-.358-3.082-.358-1.888 0-3.653.511-5.208 1.385-2.282 1.281-4.659 3.512-4.659 7.944h3.027c0-3.314 2.333-5.458 3.928-6.366 1.305-.741 2.686-1.05 4.137-1.05.749 0 1.499.07 2.251.253l-.394-1.808zm-7.16-6.831c-1.273 0-2.298 1.050-2.298 2.334 0 1.283 1.025 2.333 2.298 2.333 1.269 0 2.295-1.05 2.295-2.333 0-1.284-1.026-2.334-2.295-2.334z"/>
                  <path d="M20.444 10.127c-.296-1.775-1.083-3.406-2.151-4.741-1.569-1.963-3.818-3.136-6.293-3.136-.789 0-1.542.135-2.263.34-1.061.303-1.986.842-2.795 1.505-.929.764-1.736 1.692-2.331 2.754-1.084 1.932-1.611 4.136-1.611 6.224 0 7.125 5.722 10.679 11.519 10.679 7.462 0 11.519-5.262 11.519-10.679 0-.921-.098-1.868-.279-2.775l-5.315-.171z"/>
                </svg>
                Shopify
              </span>
            </div>
            <div className="col-span-1 flex justify-center items-center opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition">
              <span className="text-gray-500 font-bold flex items-center">
                <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M0 12v-8.646l10-1.355v10.001h-10zm11 0h13v-12l-13 1.807v10.193zm-1 1h-10v7.646l10 1.355v-9.001zm1 0v9.194l13 1.806v-11h-13z"/>
                </svg>
                Microsoft
              </span>
            </div>
            <div className="col-span-1 flex justify-center items-center opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition">
              <span className="text-gray-500 font-bold flex items-center">
                <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z"/>
                </svg>
                Facebook
              </span>
            </div>
            <div className="col-span-1 flex justify-center items-center opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition">
              <span className="text-gray-500 font-bold flex items-center">
                <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                </svg>
                Twitter
              </span>
            </div>
            <div className="col-span-1 flex justify-center items-center opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition">
              <span className="text-gray-500 font-bold flex items-center">
                <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
                </svg>
                YouTube
              </span>
            </div>
            <div className="col-span-1 flex justify-center items-center opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition">
              <span className="text-gray-500 font-bold flex items-center">
                <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm7.931 9h-2.764a14.67 14.67 0 0 0-1.792-6.243A8.013 8.013 0 0 1 19.931 11zM12.53 4.027c1.035 1.364 2.427 3.78 2.627 6.973H9.03c.139-2.596.994-5.028 2.451-6.974.172-.01.34-.026.516-.026.179 0 .354.016.534.027zm-3.842.7C7.704 6.618 7.136 8.762 7.03 11H4.069a8.013 8.013 0 0 1 4.619-6.273zM4.069 13h2.974c.136 2.379.665 4.478 1.556 6.23A8.01 8.01 0 0 1 4.069 13zm7.381 6.973C10.049 18.275 9.222 15.896 9.041 13h6.113c-.208 2.773-1.117 5.196-2.603 6.972-.182.012-.364.028-.551.028-.186 0-.367-.016-.55-.027zm4.011-.772c.955-1.794 1.538-3.901 1.691-6.201h2.778a8.005 8.005 0 0 1-4.469 6.201z"/>
                </svg>
                WordPress
              </span>
            </div>
            <div className="col-span-1 flex justify-center items-center opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition">
              <span className="text-gray-500 font-bold flex items-center">
                <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M22.814 9.031h-1.95c-1 0-1.185-.764-1.185-1.707.001-4.045-3.272-7.324-7.308-7.324h-5.062c-4.037 0-7.309 3.279-7.309 7.324v9.352c0 4.045 3.272 7.324 7.309 7.324h9.383c4.036 0 7.308-3.279 7.308-7.324v-6.457c0-.657-.531-1.188-1.186-1.188zm-15.428-3.031h4.229c.765 0 1.385.671 1.385 1.5s-.62 1.5-1.386 1.5h-4.228c-.766 0-1.386-.671-1.386-1.5s.62-1.5 1.386-1.5zm9.134 12h-9.04c-.817 0-1.48-.672-1.48-1.5 0-.83.663-1.5 1.48-1.5h9.039c.817 0 1.48.67 1.48 1.5.001.828-.662 1.5-1.479 1.5z"/>
                </svg>
                Blogger
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats section */}
      <div id="stats-section" className="bg-indigo-50 pt-12 sm:pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Trusted by marketers and affiliate professionals
            </h2>
            <p className="mt-3 text-xl text-gray-500 sm:mt-4">
              Elevate your content with <span className="font-bold text-indigo-600">✨ ReviewPro ✨</span> — create persuasive product reviews in minutes, not hours. Our AI-powered platform boosts conversions by up to 42% and improves search rankings with stunning templates and advanced SEO tools. Generate more sales with less effort.
            </p>
          </div>
        </div>
        <div className="mt-10 pb-12 sm:pb-16">
          <div className="relative">
            <div className="absolute inset-0 h-1/2 bg-indigo-50"></div>
            <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="max-w-4xl mx-auto">
                <div className="rounded-lg bg-white shadow-lg sm:grid sm:grid-cols-4">
                  <div className="flex flex-col border-b border-gray-100 p-6 text-center sm:border-0 sm:border-r">
                    <dt className="order-2 mt-2 text-lg leading-6 font-medium text-gray-500">Time Saved</dt>
                    <dd className="order-1 text-5xl font-extrabold text-indigo-600">{timeSavedStat}%</dd>
                  </div>
                  <div className="flex flex-col border-t border-b border-gray-100 p-6 text-center sm:border-0 sm:border-l sm:border-r">
                    <dt className="order-2 mt-2 text-lg leading-6 font-medium text-gray-500">Conversion Increase</dt>
                    <dd className="order-1 text-5xl font-extrabold text-indigo-600">{conversionStat}%</dd>
                  </div>
                  <div className="flex flex-col border-t border-b border-gray-100 p-6 text-center sm:border-0 sm:border-l sm:border-r">
                    <dt className="order-2 mt-2 text-lg leading-6 font-medium text-gray-500">Active Users</dt>
                    <dd className="order-1 text-5xl font-extrabold text-indigo-600">{usersStat}k</dd>
                  </div>
                  <div className="flex flex-col border-t border-gray-100 p-6 text-center sm:border-0 sm:border-l">
                    <dt className="order-2 mt-2 text-lg leading-6 font-medium text-gray-500">Reviews Generated</dt>
                    <dd className="order-1 text-5xl font-extrabold text-indigo-600">{reviewsStat}k</dd>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features section */}
      <div id="features" className="py-16 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full bg-indigo-100 text-indigo-800 mb-2">FEATURES</span>
            <h2 className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl md:text-5xl">
              Everything you need to create perfect reviews
            </h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
              Our powerful platform provides all the tools you need to create professional, conversion-focused product reviews.
            </p>
          </div>

          <div className="mt-16">
            <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-2">
              {features.map((feature, index) => (
                <FeatureCard
                  key={index}
                  icon={feature.icon}
                  title={feature.title}
                  description={feature.description}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Application showcase section */}
      <div className="py-20 bg-indigo-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full bg-indigo-100 text-indigo-800 mb-2">WORKFLOW</span>
            <h2 className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl md:text-5xl">
              See How ReviewPro Transforms Your Process
            </h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
              Our comprehensive platform offers everything you need to create, optimize, and publish professional product reviews.
            </p>
          </div>

          {/* Feature with screenshot 1 */}
          <div className="mt-20">
            <div className="lg:grid lg:grid-cols-12 lg:gap-8 items-center">
              <div className="lg:col-span-5">
                <h3 className="text-2xl font-extrabold text-gray-900 sm:text-3xl">
                  Intuitive Content Builder
                </h3>
                <p className="mt-3 text-lg text-gray-500">
                  Our smart editor makes it easy to create perfectly structured reviews with all the elements you need for high conversions. Customize sections, add visual elements, and choose your tone - all with just a few clicks.
                </p>
                <div className="mt-10">
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">Customizable templates</span> for various product categories and review styles
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">Rich content elements</span> including comparison tables, pros/cons lists, and pricing tables
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">Strategic CTA placement</span> to maximize conversion rates
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="mt-10 lg:mt-0 lg:col-span-7">
                <div className="relative">
                  <div className="relative">
                    {/* Browser window mockup */}
                    <div className="rounded-xl shadow-xl overflow-hidden">
                      {/* Browser chrome */}
                      <div className="h-8 bg-gray-200 flex items-center px-3 space-x-1.5">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
                        <div className="ml-4 h-4 w-64 bg-gray-300 rounded-sm"></div>
                      </div>
                      {/* Screenshot */}
                      <img
                        className="object-contain w-full max-h-[400px]"
                        src={reviewSettingsImg}
                        alt="ReviewPro content builder interface"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Feature with screenshot 2 */}
          <div className="mt-32">
            <div className="lg:grid lg:grid-cols-12 lg:gap-8 items-center">
              <div className="lg:col-span-7 order-2 lg:order-1">
                <div className="relative">
                  <div className="relative">
                    {/* Browser window mockup */}
                    <div className="rounded-xl shadow-xl overflow-hidden">
                      {/* Browser chrome */}
                      <div className="h-8 bg-gray-200 flex items-center px-3 space-x-1.5">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
                        <div className="ml-4 h-4 w-64 bg-gray-300 rounded-sm"></div>
                      </div>
                      {/* Screenshot */}
                      <img
                        className="object-contain w-full max-h-[400px]"
                        src={seoOptimizationImg}
                        alt="ReviewPro SEO optimization interface"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-10 lg:mt-0 lg:col-span-5 order-1 lg:order-2">
                <h3 className="text-2xl font-extrabold text-gray-900 sm:text-3xl">
                  Advanced SEO Optimization
                </h3>
                <p className="mt-3 text-lg text-gray-500">
                  Every review is automatically optimized for search engines with strategic keyword placement, structured data, and semantic HTML. Boost visibility and drive more organic traffic to your content.
                </p>
                <div className="mt-10">
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">Automatic schema markup</span> for rich search results
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">Keyword density analysis</span> to ensure optimal content structure
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">Content readability scores</span> to improve user engagement
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Feature with screenshot 3 */}
          <div className="mt-32">
            <div className="lg:grid lg:grid-cols-12 lg:gap-8 items-center">
              <div className="lg:col-span-5">
                <h3 className="text-2xl font-extrabold text-gray-900 sm:text-3xl">
                  AI-Powered Content Generation
                </h3>
                <p className="mt-3 text-lg text-gray-500">
                  Leverage cutting-edge AI to create persuasive, engaging review content in seconds. Our sophisticated models analyze product details and generate compelling, conversion-optimized reviews customized to your needs.
                </p>
                <div className="mt-10">
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">Multiple writing styles</span> from informative to persuasive
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">Product analysis</span> to highlight key selling points
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">Customizable tone and voice</span> to match your brand
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="mt-10 lg:mt-0 lg:col-span-7">
                <div className="relative">
                  <div className="relative">
                    {/* Browser window mockup */}
                    <div className="rounded-xl shadow-xl overflow-hidden">
                      {/* Browser chrome */}
                      <div className="h-8 bg-gray-200 flex items-center px-3 space-x-1.5">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
                        <div className="ml-4 h-4 w-64 bg-gray-300 rounded-sm"></div>
                      </div>
                      {/* Screenshot */}
                      <img
                        className="object-contain w-full max-h-[400px]"
                        src={productImagesImg}
                        alt="ReviewPro AI content generation"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Multi-platform publishing section */}
          <div className="mt-32">
            <div className="lg:grid lg:grid-cols-12 lg:gap-8 items-center">
              <div className="lg:col-span-7 order-2 lg:order-1">
                <div className="relative">
                  <div className="grid grid-cols-3 gap-4">
                    {/* Platform icons */}
                    <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow text-center">
                      <div className="w-16 h-16 mx-auto bg-indigo-100 rounded-full flex items-center justify-center mb-3">
                        <svg className="h-8 w-8 text-indigo-600" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm7.931 9h-2.764a14.67 14.67 0 0 0-1.792-6.243A8.013 8.013 0 0 1 19.931 11zM12.53 4.027c1.035 1.364 2.427 3.78 2.627 6.973H9.03c.139-2.596.994-5.028 2.451-6.974.172-.01.34-.026.516-.026.179 0 .354.016.534.027zm-3.842.7C7.704 6.618 7.136 8.762 7.03 11H4.069a8.013 8.013 0 0 1 4.619-6.273zM4.069 13h2.974c.136 2.379.665 4.478 1.556 6.23A8.01 8.01 0 0 1 4.069 13zm7.381 6.973C10.049 18.275 9.222 15.896 9.041 13h6.113c-.208 2.773-1.117 5.196-2.603 6.972-.182.012-.364.028-.551.028-.186 0-.367-.016-.55-.027zm4.011-.772c.955-1.794 1.538-3.901 1.691-6.201h2.778a8.005 8.005 0 0 1-4.469 6.201z"/>
                        </svg>
                      </div>
                      <h4 className="font-medium text-gray-900">WordPress</h4>
                      <p className="text-sm text-gray-500 mt-1">Direct CMS integration</p>
                    </div>
                    
                    <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow text-center">
                      <div className="w-16 h-16 mx-auto bg-indigo-100 rounded-full flex items-center justify-center mb-3">
                        <svg className="h-8 w-8 text-indigo-600" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M19.199 24h-14.398c-2.652 0-4.801-2.148-4.801-4.8v-14.4c0-2.652 2.149-4.8 4.801-4.8h14.398c2.652 0 4.801 2.148 4.801 4.8v14.4c0 2.652-2.149 4.8-4.801 4.8zm-.8-18.6c0-1.54-1.26-2.8-2.8-2.8h-8c-1.54 0-2.8 1.26-2.8 2.8v8c0 1.54 1.26 2.8 2.8 2.8h8c1.54 0 2.8-1.26 2.8-2.8v-8z"/>
                        </svg>
                      </div>
                      <h4 className="font-medium text-gray-900">Blogger</h4>
                      <p className="text-sm text-gray-500 mt-1">One-click publishing</p>
                    </div>
                    
                    <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow text-center">
                      <div className="w-16 h-16 mx-auto bg-indigo-100 rounded-full flex items-center justify-center mb-3">
                        <svg className="h-8 w-8 text-indigo-600" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M16 16c0 1.104-.896 2-2 2h-12c-1.104 0-2-.896-2-2v-8c0-1.104.896-2 2-2h12c1.104 0 2 .896 2 2v8zm8-10l-6 4.223v3.554l6 4.223v-12z"/>
                        </svg>
                      </div>
                      <h4 className="font-medium text-gray-900">Wix</h4>
                      <p className="text-sm text-gray-500 mt-1">Seamless integration</p>
                    </div>
                    
                    <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow text-center">
                      <div className="w-16 h-16 mx-auto bg-indigo-100 rounded-full flex items-center justify-center mb-3">
                        <svg className="h-8 w-8 text-indigo-600" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M24 17h-3v-5.95c1.74-.65 3-2.33 3-4.3 0-2.54-2.06-4.6-4.6-4.6s-4.6 2.06-4.6 4.6c0 1.97 1.26 3.65 3 4.3v5.95h-5.06v-8.275c1.74-.65 3-2.33 3-4.3 0-2.54-2.06-4.6-4.6-4.6s-4.6 2.06-4.6 4.6c0 1.97 1.26 3.65 3 4.3v8.275h-5.06v-5.95c1.74-.65 3-2.33 3-4.3 0-2.54-2.06-4.6-4.6-4.6s-4.6 2.06-4.6 4.6c0 1.97 1.26 3.65 3 4.3v5.95h-3v-1.72h1v-2.56h-1v-2.56h1v-2.56h-1v-2.56h1v-2.56h-1v-2.56h22v17.28z"/>
                        </svg>
                      </div>
                      <h4 className="font-medium text-gray-900">Shopify</h4>
                      <p className="text-sm text-gray-500 mt-1">E-commerce ready</p>
                    </div>
                    
                    <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow text-center">
                      <div className="w-16 h-16 mx-auto bg-indigo-100 rounded-full flex items-center justify-center mb-3">
                        <svg className="h-8 w-8 text-indigo-600" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M7.127 22.562l-7.127 1.438 1.438-7.128 5.689 5.69zm1.414-1.414l11.228-11.225-5.69-5.692-11.227 11.227 5.689 5.69zm9.768-21.148l-2.816 2.817 5.691 5.691 2.816-2.819-5.691-5.689z"/>
                        </svg>
                      </div>
                      <h4 className="font-medium text-gray-900">Medium</h4>
                      <p className="text-sm text-gray-500 mt-1">Direct publishing</p>
                    </div>
                    
                    <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow text-center">
                      <div className="w-16 h-16 mx-auto bg-indigo-100 rounded-full flex items-center justify-center mb-3">
                        <svg className="h-8 w-8 text-indigo-600" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                        </svg>
                      </div>
                      <h4 className="font-medium text-gray-900">HTML Export</h4>
                      <p className="text-sm text-gray-500 mt-1">Universal compatibility</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-10 lg:mt-0 lg:col-span-5 order-1 lg:order-2">
                <h3 className="text-2xl font-extrabold text-gray-900 sm:text-3xl">
                  Multi-Platform Publishing
                </h3>
                <p className="mt-3 text-lg text-gray-500">
                  Publish your reviews instantly to any platform of your choice. ReviewPro ensures your content is formatted perfectly for each platform, maintaining your SEO optimization and visual elements.
                </p>
                <div className="mt-10">
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">One-click publishing</span> to WordPress, Blogger, Medium, and more
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">Platform-specific optimization</span> for maximum engagement on each platform
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-6 w-6 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-base text-gray-500">
                        <span className="font-medium text-gray-900">HTML export option</span> for universal compatibility with any CMS
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Demo images section */}
          <div className="mt-32">
            <div className="text-center">
              <h3 className="text-2xl font-extrabold text-gray-900 sm:text-3xl">
                See ReviewPro in Action
              </h3>
              <p className="mt-3 text-lg text-gray-500 max-w-2xl mx-auto">
                Browse through our application screenshots to see how ReviewPro transforms your review creation workflow.
              </p>
            </div>
            <div className="mt-12">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
                {/* Image 1 */}
                <div className="rounded-xl shadow-lg overflow-hidden border border-gray-200">
                  <div className="h-6 bg-gray-200 flex items-center px-2 space-x-1">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                  </div>
                  <img 
                    src={dashboardImg} 
                    alt="ReviewPro Dashboard" 
                    className="w-full h-auto object-contain max-h-[200px]"
                  />
                  <div className="p-3 bg-gray-50">
                    <p className="text-sm text-gray-600 font-medium">Dashboard Overview</p>
                  </div>
                </div>
                
                {/* Image 2 */}
                <div className="rounded-xl shadow-lg overflow-hidden border border-gray-200">
                  <div className="h-6 bg-gray-200 flex items-center px-2 space-x-1">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                  </div>
                  <img 
                    src={productDetailsImg} 
                    alt="Product Details Configuration" 
                    className="w-full h-auto object-contain max-h-[200px]"
                  />
                  <div className="p-3 bg-gray-50">
                    <p className="text-sm text-gray-600 font-medium">Product Details Setup</p>
                  </div>
                </div>
                
                {/* Image 3 */}
                <div className="rounded-xl shadow-lg overflow-hidden border border-gray-200">
                  <div className="h-6 bg-gray-200 flex items-center px-2 space-x-1">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                  </div>
                  <img 
                    src={reviewSettingsImg} 
                    alt="Review Settings Interface" 
                    className="w-full h-auto object-contain max-h-[200px]"
                  />
                  <div className="p-3 bg-gray-50">
                    <p className="text-sm text-gray-600 font-medium">Review Configuration</p>
                  </div>
                </div>
                
                {/* Image 4 */}
                <div className="rounded-xl shadow-lg overflow-hidden border border-gray-200">
                  <div className="h-6 bg-gray-200 flex items-center px-2 space-x-1">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                  </div>
                  <img 
                    src={productImagesImg} 
                    alt="Product Images Management" 
                    className="w-full h-auto object-contain max-h-[200px]"
                  />
                  <div className="p-3 bg-gray-50">
                    <p className="text-sm text-gray-600 font-medium">Image Management</p>
                  </div>
                </div>
                
                {/* Image 5 */}
                <div className="rounded-xl shadow-lg overflow-hidden border border-gray-200">
                  <div className="h-6 bg-gray-200 flex items-center px-2 space-x-1">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                  </div>
                  <img 
                    src={seoOptimizationImg} 
                    alt="SEO Optimization Tools" 
                    className="w-full h-auto object-contain max-h-[200px]"
                  />
                  <div className="p-3 bg-gray-50">
                    <p className="text-sm text-gray-600 font-medium">SEO Optimization</p>
                  </div>
                </div>
                
                {/* Image 6 */}
                <div className="rounded-xl shadow-lg overflow-hidden border border-gray-200">
                  <div className="h-6 bg-gray-200 flex items-center px-2 space-x-1">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                    <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                  </div>
                  <img 
                    src={homeImg} 
                    alt="ReviewPro Home Interface" 
                    className="w-full h-auto object-contain max-h-[200px]"
                  />
                  <div className="p-3 bg-gray-50">
                    <p className="text-sm text-gray-600 font-medium">Home Interface</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Templates section */}
      <div id="templates" className="py-20 bg-indigo-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full bg-indigo-100 text-indigo-800 mb-2">TEMPLATES</span>
            <h2 className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl md:text-5xl">
              Ready-to-Use Review Templates
            </h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
              Our library of professionally designed templates helps you create engaging reviews in minutes
            </p>
          </div>
          
          <div className="mt-16 grid grid-cols-1 gap-6 md:grid-cols-3 lg:grid-cols-5">
            {/* Template 1 */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="relative">
                <div className="h-40 bg-gradient-to-r from-indigo-500 to-indigo-600 flex items-center justify-center">
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0" style={{ 
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                      backgroundSize: '30px 30px'
                    }}></div>
                  </div>
                  <div className="z-10 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  </div>
                </div>
                <div className="absolute top-3 right-3 bg-indigo-100 text-indigo-800 text-xs font-semibold px-2 py-0.5 rounded-full">
                  Popular
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">SaaS Product Review</h3>
                <p className="text-gray-500 text-sm mb-3">Perfect for reviewing software with detailed feature analysis.</p>
                <div className="flex flex-wrap gap-1">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    SEO Optimized
                  </span>
                </div>
              </div>
            </div>
            
            {/* Template 2 */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="relative">
                <div className="h-40 bg-gradient-to-r from-indigo-500 to-indigo-600 flex items-center justify-center">
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0" style={{ 
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                      backgroundSize: '30px 30px'
                    }}></div>
                  </div>
                  <div className="z-10 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 4v12l-4-2-4 2V4M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">Physical Product Review</h3>
                <p className="text-gray-500 text-sm mb-3">Ideal for reviewing physical products with image galleries.</p>
                <div className="flex flex-wrap gap-1">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    Affiliate-Ready
                  </span>
                </div>
              </div>
            </div>
            
            {/* Template 3 */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="relative">
                <div className="h-40 bg-gradient-to-r from-indigo-500 to-indigo-600 flex items-center justify-center">
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0" style={{ 
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                      backgroundSize: '30px 30px'
                    }}></div>
                  </div>
                  <div className="z-10 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">Course Review Template</h3>
                <p className="text-gray-500 text-sm mb-3">For online courses with curriculum breakdown and analysis.</p>
                <div className="flex flex-wrap gap-1">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    Video-Friendly
                  </span>
                </div>
              </div>
            </div>

            {/* Template 4 */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="relative">
                <div className="h-40 bg-gradient-to-r from-indigo-500 to-indigo-600 flex items-center justify-center">
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0" style={{ 
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                      backgroundSize: '30px 30px'
                    }}></div>
                  </div>
                  <div className="z-10 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
                    </svg>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">E-commerce Review</h3>
                <p className="text-gray-500 text-sm mb-3">For comparing multiple products with pricing tables and ratings.</p>
                <div className="flex flex-wrap gap-1">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    Comparison Tables
                  </span>
                </div>
              </div>
            </div>

            {/* Template 5 */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="relative">
                <div className="h-40 bg-gradient-to-r from-indigo-500 to-indigo-600 flex items-center justify-center">
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0" style={{ 
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                      backgroundSize: '30px 30px'
                    }}></div>
                  </div>
                  <div className="z-10 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z" />
                    </svg>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">App Review Template</h3>
                <p className="text-gray-500 text-sm mb-3">For mobile and desktop application reviews with screenshots.</p>
                <div className="flex flex-wrap gap-1">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    UI/UX Focus
                  </span>
                </div>
              </div>
            </div>
            
            {/* Row 2 - Template 6 */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="relative">
                <div className="h-40 bg-gradient-to-r from-indigo-500 to-indigo-600 flex items-center justify-center">
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0" style={{ 
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                      backgroundSize: '30px 30px'
                    }}></div>
                  </div>
                  <div className="z-10 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">Tech Gadget Review</h3>
                <p className="text-gray-500 text-sm mb-3">For electronics and tech devices with video demonstrations.</p>
                <div className="flex flex-wrap gap-1">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    Video Embeds
                  </span>
                </div>
              </div>
            </div>
            
            {/* Template 7 */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="relative">
                <div className="h-40 bg-gradient-to-r from-indigo-500 to-indigo-600 flex items-center justify-center">
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0" style={{ 
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                      backgroundSize: '30px 30px'
                    }}></div>
                  </div>
                  <div className="z-10 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                    </svg>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">Roundup Review</h3>
                <p className="text-gray-500 text-sm mb-3">For "best of" lists and multiple product comparisons.</p>
                <div className="flex flex-wrap gap-1">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    Top 10 Format
                  </span>
                </div>
              </div>
            </div>

            {/* Template 8 */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="relative">
                <div className="h-40 bg-gradient-to-r from-indigo-500 to-indigo-600 flex items-center justify-center">
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0" style={{ 
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                      backgroundSize: '30px 30px'
                    }}></div>
                  </div>
                  <div className="z-10 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                    </svg>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">Long-Form Review</h3>
                <p className="text-gray-500 text-sm mb-3">Comprehensive in-depth analysis with multiple sections.</p>
                <div className="flex flex-wrap gap-1">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    Expert Level
                  </span>
                </div>
              </div>
            </div>

            {/* Template 9 */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="relative">
                <div className="h-40 bg-gradient-to-r from-indigo-500 to-indigo-600 flex items-center justify-center">
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0" style={{ 
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                      backgroundSize: '30px 30px'
                    }}></div>
                  </div>
                  <div className="z-10 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                  </div>
                </div>
                <div className="absolute top-3 right-3 bg-indigo-100 text-indigo-800 text-xs font-semibold px-2 py-0.5 rounded-full">
                  New
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">Product Update Review</h3>
                <p className="text-gray-500 text-sm mb-3">For revisiting products with new features or versions.</p>
                <div className="flex flex-wrap gap-1">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    Comparison
                  </span>
                </div>
              </div>
            </div>
            
            {/* Template 10 */}
            <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="relative">
                <div className="h-40 bg-gradient-to-r from-indigo-500 to-indigo-600 flex items-center justify-center">
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0" style={{ 
                      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath opacity='.5' d='M96 95h4v1h-4v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4h-9v4h-1v-4H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15v-9H0v-1h15V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h9V0h1v15h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9h4v1h-4v9zm-1 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm9-10v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-10 0v-9h-9v9h9zm-9-10h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9zm10 0h9v-9h-9v9z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                      backgroundSize: '30px 30px'
                    }}></div>
                  </div>
                  <div className="z-10 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z" />
                    </svg>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-lg font-bold text-gray-900 mb-1">Niche Review Template</h3>
                <p className="text-gray-500 text-sm mb-3">Specialized for specific industries with custom sections.</p>
                <div className="flex flex-wrap gap-1">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    Customizable
                  </span>
                </div>
              </div>
            </div>
          </div>
          

        </div>
      </div>
      
      {/* Resources section */}
      <div id="resources" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full bg-indigo-100 text-indigo-800 mb-2">RESOURCES</span>
            <h2 className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl md:text-5xl">
              Helpful Resources for Reviewers
            </h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
              Expert guides, tutorials, and tools to help you create reviews that drive traffic and conversions
            </p>
          </div>
          
          <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {/* Resource 1 */}
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-shadow">
              <div className="aspect-w-16 aspect-h-9 bg-gray-100">
                <div className="w-full h-48 bg-indigo-100 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-20 w-20 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center mb-2">
                  <span className="bg-indigo-100 text-indigo-800 text-xs font-semibold mr-2 px-2.5 py-0.5 rounded">Guide</span>
                  <span className="text-gray-500 text-sm">10 min read</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">The Ultimate SEO Guide for Review Content</h3>
                <p className="text-gray-600 mb-4">Learn how to optimize your review content for search engines to drive more organic traffic.</p>
                <a href="/resources/seo-guide" className="text-indigo-600 hover:text-indigo-500 font-medium inline-flex items-center">
                  Read Guide
                  <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </a>
              </div>
            </div>
            
            {/* Resource 2 */}
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-shadow">
              <div className="aspect-w-16 aspect-h-9 bg-gray-100">
                <div className="w-full h-48 bg-blue-100 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-20 w-20 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center mb-2">
                  <span className="bg-blue-100 text-blue-800 text-xs font-semibold mr-2 px-2.5 py-0.5 rounded">Video Tutorial</span>
                  <span className="text-gray-500 text-sm">25 min</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">How to Create Video Reviews That Convert</h3>
                <p className="text-gray-600 mb-4">Master the art of creating compelling video reviews that drive product conversions and engagement.</p>
                <a href="/resources/video-reviews" className="text-indigo-600 hover:text-indigo-500 font-medium inline-flex items-center">
                  Watch Tutorial
                  <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </a>
              </div>
            </div>
            
            {/* Resource 3 */}
            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-shadow">
              <div className="aspect-w-16 aspect-h-9 bg-gray-100">
                <div className="w-full h-48 bg-indigo-100 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-20 w-20 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
                  </svg>
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center mb-2">
                  <span className="bg-indigo-100 text-indigo-800 text-xs font-semibold mr-2 px-2.5 py-0.5 rounded">Analytics</span>
                  <span className="text-gray-500 text-sm">Interactive</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Review Performance Analytics Dashboard</h3>
                <p className="text-gray-600 mb-4">Track your review performance with our interactive dashboard. Monitor traffic, conversions and engagement.</p>
                <a href="/resources/analytics-dashboard" className="text-indigo-600 hover:text-indigo-500 font-medium inline-flex items-center">
                  Try Dashboard
                  <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </a>
              </div>
            </div>
          </div>
          
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Resource Stat 1 */}
            <div className="bg-indigo-50 rounded-lg p-6 text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-indigo-100 text-indigo-600 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">50+</h3>
              <p className="text-gray-600">Comprehensive guides</p>
            </div>
            
            {/* Resource Stat 2 */}
            <div className="bg-indigo-50 rounded-lg p-6 text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-indigo-100 text-indigo-600 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">30+</h3>
              <p className="text-gray-600">Video tutorials</p>
            </div>
            
            {/* Resource Stat 3 */}
            <div className="bg-indigo-50 rounded-lg p-6 text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-indigo-100 text-indigo-600 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">100+</h3>
              <p className="text-gray-600">Templates & checklists</p>
            </div>
            
            {/* Resource Stat 4 */}
            <div className="bg-indigo-50 rounded-lg p-6 text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-indigo-100 text-indigo-600 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">24/7</h3>
              <p className="text-gray-600">Expert support</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Pricing section */}
      <div id="pricing" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full bg-indigo-100 text-indigo-800 mb-2">PRICING</span>
            <h2 className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl md:text-5xl">
              Simple, Transparent Pricing
            </h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
              Choose the plan that's right for your content creation needs. No hidden fees or complicated contracts.
            </p>
            <div className="mt-8 flex justify-center">
              <div className="relative bg-white p-0.5 rounded-lg flex shadow">
                <span className="sr-only">View pricing options</span>
                <button
                  type="button"
                  className={`relative whitespace-nowrap rounded-md py-2 px-6 text-sm font-medium ${
                    billingCycle === 'monthly' 
                    ? 'bg-indigo-50 text-indigo-700' 
                    : 'text-gray-700 hover:bg-indigo-50'
                  } focus:z-10 focus:outline-none`}
                  onClick={() => setBillingCycle('monthly')}
                >
                  Monthly billing
                </button>
                <button
                  type="button"
                  className={`relative ml-0.5 whitespace-nowrap rounded-md py-2 px-6 text-sm font-medium ${
                    billingCycle === 'yearly'
                    ? 'bg-indigo-50 text-indigo-700'
                    : 'text-gray-700 hover:bg-indigo-50'
                  } focus:z-10 focus:outline-none`}
                  onClick={() => setBillingCycle('yearly')}
                >
                  Annual billing
                  <span className="absolute -top-2 -right-2 flex h-5 w-auto items-center justify-center rounded-full bg-green-100 px-1.5 text-xs font-semibold text-green-800">
                    Save 25%
                  </span>
                </button>
              </div>
            </div>
          </div>

          <div className="mt-16">
            <div className="grid grid-cols-1 gap-y-12 md:gap-x-6 lg:gap-x-8 md:grid-cols-4">
              {/* Free Trial Plan */}
              <div className="relative bg-white rounded-2xl shadow-xl overflow-hidden border border-green-300 flex flex-col h-full transition-all hover:shadow-2xl hover:-translate-y-1">
                <div className="absolute top-0 inset-x-0">
                  <div className="py-1 px-4 bg-green-500 text-white text-center text-xs font-semibold">
                    FREE TRIAL
                  </div>
                </div>
                <div className="p-8 text-center pt-12">
                  <h3 className="text-2xl font-bold text-gray-900">Free Trial</h3>
                  <p className="mt-4 text-sm text-gray-500">
                    Experience all the features for 3 days without any commitment. No credit card required.
                  </p>
                  <div className="mt-6">
                    <div className="flex justify-center items-baseline">
                      <span className="text-5xl font-extrabold text-gray-900">$0</span>
                      <span className="ml-1 text-xl text-gray-500">/3 days</span>
                    </div>
                    <div className="mt-2">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        No credit card
                      </span>
                    </div>
                  </div>
                  <div className="mt-8">
                    <Link href="/checkout/free/monthly">
                      <Button 
                        className="w-full"
                        variant="default"
                      >
                        Start Free Trial
                      </Button>
                    </Link>
                  </div>
                </div>
                <div className="flex-grow border-t border-gray-200 bg-gray-50 px-8 py-6">
                  <h4 className="text-sm font-medium text-gray-900 tracking-wide uppercase">What's included</h4>
                  <ul className="mt-6 space-y-4">
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-green-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">3 AI-generated reviews</span> during trial
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-green-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Basic SEO optimization</span> for all reviews
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-green-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Standard templates</span> for reviews
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-green-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">3-day access</span> to all features
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-green-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Email support</span> during trial period
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-green-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">No credit card</span> required to start
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
              
              {/* Basic Plan */}
              <div className="relative bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200 flex flex-col h-full transition-all hover:shadow-2xl hover:-translate-y-1">
                <div className="p-8 text-center">
                  <h3 className="text-2xl font-bold text-gray-900">Basic</h3>
                  <p className="mt-4 text-sm text-gray-500">
                    Perfect for solo content creators and small websites just getting started with product reviews.
                  </p>
                  <div className="mt-6">
                    <div className="flex justify-center items-baseline">
                      <span className="text-5xl font-extrabold text-gray-900">
                        ${billingCycle === 'monthly' ? '29' : '249'}
                      </span>
                      <span className="ml-1 text-xl text-gray-500">
                        {billingCycle === 'monthly' ? '/mo' : '/year'}
                      </span>
                    </div>
                    <p className="mt-1 text-gray-500 line-through text-sm">
                      {billingCycle === 'monthly' ? '$49/mo' : '$588/year'}
                    </p>
                    <div className="mt-2">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                        Save {billingCycle === 'monthly' ? '40%' : '58%'}
                      </span>
                    </div>
                  </div>
                  <div className="mt-8">
                    <Link href={`/checkout/basic/${billingCycle}`}>
                      <Button 
                        className="w-full"
                        variant="outline"
                      >
                        Choose Basic
                      </Button>
                    </Link>
                  </div>
                </div>
                <div className="flex-grow border-t border-gray-200 bg-gray-50 px-8 py-6">
                  <h4 className="text-sm font-medium text-gray-900 tracking-wide uppercase">What's included</h4>
                  <ul className="mt-6 space-y-4">
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">20 AI-generated reviews</span> per month
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Basic SEO optimization</span> for all reviews
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">3 design themes</span> to choose from
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Standard review templates</span> for various products
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Email support</span> with 24-hour response time
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <XIcon className="h-5 w-5 text-gray-400" />
                      </div>
                      <p className="ml-3 text-sm text-gray-500">
                        Advanced conversion features
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <XIcon className="h-5 w-5 text-gray-400" />
                      </div>
                      <p className="ml-3 text-sm text-gray-500">
                        Template library access
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <XIcon className="h-5 w-5 text-gray-400" />
                      </div>
                      <p className="ml-3 text-sm text-gray-500">
                        Priority support
                      </p>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Pro Plan */}
              <div className="relative bg-white rounded-2xl shadow-xl overflow-hidden border-2 border-indigo-500 flex flex-col h-full transition-all hover:shadow-2xl hover:-translate-y-1 transform scale-105 z-10">
                <div className="absolute top-0 inset-x-0">
                  <div className="py-1 px-4 bg-indigo-500 text-white text-center text-xs font-semibold">
                    MOST POPULAR
                  </div>
                </div>
                <div className="p-8 text-center pt-12">
                  <h3 className="text-2xl font-bold text-gray-900">Pro</h3>
                  <p className="mt-4 text-sm text-gray-500">
                    Designed for marketing professionals and serious affiliate websites with regular review needs.
                  </p>
                  <div className="mt-6">
                    <div className="flex justify-center items-baseline">
                      <span className="text-5xl font-extrabold text-gray-900">
                        ${billingCycle === 'monthly' ? '49' : '419'}
                      </span>
                      <span className="ml-1 text-xl text-gray-500">
                        {billingCycle === 'monthly' ? '/mo' : '/year'}
                      </span>
                    </div>
                    <p className="mt-1 text-gray-500 line-through text-sm">
                      {billingCycle === 'monthly' ? '$79/mo' : '$948/year'}
                    </p>
                    <div className="mt-2">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                        Save {billingCycle === 'monthly' ? '38%' : '56%'}
                      </span>
                    </div>
                  </div>
                  <div className="mt-8">
                    <Link href={`/checkout/pro/${billingCycle}`}>
                      <Button 
                        className="w-full"
                      >
                        Choose Pro
                      </Button>
                    </Link>
                  </div>
                </div>
                <div className="flex-grow border-t border-gray-200 bg-gray-50 px-8 py-6">
                  <h4 className="text-sm font-medium text-gray-900 tracking-wide uppercase">What's included</h4>
                  <ul className="mt-6 space-y-4">
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">50 AI-generated reviews</span> per month
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Advanced SEO optimization</span> with schema markup
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">All design themes</span> with customization options
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Premium review templates</span> with higher conversions
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Priority email support</span> with 8-hour response time
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Advanced conversion features</span> including A/B testing
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Template library access</span> with premium templates
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <XIcon className="h-5 w-5 text-gray-400" />
                      </div>
                      <p className="ml-3 text-sm text-gray-500">
                        API access
                      </p>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Agency Plan */}
              <div className="relative bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-200 flex flex-col h-full transition-all hover:shadow-2xl hover:-translate-y-1">
                <div className="p-8 text-center">
                  <h3 className="text-2xl font-bold text-gray-900">Agency</h3>
                  <p className="mt-4 text-sm text-gray-500">
                    Full-featured solution for agencies and power users managing multiple sites and clients.
                  </p>
                  <div className="mt-6">
                    <div className="flex justify-center items-baseline">
                      <span className="text-5xl font-extrabold text-gray-900">
                        ${billingCycle === 'monthly' ? '99' : '849'}
                      </span>
                      <span className="ml-1 text-xl text-gray-500">
                        {billingCycle === 'monthly' ? '/mo' : '/year'}
                      </span>
                    </div>
                    <p className="mt-1 text-gray-500 line-through text-sm">
                      {billingCycle === 'monthly' ? '$149/mo' : '$1,788/year'}
                    </p>
                    <div className="mt-2">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                        Save {billingCycle === 'monthly' ? '33%' : '53%'}
                      </span>
                    </div>
                  </div>
                  <div className="mt-8">
                    <Link href={`/checkout/agency/${billingCycle}`}>
                      <Button 
                        className="w-full"
                        variant="outline"
                      >
                        Choose Agency
                      </Button>
                    </Link>
                  </div>
                </div>
                <div className="flex-grow border-t border-gray-200 bg-gray-50 px-8 py-6">
                  <h4 className="text-sm font-medium text-gray-900 tracking-wide uppercase">What's included</h4>
                  <ul className="mt-6 space-y-4">
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Unlimited AI-generated reviews</span>
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Advanced SEO optimization</span> with custom schema
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">All design themes + exclusives</span> with full customization
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Premium review templates</span> with highest conversions
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Priority email & chat support</span> with 4-hour response time
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Advanced conversion features</span> with advanced analytics
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">Template library access</span> with ability to create custom templates
                      </p>
                    </li>
                    <li className="flex items-start">
                      <div className="flex-shrink-0">
                        <CheckIcon className="h-5 w-5 text-indigo-500" />
                      </div>
                      <p className="ml-3 text-sm text-gray-700">
                        <span className="font-medium">API access & white-labeling</span> for client portals
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Money-back guarantee */}
          <div className="mt-16 text-center">
            <div className="inline-flex items-center justify-center py-3 px-5 rounded-lg bg-indigo-50 border border-indigo-200">
              <ShieldCheckIcon className="h-5 w-5 text-indigo-500 mr-2" />
              <span className="text-sm font-medium text-indigo-800">30-day money-back guarantee</span>
            </div>
            <p className="mt-4 text-gray-500 max-w-2xl mx-auto">
              Sign up for a free 3-day trial to test all features, then choose the plan that works for you.
            </p>
          </div>
        </div>
      </div>

      {/* Testimonials section */}
      <div id="testimonials" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full bg-indigo-100 text-indigo-800 mb-2">TESTIMONIALS</span>
            <h2 className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl md:text-5xl">
              What our users are saying
            </h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
              Don't just take our word for it. See what content creators and marketers love about our platform.
            </p>
          </div>

          <div className="mt-16">
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
              {testimonials.map((testimonial, index) => (
                <Testimonial
                  key={index}
                  quote={testimonial.quote}
                  author={testimonial.author}
                  role={testimonial.role}
                  rating={testimonial.rating}
                  avatarUrl={testimonial.avatarUrl}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* FAQ section */}
      <div id="faq" className="py-20 bg-gradient-to-b from-white via-indigo-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full bg-indigo-100 text-indigo-800 mb-2">FAQ</span>
            <h2 className="mt-2 text-3xl font-extrabold text-gray-900 sm:text-4xl md:text-5xl">
              Frequently asked questions
            </h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
              Everything you need to know about our review generator platform.
            </p>
          </div>

          <div className="relative">
            {/* Background decoration */}
            <div className="hidden lg:block absolute -left-16 top-1/4 w-32 h-32 bg-indigo-200 opacity-20 rounded-full blur-2xl"></div>
            <div className="hidden lg:block absolute -right-16 bottom-1/4 w-40 h-40 bg-purple-200 opacity-20 rounded-full blur-3xl"></div>
            
            {/* FAQ Grid */}
            <div className="relative max-w-4xl mx-auto grid grid-cols-1 gap-5 md:grid-cols-2">
              {faqs.map((faq, index) => (
                <FAQItem
                  key={index}
                  question={faq.question}
                  answer={faq.answer}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* CTA section */}
      <div className="bg-indigo-700">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8 lg:flex lg:items-center lg:justify-between">
          <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            <span className="block">Ready to get started?</span>
            <span className="block text-indigo-200">Start creating professional reviews today.</span>
          </h2>
          <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
            <div className="inline-flex rounded-md shadow">
              <a href="#pricing">
                <Button 
                  size="lg" 
                  className="bg-white hover:bg-gray-50 text-indigo-700"
                >
                  Start Free Trial
                </Button>
              </a>
            </div>
            <div className="ml-3 inline-flex rounded-md shadow">
              <Link href="/#features">
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="bg-indigo-600 hover:bg-indigo-700 text-white border-white"
                >
                  Learn more
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
          <div className="xl:grid xl:grid-cols-3 xl:gap-8">
            <div className="space-y-8 xl:col-span-1">
              <Link href="/" className="flex items-center hover:opacity-80 transition-opacity">
                <svg viewBox="0 0 32 32" className="h-8 w-8 text-indigo-400 mr-2" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M27 14.8889C27 20.7981 21.1797 25.6667 14 25.6667C6.82031 25.6667 1 20.7981 1 14.8889C1 8.97969 6.82031 4.11111 14 4.11111" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  <path d="M19.6667 5.44444L17 8.11111L19.6667 10.7778" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M14 4.11111C21.1797 4.11111 27 8.97969 27 14.8889" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  <circle cx="23.5" cy="6.5" r="6.5" fill="currentColor" fillOpacity="0.3"/>
                </svg>
                <div className="flex items-center">
                  <span className="font-bold text-2xl text-white">ReviewPro</span>
                  <span className="ml-1 text-xs px-1.5 py-0.5 bg-indigo-700 text-indigo-100 rounded font-medium">PRO</span>
                </div>
              </Link>
              <p className="text-gray-300 text-base">
                The powerful platform for creating conversion-focused product reviews that rank higher and sell more effectively.
              </p>
            </div>
            <div className="mt-12 grid grid-cols-2 gap-8 xl:mt-0 xl:col-span-2">
              <div className="md:grid md:grid-cols-2 md:gap-8">
                <div>
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Product</h3>
                  <ul className="mt-4 space-y-4">
                    <li>
                      <Link href="/#features" className="text-base text-gray-300 hover:text-white">Features</Link>
                    </li>
                    <li>
                      <Link href="/#pricing" className="text-base text-gray-300 hover:text-white">Pricing</Link>
                    </li>
                    <li>
                      <Link href="/product/roadmap" className="text-base text-gray-300 hover:text-white">Roadmap</Link>
                    </li>
                    <li>
                      <Link href="/product/api" className="text-base text-gray-300 hover:text-white">API</Link>
                    </li>
                  </ul>
                </div>
                <div className="mt-12 md:mt-0">
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Support</h3>
                  <ul className="mt-4 space-y-4">
                    <li>
                      <Link href="/support/help-center" className="text-base text-gray-300 hover:text-white">Help Center</Link>
                    </li>
                    <li>
                      <Link href="/support/documentation" className="text-base text-gray-300 hover:text-white">Documentation</Link>
                    </li>
                    <li>
                      <Link href="/support/tutorials" className="text-base text-gray-300 hover:text-white">Tutorials</Link>
                    </li>
                    <li>
                      <Link href="/support/contact" className="text-base text-gray-300 hover:text-white">Contact Us</Link>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="md:grid md:grid-cols-2 md:gap-8">
                <div>
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Company</h3>
                  <ul className="mt-4 space-y-4">
                    <li>
                      <Link href="/company/about" className="text-base text-gray-300 hover:text-white">About</Link>
                    </li>
                    <li>
                      <Link href="/company/blog" className="text-base text-gray-300 hover:text-white">Blog</Link>
                    </li>
                    <li>
                      <Link href="/company/jobs" className="text-base text-gray-300 hover:text-white">Jobs</Link>
                    </li>
                    <li>
                      <Link href="/company/press" className="text-base text-gray-300 hover:text-white">Press</Link>
                    </li>
                  </ul>
                </div>
                <div className="mt-12 md:mt-0">
                  <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Legal</h3>
                  <ul className="mt-4 space-y-4">
                    <li>
                      <Link href="/privacy" className="text-base text-gray-300 hover:text-white">Privacy</Link>
                    </li>
                    <li>
                      <Link href="/terms" className="text-base text-gray-300 hover:text-white">Terms</Link>
                    </li>
                    <li>
                      <Link href="/data-policy" className="text-base text-gray-300 hover:text-white">Data Policy</Link>
                    </li>
                    <li>
                      <Link href="/cookies" className="text-base text-gray-300 hover:text-white">Cookies</Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-12 border-t border-gray-700 pt-8">
            <p className="text-base text-gray-400 md:text-center">
              &copy; {new Date().getFullYear()} ReviewPro. All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* Auth Dialog */}
      <AuthDialog isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </div>
  );
}