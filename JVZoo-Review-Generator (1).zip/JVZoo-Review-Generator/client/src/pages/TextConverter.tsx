import Header from "@/components/Header";
import SingleLineTextConverter from "@/components/SingleLineTextConverter";

export default function TextConverter() {
  return (
    <div className="container mx-auto px-4 py-6 md:py-8 max-w-7xl">
      <Header />
      
      <div className="mt-8">
        <h1 className="text-2xl font-bold mb-6 text-gray-800">Text Processing Tools</h1>
        <p className="mb-8 text-gray-600 max-w-3xl">
          Optimize your content with our suite of text processing tools. Use the Single Line Text Converter below
          to convert any multi-line text into a clean, single-line format - perfect for SEO meta descriptions,
          alt tags, and more.
        </p>
        
        <SingleLineTextConverter />
      </div>
    </div>
  );
}