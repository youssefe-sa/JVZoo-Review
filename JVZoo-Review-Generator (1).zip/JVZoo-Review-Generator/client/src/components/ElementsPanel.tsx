export default function ElementsPanel() {
  return (
    <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Quick Elements */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center">
            <i className="ri-layout-2-line text-lg text-indigo-600 mr-2"></i>
            <h2 className="text-lg font-semibold text-gray-800">Quick Elements</h2>
          </div>
        </div>
        <div className="p-4 grid grid-cols-2 gap-3">
          <button className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-all">
            <i className="ri-price-tag-3-line text-indigo-600 mr-2"></i>
            <span className="text-sm">Pricing Table</span>
          </button>
          <button className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-all">
            <i className="ri-list-check text-indigo-600 mr-2"></i>
            <span className="text-sm">Pros & Cons</span>
          </button>
          <button className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-all">
            <i className="ri-megaphone-line text-indigo-600 mr-2"></i>
            <span className="text-sm">CTA Banner</span>
          </button>
          <button className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-all">
            <i className="ri-image-line text-indigo-600 mr-2"></i>
            <span className="text-sm">Image Gallery</span>
          </button>
          <button className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-all">
            <i className="ri-star-line text-indigo-600 mr-2"></i>
            <span className="text-sm">Rating Box</span>
          </button>
          <button className="flex items-center justify-center p-3 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-all">
            <i className="ri-question-answer-line text-indigo-600 mr-2"></i>
            <span className="text-sm">FAQ Section</span>
          </button>
        </div>
      </div>

      {/* Recent Saves */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <i className="ri-history-line text-lg text-indigo-600 mr-2"></i>
              <h2 className="text-lg font-semibold text-gray-800">Recent Saves</h2>
            </div>
            <button className="text-xs text-gray-500 hover:text-indigo-600">View All</button>
          </div>
        </div>
        <div className="p-4">
          <div className="space-y-3">
            {/* Empty state when no saved reviews */}
            <div className="py-10 flex flex-col items-center justify-center text-gray-500">
              <i className="ri-history-line text-4xl mb-2"></i>
              <p className="text-sm">No saved reviews yet</p>
              <p className="text-xs mt-1">Your saved reviews will appear here</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
