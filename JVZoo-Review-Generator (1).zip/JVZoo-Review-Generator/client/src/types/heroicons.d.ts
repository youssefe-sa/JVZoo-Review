declare module '@heroicons/react/24/outline';
declare module '@heroicons/react/24/solid';
declare module '@heroicons/react/20/solid';