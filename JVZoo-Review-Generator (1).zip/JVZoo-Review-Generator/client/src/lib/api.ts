import axios from 'axios';

interface ApiRequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  data?: any;
  headers?: Record<string, string>;
  params?: Record<string, string>;
}

// Default API configuration
const api = axios.create({
  baseURL: '/',
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * Make a request to the API
 * @param endpoint The API endpoint to call
 * @param options Request options
 * @returns Promise with the response data
 */
export const apiRequest = async (endpoint: string, options: ApiRequestOptions = {}) => {
  try {
    const { method = 'GET', data, headers, params } = options;
    
    const response = await api.request({
      url: endpoint,
      method,
      data,
      headers,
      params,
    });
    
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      // Return the error message from the server
      throw new Error(error.response.data.message || 'Request failed');
    }
    throw error;
  }
};

/**
 * Set authorization token for all future requests
 * @param token JWT token
 */
export const setAuthToken = (token: string | null) => {
  if (token) {
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    delete api.defaults.headers.common['Authorization'];
  }
};

/**
 * Verify if an API key is valid
 * @param apiKey API key to verify
 * @param model Model to use with the API key
 * @returns Promise with the verification result
 */
export const verifyApiKey = async (apiKey: string, model: string): Promise<boolean> => {
  try {
    const response = await api.post('/api/verify-api-key', { 
      apiKey, 
      model 
    });
    
    return response.data.success === true;
  } catch (error) {
    console.error('API key verification failed:', error);
    return false;
  }
};

export default api;