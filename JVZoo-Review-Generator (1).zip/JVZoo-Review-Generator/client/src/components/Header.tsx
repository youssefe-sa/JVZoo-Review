import { useState, useEffect, useRef } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { toast } from "@/hooks/use-toast";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ChatDialog } from "./ChatDialog";
import { UserMenu } from "./UserMenu";
import { AuthDialog } from "./AuthDialog";
import { useAuth } from "@/lib/AuthContext";

// Define notification type
type Notification = {
  id: string;
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  type: 'info' | 'success' | 'warning' | 'error';
  icon: string;
  borderColor: string;
  bgHoverColor: string;
};

export default function Header() {
  const [isWhatsNewOpen, setIsWhatsNewOpen] = useState(false);
  const [isDocsDialogOpen, setIsDocsDialogOpen] = useState(false);
  const [isSupportDialogOpen, setIsSupportDialogOpen] = useState(false);
  const [isFaqDialogOpen, setIsFaqDialogOpen] = useState(false);
  const [isBugDialogOpen, setIsBugDialogOpen] = useState(false);

  const [isChatOpen, setIsChatOpen] = useState(false);
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [authDialogTab, setAuthDialogTab] = useState<'login' | 'register'>('login');
  const [scrolled, setScrolled] = useState(false);
  const headerRef = useRef<HTMLDivElement>(null);
  const { user, isAuthenticated } = useAuth();

  // Notifications state
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      title: 'New template available',
      message: 'We\'ve added a new review template for software products',
      timestamp: new Date(Date.now() - 10 * 60 * 1000), // 10 minutes ago
      read: false,
      type: 'info',
      icon: 'ri-award-line',
      borderColor: 'border-blue-500',
      bgHoverColor: 'hover:bg-blue-50/50'
    },
    {
      id: '2',
      title: 'Review successfully generated',
      message: 'Your review for "Advanced Marketing Suite" is ready',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      read: false,
      type: 'success',
      icon: 'ri-check-double-line',
      borderColor: 'border-green-500',
      bgHoverColor: 'hover:bg-green-50/50'
    }
  ]);

  // Get unread notifications count
  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  // Mark all notifications as read
  const markAllAsRead = () => {
    setNotifications(prev => prev.map(notification => ({ ...notification, read: true })));

    toast({
      title: "Notifications cleared",
      description: "All notifications have been marked as read",
    });
  };

  // Mark a single notification as read
  const markAsRead = (id: string) => {
    const notification = notifications.find(n => n.id === id);

    if (notification && !notification.read) {
      setNotifications(prev => 
        prev.map(n => 
          n.id === id 
            ? { ...n, read: true } 
            : n
        )
      );

      toast({
        title: `"${notification.title}" marked as read`,
        description: "Notification has been updated",
      });
    }
  };

  // Listen to scroll events to update header style
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      if (scrollPosition > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header className="mb-8 relative">
      {/* Top navigation bar with logo and login/logout */}
      <div 
        ref={headerRef}
        className={`bg-white shadow-md border-b border-gray-200 px-4 py-2 mb-4 flex items-center justify-between fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'mx-auto left-[2.5%] right-[2.5%] rounded-b-lg shadow-lg' : 'w-full'
        }`}
      >
        <Link href="/" className="flex items-center hover:opacity-80 transition-opacity">
          <svg viewBox="0 0 32 32" className="h-8 w-8 text-indigo-600 mr-2" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M27 14.8889C27 20.7981 21.1797 25.6667 14 25.6667C6.82031 25.6667 1 20.7981 1 14.8889C1 8.97969 6.82031 4.11111 14 4.11111" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            <path d="M19.6667 5.44444L17 8.11111L19.6667 10.7778" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M14 4.11111C21.1797 4.11111 27 8.97969 27 14.8889" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            <circle cx="23.5" cy="6.5" r="6.5" fill="currentColor" fillOpacity="0.3"/>
          </svg>
          <div className="flex flex-col">
            <div className="flex items-center">
              <span className="font-bold text-xl text-indigo-800">Review Generator</span>
              <span className="ml-1 text-xs px-1.5 py-0.5 bg-indigo-100 text-indigo-800 rounded font-medium">PRO</span>
            </div>
          </div>
        </Link>

        <div className="flex items-center space-x-3">
          {isAuthenticated && user ? (
            <>
              <div className="hidden md:flex items-center gap-3 bg-indigo-50 px-3 py-1.5 rounded-full border border-indigo-100">
                <div className="w-6 h-6 bg-gradient-to-br from-indigo-600 to-blue-400 rounded-full flex items-center justify-center text-white text-xs font-bold">
                  {user?.username?.charAt(0).toUpperCase() || 'U'}
                </div>
                <span className="text-sm font-medium text-indigo-700">
                  Welcome, {user?.username || 'User'}
                </span>
                <div className="h-4 w-4 bg-green-500 rounded-full relative animate-pulse">
                  <span className="absolute -top-0.5 -right-0.5 bg-white w-1.5 h-1.5 rounded-full"></span>
                </div>
              </div>

              <Link href="/dashboard">
                <Button variant="ghost" className="hidden md:flex items-center gap-1.5">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-layout-dashboard">
                    <rect width="7" height="9" x="3" y="3" rx="1"/>
                    <rect width="7" height="5" x="14" y="3" rx="1"/>
                    <rect width="7" height="9" x="14" y="12" rx="1"/>
                    <rect width="7" height="5" x="3" y="16" rx="1"/>
                  </svg>
                  Dashboard
                </Button>
              </Link>

              <div className="flex gap-2 items-center">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="hidden md:flex items-center gap-2 text-indigo-700 hover:text-indigo-900 hover:bg-indigo-50 relative"
                    >
                      <i className="ri-notification-3-line"></i>
                      {unreadNotificationsCount > 0 && (
                        <>
                          <span className="inline-flex items-center justify-center px-1.5 py-0.5 text-xs font-medium rounded-full bg-red-100 text-red-700">
                            {unreadNotificationsCount}
                          </span>
                          <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-red-500 border border-white animate-pulse"></span>
                        </>
                      )}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-80">
                    <div className="flex items-center justify-between px-3 py-2 border-b">
                      <h4 className="font-medium text-sm text-gray-700">
                        Notifications
                        {unreadNotificationsCount > 0 && (
                          <span className="ml-1.5 inline-flex items-center justify-center px-1.5 py-0.5 text-xs font-medium rounded-full bg-red-100 text-red-700">
                            {unreadNotificationsCount}
                          </span>
                        )}
                      </h4>
                      {unreadNotificationsCount > 0 && (
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 text-xs"
                          onClick={markAllAsRead}
                        >
                          Mark all as read
                        </Button>
                      )}
                    </div>
                    <div className="max-h-[420px] overflow-y-auto">
                      {notifications.length > 0 ? (
                        notifications.map(notification => (
                          <DropdownMenuItem 
                            key={notification.id} 
                            className="p-0 focus:bg-gray-100 cursor-default"
                            onSelect={(e) => {
                              e.preventDefault();
                              markAsRead(notification.id);
                            }}
                          >
                            <div className={`px-3 py-2.5 border-l-2 ${notification.borderColor} ${notification.bgHoverColor} transition-colors w-full ${notification.read ? 'opacity-60' : ''}`}>
                              <div className="flex items-start gap-3">
                                <div className={`w-9 h-9 rounded-full ${notification.type === 'info' ? 'bg-blue-100' : notification.type === 'success' ? 'bg-green-100' : notification.type === 'warning' ? 'bg-amber-100' : 'bg-red-100'} flex items-center justify-center flex-shrink-0`}>
                                  <i className={`${notification.icon} ${notification.type === 'info' ? 'text-blue-600' : notification.type === 'success' ? 'text-green-600' : notification.type === 'warning' ? 'text-amber-600' : 'text-red-600'}`}></i>
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-gray-800">{notification.title}</p>
                                  <p className="text-xs text-gray-500 mt-0.5">{notification.message}</p>
                                  <p className="text-xs text-gray-400 mt-1.5">
                                    {notification.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    {notification.read && <span className="ml-2 text-green-600">• Read</span>}
                                  </p>
                                </div>
                                {!notification.read && (
                                  <div className="w-2 h-2 rounded-full bg-blue-500 ml-auto mt-1"></div>
                                )}
                              </div>
                            </div>
                          </DropdownMenuItem>
                        ))
                      ) : (
                        <div className="py-8 text-center">
                          <div className="w-12 h-12 mx-auto rounded-full bg-gray-100 flex items-center justify-center mb-3">
                            <i className="ri-notification-off-line text-gray-400 text-xl"></i>
                          </div>
                          <p className="text-sm text-gray-500">No notifications yet</p>
                        </div>
                      )}
                    </div>
                    {notifications.length > 0 && (
                      <DropdownMenuSeparator />
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
                <UserMenu />
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => {
                  setAuthDialogTab('login');
                  setAuthDialogOpen(true);
                }}
                className="text-xs font-medium text-indigo-700 border-indigo-200 hover:bg-indigo-50"
              >
                Login
              </Button>
              <Button 
                size="sm" 
                onClick={() => {
                  setAuthDialogTab('register');
                  setAuthDialogOpen(true);
                }}
                className="bg-indigo-600 hover:bg-indigo-700 text-xs font-medium"
              >
                Sign Up
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Adding top padding to prevent content from being hidden under the fixed header */}
      <div className="pt-16 md:pt-16"></div>
      
      {/* Main header with spacing */}
      <div className="mt-6 mb-6">
        <div className="bg-gradient-to-br from-blue-600 via-indigo-700 to-indigo-800 p-6 md:p-8 rounded-xl shadow-lg text-white mb-4 relative overflow-hidden max-w-7xl mx-auto">
          {/* Abstract background elements */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-full -mt-16 -mr-16"></div>
          <div className="absolute bottom-0 left-0 w-40 h-40 bg-white opacity-5 rounded-full -mb-10 -ml-10"></div>

          <div className="relative z-10">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 md:mb-2">
              <div className="flex items-center mb-2 md:mb-0">
                <i className="ri-article-line text-2xl mr-3 text-indigo-200"></i>
                <h1 className="text-2xl md:text-3xl font-bold">Review Generator</h1>
                <div className="ml-3 relative">
                  <Badge className="bg-gradient-to-r from-amber-400 to-amber-500 text-amber-900 hover:from-amber-300 hover:to-amber-400 text-xs font-semibold shadow-sm">PRO</Badge>
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white animate-pulse"></div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {/* Help Dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="p-1.5 rounded-md bg-white/20 hover:bg-white/30 transition-all flex items-center text-xs font-medium text-white gap-1.5" aria-label="Help">
                      <i className="ri-question-line"></i>
                      <span className="hidden md:inline">Help</span>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-64 p-2">
                    <DropdownMenuItem 
                      className="cursor-pointer flex flex-col items-start"
                      onSelect={(e) => {
                        e.preventDefault();
                        setIsDocsDialogOpen(true);
                      }}
                    >
                      <div className="flex items-center">
                        <i className="ri-book-read-line mr-2 text-indigo-600"></i>
                        <span className="font-medium">Documentation</span>
                      </div>
                      <span className="text-xs text-gray-500 ml-6 mt-1">Complete user guides and tutorials</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="cursor-pointer flex flex-col items-start"
                      onSelect={(e) => {
                        e.preventDefault();
                        setIsSupportDialogOpen(true);
                      }}
                    >
                      <div className="flex items-center">
                        <i className="ri-customer-service-2-line mr-2 text-indigo-600"></i>
                        <span className="font-medium">Contact Support</span>
                      </div>
                      <span className="text-xs text-gray-500 ml-6 mt-1">Get help from our support team</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="cursor-pointer flex flex-col items-start"
                      onSelect={(e) => {
                        e.preventDefault();
                        setIsFaqDialogOpen(true);
                      }}
                    >
                      <div className="flex items-center">
                        <i className="ri-question-answer-line mr-2 text-indigo-600"></i>
                        <span className="font-medium">FAQ</span>
                      </div>
                      <span className="text-xs text-gray-500 ml-6 mt-1">Answers to common questions</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="cursor-pointer flex flex-col items-start"
                      onSelect={(e) => {
                        e.preventDefault();
                        setIsBugDialogOpen(true);
                      }}
                    >
                      <div className="flex items-center">
                        <i className="ri-bug-line mr-2 text-red-500"></i>
                        <span className="font-medium">Report a Bug</span>
                      </div>
                      <span className="text-xs text-gray-500 ml-6 mt-1">Help us improve by reporting issues</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                {/* What's New button */}
                <button 
                  onClick={() => setIsWhatsNewOpen(true)} 
                  className="hidden md:flex items-center px-3 py-1 bg-amber-400/30 hover:bg-amber-400/40 rounded-full text-xs font-medium transition-all shadow-sm border border-amber-400/40 relative group"
                >
                  <i className="ri-magic-line mr-1 text-amber-600"></i>
                  What's New
                  <span className="absolute -top-1 -right-1 flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
                  </span>
                  <span className="absolute left-0 -bottom-5 hidden group-hover:block text-amber-700 text-[10px] bg-amber-100 rounded px-1 whitespace-nowrap border border-amber-200">
                    New features added!
                  </span>
                </button>
              </div>
            </div>

            <p className="text-base md:text-lg opacity-90 mb-4">Generate professional, high-converting product reviews with advanced AI-powered elements</p>

            <div className="flex flex-wrap gap-2 mt-2">
              <span className="inline-flex items-center px-3 py-1.5 rounded-md text-xs font-medium bg-white text-indigo-700 border-2 border-indigo-400 shadow-sm animate-pulse">
                <i className="ri-rocket-line mr-1"></i> NEW! Interactive Tour
              </span>
              <span className="inline-flex items-center px-3 py-1.5 rounded-md text-xs font-medium bg-white text-indigo-700 border-2 border-indigo-400 shadow-sm animate-pulse" style={{ animationDelay: '0.3s' }}>
                <i className="ri-customer-service-2-line mr-1"></i> NEW! Chat Support
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-indigo-500/30 border border-indigo-400/30 text-white">
                <i className="ri-search-line mr-1"></i> SEO Optimization
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-purple-500/30 border border-purple-400/30 text-white">
                <i className="ri-paint-brush-line mr-1"></i> Multiple Themes
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-pink-500/30 border border-pink-400/30 text-white">
                <i className="ri-table-line mr-1"></i> Comparison Tables
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-blue-500/30 border border-blue-400/30 text-white">
                <i className="ri-image-line mr-1"></i> Visual Elements
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-green-500/30 border border-green-400/30 text-white">
                <i className="ri-file-list-3-line mr-1"></i> Template System
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-amber-500/30 border border-amber-400/30 text-white">
                <i className="ri-ai-generate mr-1"></i> Google AI Studio
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex items-center justify-between bg-white rounded-lg shadow-sm border border-gray-100 p-1.5 mb-4 max-w-7xl mx-auto">
        <div>
          <Link to="/">
            <span className="flex items-center px-4 py-2 rounded-md text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 transition-colors cursor-pointer">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
              </svg>
              Review Generator
            </span>
          </Link>
        </div>

        <div>
          <Link to="/text-tools">
            <span className="flex items-center px-4 py-2 rounded-md text-gray-700 hover:bg-indigo-50 hover:text-indigo-700 transition-colors cursor-pointer">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16m-7 6h7" />
              </svg>
              Text Tools
            </span>
          </Link>
        </div>
      </nav>

      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-100 p-4 rounded-md shadow-sm overflow-hidden relative max-w-7xl mx-auto">
        {/* Decorative elements */}
        <div className="absolute w-24 h-24 -right-6 -top-6 bg-indigo-100 rounded-full opacity-40"></div>
        <div className="absolute w-16 h-16 -left-4 -bottom-4 bg-purple-100 rounded-full opacity-50"></div>

        <div className="flex relative z-10">
          <div className="flex-shrink-0 bg-indigo-100 rounded-full p-2.5 h-fit mt-1">
            <i className="ri-award-line text-indigo-600 text-lg"></i>
          </div>
          <div className="ml-4">
            <div className="flex items-center mb-1">
              <p className="text-sm text-indigo-800 font-semibold">
                Enhanced 2025 Professional Features
              </p>
              <span className="ml-2 inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 border border-amber-200">
                <i className="ri-notification-3-line mr-0.5 text-amber-500"></i> NEW
              </span>
            </div>
            <p className="text-sm text-indigo-600 leading-relaxed">
              <span className="font-medium">April 2025 update available!</span> This professional version now includes:
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-100">
                <i className="ri-rocket-line mr-1 text-indigo-600"></i> New! Interactive Tour
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-100">
                <i className="ri-customer-service-2-line mr-1 text-indigo-600"></i> New! Smart Chat Support
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium text-gray-700">
                <i className="ri-check-line mr-1 text-green-600"></i> 5-Phase Analysis
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium text-gray-700">
                <i className="ri-check-line mr-1 text-green-600"></i> SEO Schema Markup
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium text-gray-700">
                <i className="ri-check-line mr-1 text-green-600"></i> Advanced Copywriting
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium text-gray-700">
                <i className="ri-check-line mr-1 text-green-600"></i> Extended Word Count
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium text-gray-700">
                <i className="ri-check-line mr-1 text-green-600"></i> Competitor Analysis
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium text-gray-700">
                <i className="ri-check-line mr-1 text-green-600"></i> AI Integration
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium text-gray-700">
                <i className="ri-check-line mr-1 text-green-600"></i> Guided Onboarding
              </span>
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium text-gray-700">
                <i className="ri-check-line mr-1 text-green-600"></i> 24/7 Assistant
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Live Chat Dialog */}
      <ChatDialog isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />

      {/* Auth Dialog */}
      <AuthDialog 
        isOpen={authDialogOpen} 
        onClose={() => setAuthDialogOpen(false)} 
        defaultTab={authDialogTab} 
      />
    </header>
  );
}