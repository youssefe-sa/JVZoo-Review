// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, User } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAhmfgBkzcA8ay44grfaLCYRckB_hUNwB8",
  authDomain: "jvzoo-70137.firebaseapp.com",
  projectId: "jvzoo-70137",
  storageBucket: "jvzoo-70137.firebasestorage.app",
  messagingSenderId: "148115020521",
  appId: "1:148115020521:web:a0cb1a21b161f166716e78"
};

// Initialize Firebase
// Use a function to create the Firebase app singleton
const getFirebaseApp = () => {
  try {
    return initializeApp(firebaseConfig);
  } catch (error: any) {
    // If already initialized, use that one
    if (error.code === 'app/duplicate-app') {
      return initializeApp(firebaseConfig, 'reviewPro');
    }
    throw error;
  }
};

const app = getFirebaseApp();

const auth = getAuth(app);
const db = getFirestore(app);

// Export the Firebase services
export { app, auth, db };

// Authentication functions
export const registerWithEmailAndPassword = async (email: string, password: string, username: string) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // You can store additional user data in Firestore here if needed
    
    return { success: true, user };
  } catch (error: any) {
    return { 
      success: false, 
      error: error.message || "An error occurred during registration" 
    };
  }
};

export const loginWithEmailAndPassword = async (email: string, password: string) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    return { success: true, user };
  } catch (error: any) {
    return { 
      success: false, 
      error: error.message || "Invalid email or password" 
    };
  }
};

export const logoutUser = async () => {
  try {
    await signOut(auth);
    return { success: true };
  } catch (error: any) {
    return { 
      success: false, 
      error: error.message || "An error occurred during logout" 
    };
  }
};

// A hook to observe auth state changes
export const onAuthStateChange = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, callback);
};