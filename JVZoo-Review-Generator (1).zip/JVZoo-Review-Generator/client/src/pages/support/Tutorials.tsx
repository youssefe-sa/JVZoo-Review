import React, { useState } from 'react';
import { Helmet } from "react-helmet";
import Layout from "@/components/Layout";
import { Search, Play, Clock, Tag, Video, BookOpen, ChevronRight, ArrowRight } from "lucide-react";

export default function Tutorials() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  
  // Tutorial categories
  const categories = [
    { id: "all", name: "All Tutorials" },
    { id: "getting-started", name: "Getting Started" },
    { id: "review-creation", name: "Review Creation" },
    { id: "templates", name: "Templates" },
    { id: "seo", name: "SEO Optimization" },
    { id: "publishing", name: "Publishing" },
    { id: "advanced", name: "Advanced Features" }
  ];
  
  // Tutorial videos
  const tutorials = [
    {
      id: 1,
      title: "Getting Started with ReviewPro",
      description: "Learn the basics of setting up your account and navigating the ReviewPro dashboard.",
      category: "getting-started",
      thumbnail: "https://images.unsplash.com/photo-1516321497487-e288fb19713f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      duration: "12:34",
      level: "Beginner",
      featured: true,
      videoUrl: "#"
    },
    {
      id: 2,
      title: "Creating Your First AI-Generated Review",
      description: "Step-by-step guide to creating a complete product review using ReviewPro's AI tools.",
      category: "review-creation",
      thumbnail: "https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      duration: "15:47",
      level: "Beginner",
      featured: true,
      videoUrl: "#"
    },
    {
      id: 3,
      title: "Customizing Review Templates",
      description: "Learn how to modify existing templates and create custom templates for different product categories.",
      category: "templates",
      thumbnail: "https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      duration: "18:23",
      level: "Intermediate",
      featured: false,
      videoUrl: "#"
    },
    {
      id: 4,
      title: "SEO Optimization for Product Reviews",
      description: "Master the SEO tools to create reviews that rank higher in search engines.",
      category: "seo",
      thumbnail: "https://images.unsplash.com/photo-1605310079730-482e8861b6c9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1169&q=80",
      duration: "21:17",
      level: "Intermediate",
      featured: true,
      videoUrl: "#"
    },
    {
      id: 5,
      title: "Publishing to WordPress",
      description: "Learn how to set up the WordPress integration and publish reviews directly to your site.",
      category: "publishing",
      thumbnail: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      duration: "14:56",
      level: "Intermediate",
      featured: false,
      videoUrl: "#"
    },
    {
      id: 6,
      title: "Creating Effective Comparison Tables",
      description: "Techniques for building product comparison tables that boost conversions and clarity.",
      category: "advanced",
      thumbnail: "https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      duration: "19:42",
      level: "Advanced",
      featured: false,
      videoUrl: "#"
    },
    {
      id: 7,
      title: "Advanced AI Text Generation Techniques",
      description: "Learn advanced prompts and settings to get the most out of ReviewPro's AI generation.",
      category: "advanced",
      thumbnail: "https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      duration: "26:38",
      level: "Advanced",
      featured: false,
      videoUrl: "#"
    },
    {
      id: 8,
      title: "Managing Multiple Reviews",
      description: "Workflow tips for efficiently managing and updating multiple product reviews.",
      category: "review-creation",
      thumbnail: "https://images.unsplash.com/photo-1587691592099-24045742c181?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1173&q=80",
      duration: "16:45",
      level: "Intermediate",
      featured: false,
      videoUrl: "#"
    }
  ];
  
  // Get filtered tutorials based on search and category
  const filteredTutorials = tutorials.filter(tutorial => {
    const matchesSearch = tutorial.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tutorial.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === "all" || tutorial.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  // Get featured tutorials
  const featuredTutorials = tutorials.filter(tutorial => tutorial.featured);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Search is handled through the state and filtering
    console.log("Searching for:", searchQuery);
  };

  return (
    <Layout variant="landing">
      <Helmet>
        <title>Video Tutorials | ReviewPro</title>
        <meta name="description" content="Learn how to use ReviewPro with our comprehensive video tutorials covering everything from getting started to advanced features." />
      </Helmet>
      
      <div className="bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Tutorials Header */}
          <div className="text-center">
            <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl lg:text-5xl">Video Tutorials</h1>
            <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
              Learn how to use ReviewPro effectively with our step-by-step video guides
            </p>
          </div>
          
          {/* Search Bar */}
          <div className="mt-12 max-w-3xl mx-auto">
            <form onSubmit={handleSearch} className="sm:flex">
              <div className="min-w-0 flex-1">
                <label htmlFor="search" className="sr-only">Search tutorials</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    id="search"
                    className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 pr-12 py-4 sm:text-lg border-gray-300 rounded-md"
                    placeholder="Search for tutorials..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              <div className="mt-3 sm:mt-0 sm:ml-3">
                <button
                  type="submit"
                  className="block w-full rounded-md border border-transparent px-5 py-4 bg-indigo-600 text-base font-medium text-white shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:px-10"
                >
                  Search
                </button>
              </div>
            </form>
          </div>
          
          {/* Category Filters */}
          <div className="mt-12">
            <div className="flex flex-wrap justify-center gap-4">
              {categories.map(category => (
                <button
                  key={category.id}
                  className={`px-4 py-2 rounded-full text-sm font-medium ${
                    selectedCategory === category.id
                      ? "bg-indigo-100 text-indigo-800"
                      : "bg-gray-100 text-gray-800 hover:bg-gray-200"
                  }`}
                  onClick={() => setSelectedCategory(category.id)}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
          
          {/* Featured Tutorials */}
          {selectedCategory === "all" && searchQuery === "" && (
            <div className="mt-16">
              <h2 className="text-2xl font-bold text-gray-900 mb-8">Featured Tutorials</h2>
              <div className="grid gap-8 md:grid-cols-3">
                {featuredTutorials.map(tutorial => (
                  <div key={tutorial.id} className="group relative">
                    <div className="relative h-60 w-full overflow-hidden rounded-lg bg-white shadow-lg">
                      <img
                        src={tutorial.thumbnail}
                        alt={tutorial.title}
                        className="h-full w-full object-cover group-hover:opacity-75 transition-opacity duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black opacity-60"></div>
                      <div className="absolute top-4 right-4 bg-indigo-600 rounded-full p-2">
                        <Play className="h-6 w-6 text-white" />
                      </div>
                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-medium text-white bg-indigo-600 px-2 py-1 rounded-full">
                            {tutorial.level}
                          </span>
                          <span className="text-xs font-medium text-white flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            {tutorial.duration}
                          </span>
                        </div>
                        <h3 className="mt-2 text-lg font-semibold text-white">{tutorial.title}</h3>
                      </div>
                    </div>
                    <a href={tutorial.videoUrl} className="absolute inset-0 focus:outline-none">
                      <span className="sr-only">View {tutorial.title}</span>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* All Tutorials */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">
              {selectedCategory === "all" ? "All Tutorials" : 
               categories.find(c => c.id === selectedCategory)?.name || "Tutorials"}
            </h2>
            
            {filteredTutorials.length === 0 ? (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <BookOpen className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">No tutorials found</h3>
                <p className="mt-1 text-gray-500">Try adjusting your search or filter to find what you're looking for.</p>
                <div className="mt-6">
                  <button
                    className="text-indigo-600 hover:text-indigo-500 font-medium"
                    onClick={() => {
                      setSearchQuery("");
                      setSelectedCategory("all");
                    }}
                  >
                    Clear filters
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                {filteredTutorials.map(tutorial => (
                  <div key={tutorial.id} className="group bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow duration-300">
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={tutorial.thumbnail}
                        alt={tutorial.title}
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className="bg-indigo-600 rounded-full p-3">
                          <Play className="h-8 w-8 text-white" />
                        </div>
                      </div>
                      <div className="absolute top-2 right-2 bg-indigo-600 text-white text-xs px-2 py-1 rounded-full flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {tutorial.duration}
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="flex items-center mb-2">
                        <Tag className="h-4 w-4 text-indigo-500 mr-1" />
                        <span className="text-xs font-medium text-indigo-600">
                          {categories.find(c => c.id === tutorial.category)?.name}
                        </span>
                        <span className="mx-2 text-gray-300">•</span>
                        <span className="text-xs font-medium text-gray-500">
                          {tutorial.level}
                        </span>
                      </div>
                      <a href={tutorial.videoUrl}>
                        <h3 className="text-lg font-semibold text-gray-900 group-hover:text-indigo-600">
                          {tutorial.title}
                        </h3>
                      </a>
                      <p className="mt-2 text-sm text-gray-600 line-clamp-2">
                        {tutorial.description}
                      </p>
                      <div className="mt-4">
                        <a
                          href={tutorial.videoUrl}
                          className="inline-flex items-center text-indigo-600 hover:text-indigo-500 text-sm font-medium"
                        >
                          Watch tutorial
                          <ChevronRight className="ml-1 h-4 w-4" />
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Tutorial Series */}
          <div className="mt-24">
            <div className="text-center">
              <h2 className="text-2xl font-extrabold text-gray-900 sm:text-3xl">
                Tutorial Series
              </h2>
              <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
                Comprehensive multi-part guides for mastering ReviewPro
              </p>
            </div>
            
            <div className="mt-12 grid gap-8 lg:grid-cols-2">
              {/* Series 1 */}
              <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200">
                <div className="relative h-64">
                  <img
                    src="https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
                    alt="ReviewPro Masterclass Series"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black opacity-70"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-xl font-bold text-white">ReviewPro Masterclass Series</h3>
                    <p className="text-indigo-200">5 videos • 1 hour 15 minutes total</p>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-600 mb-6">
                    Complete guide to mastering ReviewPro from setup to advanced techniques. Perfect for new users who want to learn all aspects of the platform.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">1. Getting Started with ReviewPro</span>
                      <span className="text-xs text-gray-500">12:34</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">2. Creating Your First Review</span>
                      <span className="text-xs text-gray-500">15:47</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">3. Advanced Template Customization</span>
                      <span className="text-xs text-gray-500">18:23</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">4. SEO Optimization Techniques</span>
                      <span className="text-xs text-gray-500">14:56</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">5. Publishing and Distribution</span>
                      <span className="text-xs text-gray-500">13:12</span>
                    </div>
                  </div>
                  <div className="mt-6">
                    <a
                      href="#"
                      className="inline-flex items-center justify-center w-full px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 md:w-auto"
                    >
                      Start Series
                      <Play className="ml-2 h-4 w-4" />
                    </a>
                  </div>
                </div>
              </div>
              
              {/* Series 2 */}
              <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200">
                <div className="relative h-64">
                  <img
                    src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
                    alt="Advanced SEO for Product Reviews"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black opacity-70"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-xl font-bold text-white">Advanced SEO for Product Reviews</h3>
                    <p className="text-indigo-200">4 videos • 58 minutes total</p>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-600 mb-6">
                    Comprehensive guide to optimizing your product reviews for search engines. Learn advanced techniques to rank higher and drive more traffic.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">1. SEO Fundamentals for Reviews</span>
                      <span className="text-xs text-gray-500">14:22</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">2. Keyword Research and Implementation</span>
                      <span className="text-xs text-gray-500">16:35</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">3. Schema Markup for Rich Snippets</span>
                      <span className="text-xs text-gray-500">15:41</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">4. Advanced On-Page Optimization</span>
                      <span className="text-xs text-gray-500">11:28</span>
                    </div>
                  </div>
                  <div className="mt-6">
                    <a
                      href="#"
                      className="inline-flex items-center justify-center w-full px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 md:w-auto"
                    >
                      Start Series
                      <Play className="ml-2 h-4 w-4" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Request Tutorial Section */}
          <div className="mt-24 bg-indigo-700 rounded-lg py-12 px-6 sm:py-16 sm:px-12 text-center">
            <Video className="mx-auto h-12 w-12 text-white" />
            <h2 className="mt-4 text-3xl font-extrabold text-white tracking-tight">
              Can't find what you're looking for?
            </h2>
            <p className="mt-4 max-w-3xl mx-auto text-xl text-indigo-200">
              Request a tutorial on a specific topic and our team will create it for you.
            </p>
            <div className="mt-8">
              <a
                href="/support/contact"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-white hover:bg-indigo-50"
              >
                Request a Tutorial
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}