import React from 'react';
import { Helmet } from "react-helmet";
import Layout from "@/components/Layout";
import { Download, Calendar, ExternalLink } from "lucide-react";

export default function Press() {
  // Press releases
  const pressReleases = [
    {
      id: 1,
      title: "ReviewPro Raises $8.5 Million Series A to Revolutionize Product Review Creation",
      date: "June 15, 2023",
      excerpt: "Funding will accelerate AI capabilities and expand platform integrations with major content management systems.",
      link: "#"
    },
    {
      id: 2,
      title: "ReviewPro Achieves 250% Year-Over-Year Growth, Surpasses 50,000 Users",
      date: "March 3, 2023",
      excerpt: "Milestone underscores growing demand for AI-assisted content creation tools among affiliate marketers and e-commerce professionals.",
      link: "#"
    },
    {
      id: 3,
      title: "ReviewPro Launches Advanced SEO Toolkit for Product Review Optimization",
      date: "January 12, 2023",
      excerpt: "New features help content creators stay ahead of search engine algorithm changes specifically targeting product reviews.",
      link: "#"
    },
    {
      id: 4,
      title: "ReviewPro Partners with Leading E-commerce Platforms to Streamline Product Data Integration",
      date: "November 30, 2022",
      excerpt: "Strategic partnerships with Shopify, WooCommerce, and Amazon enable seamless product information synchronization for more accurate reviews.",
      link: "#"
    }
  ];

  // Media coverage
  const mediaCoverage = [
    {
      id: 1,
      publication: "TechCrunch",
      logo: "https://upload.wikimedia.org/wikipedia/commons/b/b9/TechCrunch_logo.png",
      title: "ReviewPro's AI-Powered Platform Is Changing How Affiliate Marketers Create Content",
      date: "May 18, 2023",
      link: "#"
    },
    {
      id: 2,
      publication: "Forbes",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Forbes_logo.svg/1200px-Forbes_logo.svg.png",
      title: "The Future Of Content Creation: How ReviewPro Is Empowering Affiliate Marketers",
      date: "April 7, 2023",
      link: "#"
    },
    {
      id: 3,
      publication: "Entrepreneur",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Entrepreneur-magazine-logo.svg/2560px-Entrepreneur-magazine-logo.svg.png",
      title: "This Startup Is Using AI To Transform Product Reviews And Boost Conversions",
      date: "February 22, 2023",
      link: "#"
    }
  ];

  // Company facts
  const companyFacts = [
    { label: "Founded", value: "2020" },
    { label: "Headquarters", value: "San Francisco, CA" },
    { label: "Employees", value: "75+" },
    { label: "Funding", value: "$12.5M" },
    { label: "Users", value: "50,000+" },
    { label: "Reviews Generated", value: "1.2M+" }
  ];

  // Company logos (for "as seen in" section)
  const featuredIn = [
    { name: "TechCrunch", logo: "https://upload.wikimedia.org/wikipedia/commons/b/b9/TechCrunch_logo.png" },
    { name: "Forbes", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Forbes_logo.svg/1200px-Forbes_logo.svg.png" },
    { name: "Entrepreneur", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Entrepreneur-magazine-logo.svg/2560px-Entrepreneur-magazine-logo.svg.png" },
    { name: "Business Insider", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Business_Insider_Logo_2013.svg/1200px-Business_Insider_Logo_2013.svg.png" },
    { name: "Marketing Land", logo: "https://marketingland.com/wp-content/ml-loads/2014/08/marketing-land-logo-square.png" }
  ];

  return (
    <Layout variant="landing">
      <Helmet>
        <title>Press & Media | ReviewPro</title>
        <meta name="description" content="ReviewPro press releases, media coverage, and company information for press and media inquiries." />
      </Helmet>
      
      <div className="bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl lg:text-5xl">Press & Media</h1>
            <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
              Latest news, press releases, and media resources from ReviewPro
            </p>
          </div>
          
          {/* Press Contact Section */}
          <div className="mt-16 bg-indigo-700 rounded-lg shadow-xl overflow-hidden">
            <div className="pt-10 pb-12 px-6 sm:pt-16 sm:px-16 lg:py-16 lg:pr-0 xl:py-20 xl:px-20">
              <div className="lg:self-center">
                <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
                  <span className="block">Press Contact</span>
                </h2>
                <p className="mt-4 text-lg leading-6 text-indigo-200">
                  For press inquiries, interview requests, or additional information, please contact:
                </p>
                <div className="mt-8">
                  <div className="text-white font-medium">Sarah Miller</div>
                  <div className="text-indigo-200">Director of Communications</div>
                  <a href="mailto:press@reviewpro.com" className="text-white underline">press@reviewpro.com</a>
                </div>
              </div>
            </div>
          </div>
          
          {/* Company Facts Section */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">Company Facts</h2>
            <div className="bg-white shadow-lg rounded-lg border border-gray-200 overflow-hidden">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 divide-x divide-y sm:divide-y-0 divide-gray-200">
                {companyFacts.map((fact, index) => (
                  <div key={index} className="p-6 text-center">
                    <p className="text-sm font-medium text-gray-500">{fact.label}</p>
                    <p className="mt-2 text-3xl font-extrabold text-indigo-600">{fact.value}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Press Releases Section */}
          <div className="mt-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">Press Releases</h2>
            <div className="space-y-6">
              {pressReleases.map((press) => (
                <div key={press.id} className="bg-white shadow-md rounded-lg overflow-hidden border border-gray-100">
                  <div className="p-6">
                    <div className="flex items-center text-sm text-gray-500 mb-3">
                      <Calendar className="h-4 w-4 mr-2" />
                      {press.date}
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">{press.title}</h3>
                    <p className="mt-3 text-gray-600">{press.excerpt}</p>
                    <div className="mt-4">
                      <a
                        href={press.link}
                        className="inline-flex items-center text-indigo-600 hover:text-indigo-500"
                      >
                        Read full release
                        <ExternalLink className="ml-1 h-4 w-4" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Media Coverage Section */}
          <div className="mt-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">Media Coverage</h2>
            <div className="grid gap-6 lg:grid-cols-3">
              {mediaCoverage.map((coverage) => (
                <div key={coverage.id} className="bg-white shadow-md rounded-lg overflow-hidden border border-gray-100 flex flex-col">
                  <div className="p-6 flex-grow">
                    <div className="h-8 mb-4">
                      <img
                        src={coverage.logo}
                        alt={coverage.publication}
                        className="h-full object-contain"
                      />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mt-2">{coverage.title}</h3>
                    <p className="mt-2 text-sm text-gray-500">{coverage.date}</p>
                  </div>
                  <div className="px-6 py-3 bg-gray-50 border-t border-gray-100">
                    <a
                      href={coverage.link}
                      className="text-sm inline-flex items-center text-indigo-600 hover:text-indigo-500"
                    >
                      Read article
                      <ExternalLink className="ml-1 h-4 w-4" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Featured In Section */}
          <div className="mt-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-12 text-center">As Seen In</h2>
            <div className="grid grid-cols-2 gap-8 md:grid-cols-3 lg:grid-cols-5">
              {featuredIn.map((company, index) => (
                <div key={index} className="col-span-1 flex justify-center">
                  <img
                    className="h-12 object-contain grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all duration-300"
                    src={company.logo}
                    alt={company.name}
                  />
                </div>
              ))}
            </div>
          </div>
          
          {/* Media Resources Section */}
          <div className="mt-20">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">Media Resources</h2>
            <div className="bg-gray-50 rounded-lg p-8 border border-gray-200">
              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Brand Assets</h3>
                  <p className="mt-2 text-gray-600">
                    Download our logo, product screenshots, founder headshots, and other brand assets for media use.
                  </p>
                  <a
                    href="#"
                    className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download Media Kit
                  </a>
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Company Boilerplate</h3>
                  <div className="mt-2 p-4 bg-white rounded border border-gray-200 text-sm text-gray-600">
                    <p>
                      ReviewPro is the leading AI-powered product review creation platform trusted by over 50,000 marketers and content creators worldwide. Founded in 2020, the company has raised $12.5M in funding to develop innovative tools that help affiliate marketers and e-commerce businesses create high-converting product reviews in a fraction of the time. ReviewPro's platform combines cutting-edge AI technology with proven marketing principles to generate content that ranks higher in search engines and drives more sales.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}