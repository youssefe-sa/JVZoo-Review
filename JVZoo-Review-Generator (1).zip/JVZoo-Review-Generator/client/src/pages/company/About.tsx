import React from 'react';
import { Helmet } from "react-helmet";
import Layout from "@/components/Layout";
import { CheckIcon } from "lucide-react";

export default function About() {
  return (
    <Layout variant="landing">
      <Helmet>
        <title>About Us | ReviewPro</title>
        <meta name="description" content="Learn about ReviewPro's mission to revolutionize product review content creation for marketers and affiliate professionals." />
      </Helmet>
      
      <div className="bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl lg:text-5xl">About ReviewPro</h1>
            <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
              Our mission is to revolutionize how product reviews are created, optimized, and published.
            </p>
          </div>
          
          {/* Company Story Section */}
          <div className="mt-16">
            <div className="relative">
              <div className="relative md:bg-white md:p-6">
                <div className="lg:grid lg:grid-cols-2 lg:gap-12">
                  <div className="prose prose-indigo prose-lg text-gray-500 lg:max-w-none">
                    <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">Our Story</h2>
                    <p>
                      ReviewPro was founded in 2020 by a team of seasoned marketers and software engineers who recognized a critical gap in the content creation ecosystem. After years of creating product reviews manually, our founders sought to develop a better way to produce high-quality, conversion-focused review content at scale.
                    </p>
                    <p>
                      What began as an internal tool quickly evolved into a comprehensive platform that combines cutting-edge AI technology with proven marketing principles to help affiliate marketers, e-commerce brands, and content creators develop reviews that not only rank well in search engines but also drive meaningful conversions.
                    </p>
                    <p>
                      Today, ReviewPro is trusted by thousands of marketers worldwide who rely on our platform to create compelling product review content that outperforms traditional approaches in both efficiency and effectiveness.
                    </p>
                  </div>
                  <div className="mt-10 lg:mt-0">
                    <div className="aspect-w-4 aspect-h-3 rounded-lg overflow-hidden">
                      <img
                        src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
                        alt="ReviewPro team collaboration"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <figcaption className="mt-3 flex text-sm text-gray-500">
                      <span className="ml-2">Our team collaborating on the ReviewPro platform</span>
                    </figcaption>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Mission and Values */}
          <div className="mt-24">
            <div className="lg:grid lg:grid-cols-3 lg:gap-8">
              <div>
                <h2 className="text-2xl font-extrabold text-gray-900">Our Mission</h2>
                <p className="mt-4 text-lg text-gray-500">
                  To empower content creators with AI-driven tools that transform the review creation process, making it possible to produce higher-converting, more engaging product reviews in a fraction of the time.
                </p>
              </div>
              <div className="mt-12 lg:mt-0">
                <h2 className="text-2xl font-extrabold text-gray-900">Our Vision</h2>
                <p className="mt-4 text-lg text-gray-500">
                  To become the global standard for product review content creation, helping one million marketers create reviews that engage readers and drive sales.
                </p>
              </div>
              <div className="mt-12 lg:mt-0">
                <h2 className="text-2xl font-extrabold text-gray-900">Our Values</h2>
                <ul className="mt-4 space-y-4">
                  <li className="flex">
                    <CheckIcon className="h-6 w-6 text-indigo-600 flex-shrink-0" />
                    <span className="ml-3 text-lg text-gray-500">Innovation</span>
                  </li>
                  <li className="flex">
                    <CheckIcon className="h-6 w-6 text-indigo-600 flex-shrink-0" />
                    <span className="ml-3 text-lg text-gray-500">Quality</span>
                  </li>
                  <li className="flex">
                    <CheckIcon className="h-6 w-6 text-indigo-600 flex-shrink-0" />
                    <span className="ml-3 text-lg text-gray-500">Transparency</span>
                  </li>
                  <li className="flex">
                    <CheckIcon className="h-6 w-6 text-indigo-600 flex-shrink-0" />
                    <span className="ml-3 text-lg text-gray-500">User-centricity</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          {/* Leadership Section */}
          <div className="mt-24">
            <div className="lg:text-center">
              <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">Our Leadership Team</h2>
              <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
                Meet the experienced professionals driving ReviewPro's mission forward.
              </p>
            </div>
            <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {/* Team member 1 */}
              <div className="pt-6">
                <div className="flow-root bg-gray-50 rounded-lg px-6 pb-8">
                  <div className="-mt-6">
                    <div>
                      <span className="inline-flex items-center justify-center p-3 bg-indigo-500 rounded-md shadow-lg">
                        <img
                          className="h-24 w-24 rounded-full object-cover"
                          src="https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80"
                          alt="CEO portrait"
                        />
                      </span>
                    </div>
                    <h3 className="mt-8 text-lg font-medium text-gray-900 tracking-tight">Michael Bennett</h3>
                    <p className="mt-1 text-md text-indigo-500">Co-Founder & CEO</p>
                    <p className="mt-5 text-base text-gray-500">
                      Former marketing executive with 15+ years of experience in digital content strategy and affiliate marketing.
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Team member 2 */}
              <div className="pt-6">
                <div className="flow-root bg-gray-50 rounded-lg px-6 pb-8">
                  <div className="-mt-6">
                    <div>
                      <span className="inline-flex items-center justify-center p-3 bg-indigo-500 rounded-md shadow-lg">
                        <img
                          className="h-24 w-24 rounded-full object-cover"
                          src="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=761&q=80"
                          alt="CTO portrait"
                        />
                      </span>
                    </div>
                    <h3 className="mt-8 text-lg font-medium text-gray-900 tracking-tight">Sarah Chen</h3>
                    <p className="mt-1 text-md text-indigo-500">Co-Founder & CTO</p>
                    <p className="mt-5 text-base text-gray-500">
                      AI researcher and software engineer with expertise in natural language processing and machine learning.
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Team member 3 */}
              <div className="pt-6">
                <div className="flow-root bg-gray-50 rounded-lg px-6 pb-8">
                  <div className="-mt-6">
                    <div>
                      <span className="inline-flex items-center justify-center p-3 bg-indigo-500 rounded-md shadow-lg">
                        <img
                          className="h-24 w-24 rounded-full object-cover"
                          src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80"
                          alt="COO portrait"
                        />
                      </span>
                    </div>
                    <h3 className="mt-8 text-lg font-medium text-gray-900 tracking-tight">David Rodriguez</h3>
                    <p className="mt-1 text-md text-indigo-500">Chief Operating Officer</p>
                    <p className="mt-5 text-base text-gray-500">
                      Operations expert with a background in scaling SaaS companies and optimizing business processes.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Testimonials */}
          <div className="mt-24">
            <div className="lg:text-center">
              <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">What Our Customers Say</h2>
              <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
                Hear from the marketers and content creators who rely on ReviewPro every day.
              </p>
            </div>
            <div className="mt-12 grid gap-8 lg:grid-cols-2">
              <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="p-8">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <img
                        className="h-12 w-12 rounded-full"
                        src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80"
                        alt="Customer testimonial"
                      />
                    </div>
                    <div className="ml-4">
                      <h4 className="text-lg font-bold text-gray-900">Emma Wilson</h4>
                      <p className="text-indigo-600">Affiliate Marketer</p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-gray-500 italic">
                      "ReviewPro has completely transformed my content strategy. I used to spend days creating product reviews, but now I can produce better content in just a few hours. My conversion rates have increased by 35% since I started using the platform."
                    </p>
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                <div className="p-8">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <img
                        className="h-12 w-12 rounded-full"
                        src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
                        alt="Customer testimonial"
                      />
                    </div>
                    <div className="ml-4">
                      <h4 className="text-lg font-bold text-gray-900">Thomas Green</h4>
                      <p className="text-indigo-600">E-commerce Director</p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-gray-500 italic">
                      "As an e-commerce brand, we need to create detailed reviews for hundreds of products. ReviewPro's AI-powered platform allows our team to scale content production while maintaining quality. It's been a game-changer for our business."
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* CTA Section */}
          <div className="mt-24 bg-indigo-50 rounded-lg py-12 px-6 sm:py-16 sm:px-12 lg:flex lg:items-center">
            <div className="lg:w-0 lg:flex-1">
              <h2 className="text-3xl font-extrabold tracking-tight text-gray-900">
                Ready to revolutionize your review content?
              </h2>
              <p className="mt-4 max-w-3xl text-lg text-gray-500">
                Join thousands of marketers who are creating better product reviews in less time with ReviewPro.
              </p>
            </div>
            <div className="mt-12 sm:w-full sm:max-w-md lg:mt-0 lg:ml-8 lg:flex-1">
              <div className="sm:flex">
                <a
                  href="/"
                  className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 md:py-4 md:text-lg md:px-10"
                >
                  Get Started
                </a>
                <a
                  href="/contact"
                  className="mt-3 w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 md:mt-0 md:ml-3 md:py-4 md:text-lg md:px-10"
                >
                  Contact Sales
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}