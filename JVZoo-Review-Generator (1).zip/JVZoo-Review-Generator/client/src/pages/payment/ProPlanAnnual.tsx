import React from 'react';
import Layout from '@/components/Layout';
import { PaymentForm } from '@/components/PaymentForm';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import { Link } from 'wouter';

export default function ProPlanAnnual() {
  // Calculate annual price (monthly price * 12 with 25% discount)
  const monthlyPrice = 49;
  const annualPrice = Math.round(monthlyPrice * 12 * 0.75).toString();
  
  // Plan details
  const planDetails = {
    name: 'Pro',
    price: annualPrice,
    billingCycle: 'yearly' as const,
    description: 'Advanced features for marketers and affiliate professionals',
    features: [
      '50 AI-generated reviews per month',
      'Advanced SEO optimization for better rankings',
      'All design themes included',
      'Premium review templates for varied products',
      'Priority email support with faster response times',
      'Advanced conversion features',
      'Full template library access',
      '14-day money-back guarantee',
      '25% discount with annual billing',
    ],
  };

  return (
    <Layout variant="landing">
      <div className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <Link href="/#pricing" className="inline-flex items-center text-indigo-600 hover:text-indigo-700">
              <ArrowLeftIcon className="h-4 w-4 mr-2" />
              Back to Pricing
            </Link>
            <h1 className="text-3xl font-bold mt-4 mb-2">Complete Your Pro Annual Plan Purchase</h1>
            <p className="text-gray-600">
              You're just a step away from unlocking advanced review creation capabilities with our Pro annual plan, with 25% savings.
            </p>
          </div>
          
          <PaymentForm plan={planDetails} />
        </div>
      </div>
    </Layout>
  );
}