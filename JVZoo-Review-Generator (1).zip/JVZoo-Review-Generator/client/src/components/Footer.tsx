import React from 'react';
import { Link, useLocation } from 'wouter';

export default function Footer() {
  const [location] = useLocation();
  const isAppRoute = location.startsWith('/app');

  // Simple footer for app routes
  if (isAppRoute) {
    return (
      <footer className="bg-gray-800">
        <div className="max-w-7xl mx-auto py-5 px-4 sm:px-6">
          <div className="flex justify-between items-center">
            <Link href="/" className="flex items-center hover:opacity-80 transition-opacity">
              <svg viewBox="0 0 32 32" className="h-7 w-7 text-indigo-400 mr-2" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M27 14.8889C27 20.7981 21.1797 25.6667 14 25.6667C6.82031 25.6667 1 20.7981 1 14.8889C1 8.97969 6.82031 4.11111 14 4.11111" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                <path d="M19.6667 5.44444L17 8.11111L19.6667 10.7778" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14 4.11111C21.1797 4.11111 27 8.97969 27 14.8889" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                <circle cx="23.5" cy="6.5" r="6.5" fill="currentColor" fillOpacity="0.3"/>
              </svg>
              <div className="flex items-center">
                <span className="font-bold text-xl text-white">ReviewPro</span>
                <span className="ml-1 text-xs px-1.5 py-0.5 bg-indigo-700 text-indigo-100 rounded font-medium">PRO</span>
              </div>
            </Link>
            <p className="text-sm text-gray-400">
              &copy; 2025 ReviewPro. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    );
  }

  // Full footer for non-app routes
  return (
    <footer className="bg-gray-800">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
          <div className="space-y-8 xl:col-span-1">
            <Link href="/" className="flex items-center hover:opacity-80 transition-opacity">
              <svg viewBox="0 0 32 32" className="h-8 w-8 text-indigo-400 mr-2" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M27 14.8889C27 20.7981 21.1797 25.6667 14 25.6667C6.82031 25.6667 1 20.7981 1 14.8889C1 8.97969 6.82031 4.11111 14 4.11111" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                <path d="M19.6667 5.44444L17 8.11111L19.6667 10.7778" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14 4.11111C21.1797 4.11111 27 8.97969 27 14.8889" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                <circle cx="23.5" cy="6.5" r="6.5" fill="currentColor" fillOpacity="0.3"/>
              </svg>
              <div className="flex items-center">
                <span className="font-bold text-2xl text-white">ReviewPro</span>
                <span className="ml-1 text-xs px-1.5 py-0.5 bg-indigo-700 text-indigo-100 rounded font-medium">PRO</span>
              </div>
            </Link>
            <p className="text-gray-300 text-base">
              The powerful platform for creating conversion-focused product reviews that rank higher and sell more effectively.
            </p>
          </div>
          <div className="mt-12 grid grid-cols-2 gap-8 xl:mt-0 xl:col-span-2">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Product</h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/#features" className="text-base text-gray-300 hover:text-white">Features</Link>
                  </li>
                  <li>
                    <Link href="/#pricing" className="text-base text-gray-300 hover:text-white">Pricing</Link>
                  </li>
                  <li>
                    <Link href="/product/roadmap" className="text-base text-gray-300 hover:text-white">Roadmap</Link>
                  </li>
                  <li>
                    <Link href="/product/api" className="text-base text-gray-300 hover:text-white">API</Link>
                  </li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Support</h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/support/help-center" className="text-base text-gray-300 hover:text-white">Help Center</Link>
                  </li>
                  <li>
                    <Link href="/support/documentation" className="text-base text-gray-300 hover:text-white">Documentation</Link>
                  </li>
                  <li>
                    <Link href="/support/tutorials" className="text-base text-gray-300 hover:text-white">Tutorials</Link>
                  </li>
                  <li>
                    <Link href="/support/contact" className="text-base text-gray-300 hover:text-white">Contact Us</Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Company</h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/company/about" className="text-base text-gray-300 hover:text-white">About</Link>
                  </li>
                  <li>
                    <Link href="/company/blog" className="text-base text-gray-300 hover:text-white">Blog</Link>
                  </li>
                  <li>
                    <Link href="/company/jobs" className="text-base text-gray-300 hover:text-white">Jobs</Link>
                  </li>
                  <li>
                    <Link href="/company/press" className="text-base text-gray-300 hover:text-white">Press</Link>
                  </li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">Legal</h3>
                <ul className="mt-4 space-y-4">
                  <li>
                    <Link href="/privacy" className="text-base text-gray-300 hover:text-white">Privacy</Link>
                  </li>
                  <li>
                    <Link href="/terms" className="text-base text-gray-300 hover:text-white">Terms</Link>
                  </li>
                  <li>
                    <Link href="/data-policy" className="text-base text-gray-300 hover:text-white">Data Policy</Link>
                  </li>
                  <li>
                    <Link href="/cookies" className="text-base text-gray-300 hover:text-white">Cookies</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-gray-700 pt-8">
          <p className="text-base text-gray-400 md:text-center">
            &copy; {new Date().getFullYear()} ReviewPro. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}