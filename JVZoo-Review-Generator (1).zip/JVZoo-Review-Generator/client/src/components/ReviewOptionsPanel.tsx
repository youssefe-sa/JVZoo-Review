import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import ProductImagesPanel from "./ProductImagesPanel";
import { Image } from "lucide-react";
import { ProductImage } from "@/lib/types";

interface ReviewOptionsPanelProps {
  reviewStyle: string;
  toneStyle: string;
  includePricingTable: boolean;
  includeProsConsSection: boolean;
  includeCtaBanner: boolean;
  includeProductImages: boolean;
  includeFaqSection: boolean;
  includeIntroduction?: boolean;
  includeCaseStudy?: boolean;
  includeConclusion?: boolean;
  usePhaseApproach: boolean;
  useMarketingCopywriting: boolean;
  extendedWordCount: boolean;
  includeSeoSchema: boolean;
  productImagesList?: ProductImage[];
  updateFormData: (data: Partial<{
    reviewStyle: string;
    toneStyle: string;
    includePricingTable: boolean;
    includeProsConsSection: boolean;
    includeCtaBanner: boolean;
    includeProductImages: boolean;
    includeFaqSection: boolean;
    includeIntroduction: boolean;
    includeCaseStudy: boolean;
    includeConclusion: boolean;
    usePhaseApproach: boolean;
    useMarketingCopywriting: boolean;
    extendedWordCount: boolean;
    includeSeoSchema: boolean;
    productImagesList?: ProductImage[];
  }>) => void;
  handleGenerateReview: () => void;
  isGenerating: boolean;
}

export default function ReviewOptionsPanel({
  reviewStyle,
  toneStyle,
  includePricingTable,
  includeProsConsSection,
  includeCtaBanner,
  includeProductImages,
  includeFaqSection,
  includeIntroduction = true,
  includeCaseStudy = false,
  includeConclusion = true,
  usePhaseApproach,
  useMarketingCopywriting,
  extendedWordCount,
  includeSeoSchema,
  productImagesList = [],
  updateFormData,
  handleGenerateReview,
  isGenerating
}: ReviewOptionsPanelProps) {
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="p-5 border-b border-gray-100">
        <div className="flex items-center">
          <i className="ri-tools-line text-lg text-indigo-600 mr-2"></i>
          <h2 className="text-lg font-semibold text-gray-800">Review Options</h2>
        </div>
      </div>
      
      <div className="p-5">
        <div className="mb-4">
          <label htmlFor="reviewStyle" className="block text-sm font-medium text-gray-700 mb-1">Review Style</label>
          <div className="relative">
            <select 
              id="reviewStyle"
              value={reviewStyle}
              onChange={(e) => updateFormData({ reviewStyle: e.target.value })}
              className="w-full appearance-none bg-white px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
            >
              <option value="ultra-comprehensive">Ultra Comprehensive (3500+ words)</option>
              <option value="comprehensive">Comprehensive (2000+ words)</option>
              <option value="balanced">Balanced (1200-1500 words)</option>
              <option value="concise">Concise (800-1000 words)</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-gray-500">
              <i className="ri-arrow-down-s-line"></i>
            </div>
          </div>
          {reviewStyle === 'ultra-comprehensive' && (
            <div className="mt-1 text-xs text-indigo-600 font-medium flex items-center">
              <i className="ri-star-fill mr-1"></i> Perfect for SEO optimization and Google ranking
            </div>
          )}
        </div>

        <div className="mb-4">
          <label htmlFor="toneStyle" className="block text-sm font-medium text-gray-700 mb-1">Tone Style</label>
          <div className="relative">
            <select 
              id="toneStyle"
              value={toneStyle}
              onChange={(e) => updateFormData({ toneStyle: e.target.value })}
              className="w-full appearance-none bg-white px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
            >
              <option value="professional">Professional</option>
              <option value="conversational">Conversational</option>
              <option value="enthusiastic">Enthusiastic</option>
              <option value="analytical">Analytical</option>
              <option value="persuasive">Persuasive (Sales-Focused)</option>
              <option value="balanced">Balanced Review</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-gray-500">
              <i className="ri-arrow-down-s-line"></i>
            </div>
          </div>
        </div>

        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">Basic Elements</label>
          
          <div className="space-y-3">
            {/* Toggle Option */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Pricing Table</span>
              <div className="relative inline-block w-10 mr-2 align-middle select-none">
                <input 
                  type="checkbox" 
                  name="includePricingTable" 
                  id="includePricingTable" 
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                  checked={includePricingTable}
                  onChange={(e) => updateFormData({ includePricingTable: e.target.checked })}
                  style={{ 
                    right: includePricingTable ? '0' : 'auto',
                    borderColor: includePricingTable ? '#4F46E5' : 'transparent'
                  }}
                />
                <label 
                  htmlFor="includePricingTable" 
                  className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                  style={{ backgroundColor: includePricingTable ? '#4F46E5' : '#D1D5DB' }}
                ></label>
              </div>
            </div>
            
            {/* Toggle Option */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Pros & Cons Section</span>
              <div className="relative inline-block w-10 mr-2 align-middle select-none">
                <input 
                  type="checkbox" 
                  name="includeProsConsSection" 
                  id="includeProsConsSection" 
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                  checked={includeProsConsSection}
                  onChange={(e) => updateFormData({ includeProsConsSection: e.target.checked })}
                  style={{ 
                    right: includeProsConsSection ? '0' : 'auto', 
                    borderColor: includeProsConsSection ? '#4F46E5' : 'transparent'
                  }}
                />
                <label 
                  htmlFor="includeProsConsSection" 
                  className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                  style={{ backgroundColor: includeProsConsSection ? '#4F46E5' : '#D1D5DB' }}
                ></label>
              </div>
            </div>
            
            {/* Toggle Option */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-700">CTA Banner</span>
              <div className="relative inline-block w-10 mr-2 align-middle select-none">
                <input 
                  type="checkbox" 
                  name="includeCtaBanner" 
                  id="includeCtaBanner" 
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                  checked={includeCtaBanner}
                  onChange={(e) => updateFormData({ includeCtaBanner: e.target.checked })}
                  style={{ 
                    right: includeCtaBanner ? '0' : 'auto', 
                    borderColor: includeCtaBanner ? '#4F46E5' : 'transparent'
                  }}
                />
                <label 
                  htmlFor="includeCtaBanner" 
                  className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                  style={{ backgroundColor: includeCtaBanner ? '#4F46E5' : '#D1D5DB' }}
                ></label>
              </div>
            </div>
            
            {/* Toggle Option */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Product Images</span>
              <div className="relative inline-block w-10 mr-2 align-middle select-none">
                <input 
                  type="checkbox" 
                  name="includeProductImages" 
                  id="includeProductImages" 
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                  checked={includeProductImages}
                  onChange={(e) => updateFormData({ includeProductImages: e.target.checked })}
                  style={{ 
                    right: includeProductImages ? '0' : 'auto', 
                    borderColor: includeProductImages ? '#4F46E5' : 'transparent'
                  }}
                />
                <label 
                  htmlFor="includeProductImages" 
                  className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                  style={{ backgroundColor: includeProductImages ? '#4F46E5' : '#D1D5DB' }}
                ></label>
              </div>
            </div>
            
            {/* Toggle Option */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-700">FAQ Section</span>
              <div className="relative inline-block w-10 mr-2 align-middle select-none">
                <input 
                  type="checkbox" 
                  name="includeFaqSection" 
                  id="includeFaqSection" 
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                  checked={includeFaqSection}
                  onChange={(e) => updateFormData({ includeFaqSection: e.target.checked })}
                  style={{ 
                    right: includeFaqSection ? '0' : 'auto', 
                    borderColor: includeFaqSection ? '#4F46E5' : 'transparent'
                  }}
                />
                <label 
                  htmlFor="includeFaqSection" 
                  className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                  style={{ backgroundColor: includeFaqSection ? '#4F46E5' : '#D1D5DB' }}
                ></label>
              </div>
            </div>
            
            {/* Toggle Option - Introduction */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Introduction</span>
              <div className="relative inline-block w-10 mr-2 align-middle select-none">
                <input 
                  type="checkbox" 
                  name="includeIntroduction" 
                  id="includeIntroduction" 
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                  checked={includeIntroduction}
                  onChange={(e) => updateFormData({ includeIntroduction: e.target.checked })}
                  style={{ 
                    right: includeIntroduction ? '0' : 'auto', 
                    borderColor: includeIntroduction ? '#4F46E5' : 'transparent'
                  }}
                />
                <label 
                  htmlFor="includeIntroduction" 
                  className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                  style={{ backgroundColor: includeIntroduction ? '#4F46E5' : '#D1D5DB' }}
                ></label>
              </div>
            </div>
            
            {/* Toggle Option - Case Study */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Case Study / Personal Experience</span>
              <div className="relative inline-block w-10 mr-2 align-middle select-none">
                <input 
                  type="checkbox" 
                  name="includeCaseStudy" 
                  id="includeCaseStudy" 
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                  checked={includeCaseStudy}
                  onChange={(e) => updateFormData({ includeCaseStudy: e.target.checked })}
                  style={{ 
                    right: includeCaseStudy ? '0' : 'auto', 
                    borderColor: includeCaseStudy ? '#4F46E5' : 'transparent'
                  }}
                />
                <label 
                  htmlFor="includeCaseStudy" 
                  className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                  style={{ backgroundColor: includeCaseStudy ? '#4F46E5' : '#D1D5DB' }}
                ></label>
              </div>
            </div>
            
            {/* Toggle Option - Conclusion */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-700">Conclusion</span>
              <div className="relative inline-block w-10 mr-2 align-middle select-none">
                <input 
                  type="checkbox" 
                  name="includeConclusion" 
                  id="includeConclusion" 
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                  checked={includeConclusion}
                  onChange={(e) => updateFormData({ includeConclusion: e.target.checked })}
                  style={{ 
                    right: includeConclusion ? '0' : 'auto', 
                    borderColor: includeConclusion ? '#4F46E5' : 'transparent'
                  }}
                />
                <label 
                  htmlFor="includeConclusion" 
                  className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                  style={{ backgroundColor: includeConclusion ? '#4F46E5' : '#D1D5DB' }}
                ></label>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 mb-4">
          <div className="flex items-center justify-start gap-4">
            <button 
              onClick={() => setShowAdvancedOptions(!showAdvancedOptions)}
              className="flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-800 transition-colors"
            >
              {showAdvancedOptions ? (
                <>
                  <i className="ri-arrow-up-s-line mr-1"></i>
                  Hide Advanced Options
                </>
              ) : (
                <>
                  <i className="ri-arrow-down-s-line mr-1"></i>
                  Show Advanced Options
                </>
              )}
            </button>
          </div>
          
          {showAdvancedOptions && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <h3 className="text-sm font-medium text-gray-700 mb-3 flex items-center">
                Professional Options
                <Badge className="ml-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white text-xs">PRO</Badge>
              </h3>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between p-2 rounded-lg bg-blue-50 border border-blue-100">
                  <div>
                    <span className="text-sm text-blue-800 font-medium flex items-center">
                      Advanced Multi-Phase Analysis
                      <span className="ml-2 px-2 py-0.5 text-[10px] font-semibold rounded-full bg-blue-100 text-blue-800">NEW</span>
                    </span>
                    <p className="text-xs text-blue-700">Displays detailed phase-by-phase analysis process with research, competitor analysis, and strategic content planning</p>
                  </div>
                  <div className="relative inline-block w-10 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      name="usePhaseApproach" 
                      id="usePhaseApproach" 
                      className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                      checked={usePhaseApproach}
                      onChange={(e) => updateFormData({ usePhaseApproach: e.target.checked })}
                      style={{ 
                        right: usePhaseApproach ? '0' : 'auto', 
                        borderColor: usePhaseApproach ? '#4F46E5' : 'transparent'
                      }}
                    />
                    <label 
                      htmlFor="usePhaseApproach" 
                      className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                      style={{ backgroundColor: usePhaseApproach ? '#4F46E5' : '#D1D5DB' }}
                    ></label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm text-gray-700 font-medium">Elite Copywriting Frameworks</span>
                    <p className="text-xs text-gray-500">Advanced AIDA, PAS, storytelling patterns, and emotional triggers</p>
                  </div>
                  <div className="relative inline-block w-10 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      name="useMarketingCopywriting" 
                      id="useMarketingCopywriting" 
                      className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                      checked={useMarketingCopywriting}
                      onChange={(e) => updateFormData({ useMarketingCopywriting: e.target.checked })}
                      style={{ 
                        right: useMarketingCopywriting ? '0' : 'auto', 
                        borderColor: useMarketingCopywriting ? '#4F46E5' : 'transparent'
                      }}
                    />
                    <label 
                      htmlFor="useMarketingCopywriting" 
                      className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                      style={{ backgroundColor: useMarketingCopywriting ? '#4F46E5' : '#D1D5DB' }}
                    ></label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm text-gray-700 font-medium">Premium Long-Form Content</span>
                    <p className="text-xs text-gray-500">4,000+ words with expert sections to outrank competitors in Google</p>
                  </div>
                  <div className="relative inline-block w-10 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      name="extendedWordCount" 
                      id="extendedWordCount" 
                      className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                      checked={extendedWordCount}
                      onChange={(e) => updateFormData({ extendedWordCount: e.target.checked })}
                      style={{ 
                        right: extendedWordCount ? '0' : 'auto', 
                        borderColor: extendedWordCount ? '#4F46E5' : 'transparent'
                      }}
                    />
                    <label 
                      htmlFor="extendedWordCount" 
                      className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                      style={{ backgroundColor: extendedWordCount ? '#4F46E5' : '#D1D5DB' }}
                    ></label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm text-gray-700 font-medium">Enhanced Schema Markup for SEO</span>
                    <p className="text-xs text-gray-500">Complete JSON-LD markup with star ratings for better Google visibility</p>
                  </div>
                  <div className="relative inline-block w-10 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      name="includeSeoSchema" 
                      id="includeSeoSchema" 
                      className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                      checked={includeSeoSchema}
                      onChange={(e) => updateFormData({ includeSeoSchema: e.target.checked })}
                      style={{ 
                        right: includeSeoSchema ? '0' : 'auto', 
                        borderColor: includeSeoSchema ? '#4F46E5' : 'transparent'
                      }}
                    />
                    <label 
                      htmlFor="includeSeoSchema" 
                      className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                      style={{ backgroundColor: includeSeoSchema ? '#4F46E5' : '#D1D5DB' }}
                    ></label>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {includeProductImages && (
          <div className="mt-6 mb-6">
            <h3 className="text-sm font-medium text-gray-700 mb-3 flex items-center">
              <Image className="h-4 w-4 text-indigo-600 mr-2" />
              Product Images
            </h3>
            <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
              <ProductImagesPanel
                productImages={productImagesList || []}
                updateProductImages={(images) => updateFormData({ productImagesList: images })}
              />
            </div>
          </div>
        )}


      </div>
    </div>
  );
}
