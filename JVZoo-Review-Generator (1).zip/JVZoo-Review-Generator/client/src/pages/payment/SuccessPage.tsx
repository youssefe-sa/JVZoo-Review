import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';

export default function SuccessPage() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  
  // Clear any payment related data from session storage
  useEffect(() => {
    sessionStorage.removeItem('selectedPlan');
  }, []);
  
  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation('/payment/plans');
    }
  }, [isAuthenticated, setLocation]);

  return (
    <div className="container mx-auto py-12 px-4 max-w-3xl">
      <Card className="border-green-100">
        <CardContent className="pt-6 flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
            <CheckCircle2 className="w-10 h-10 text-green-600" />
          </div>
          
          <h1 className="text-3xl font-bold mb-2">Payment Successful!</h1>
          <p className="text-xl text-gray-600 mb-6">
            {user ? `Thank you for your purchase, ${user.email}. ` : 'Thank you for your purchase. '}
            Your subscription is now active.
          </p>
          
          <div className="bg-gray-50 p-6 rounded-lg w-full mb-8">
            <h2 className="text-lg font-medium mb-4">What's Next?</h2>
            <ul className="space-y-4 text-left">
              <li className="flex items-start">
                <span className="mr-2 text-green-600">✓</span>
                <span>Explore our template library to find the perfect review templates</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-green-600">✓</span>
                <span>Create your first AI-powered product review</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-green-600">✓</span>
                <span>Set up your profile to optimize your workflow</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2 text-green-600">✓</span>
                <span>Explore advanced features like SEO optimization and multi-platform publishing</span>
              </li>
            </ul>
          </div>
          
          <div className="flex gap-4 flex-wrap justify-center">
            <Button size="lg" onClick={() => setLocation('/dashboard')}>
              Go to Dashboard
            </Button>
            <Button size="lg" variant="outline" onClick={() => setLocation('/templates')}>
              Browse Templates
            </Button>
          </div>
          
          <p className="mt-8 text-sm text-gray-500">
            A receipt has been sent to your email address. If you have any questions,
            please contact our support team.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}