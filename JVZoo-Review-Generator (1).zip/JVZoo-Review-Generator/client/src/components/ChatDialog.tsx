import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";

// Define the message type
type ChatMessage = {
  id: string;
  isUser: boolean;
  text: string;
  timestamp: Date;
};

// Automated responses based on keywords
const AUTO_RESPONSES: Record<string, string[]> = {
  // Greetings
  "hello": [
    "Hello! How can I help you with your product review today?",
    "Hi there! What kind of product are you reviewing?",
    "Welcome to our chat support! How can I assist you with your review generation today?"
  ],
  "hi": [
    "Hi! How can I help you today?",
    "Hello there! What can I assist you with?",
    "Hi! I'm your Review Assistant. What questions do you have about our platform?"
  ],
  "hey": [
    "Hey there! How can I assist you today?",
    "Hello! I'm here to help with your review generation needs.",
    "Hey! What can I help you with on the Review Generator today?"
  ],
  
  // General Help
  "help": [
    "I'd be happy to help! Here are some things I can assist with:\n- Using the review generator\n- SEO optimization tips\n- Template management\n- Technical issues",
    "What do you need help with? I can assist with review generation, SEO optimization, or using templates.",
    "I'm here to help! Some popular topics include: generating your first review, optimizing for SEO, using templates, and troubleshooting issues. What would you like to know more about?"
  ],
  "support": [
    "Our support team is here to help! What issue are you experiencing?",
    "I can help resolve most issues right here in chat. What's going on?",
    "I'd be happy to assist you. Could you tell me more about what you need help with?"
  ],
  
  // Review Generation
  "review": [
    "Our review generator creates comprehensive product reviews with just a few inputs. Would you like me to explain how to use it?",
    "For the best review results, make sure to fill out the product information completely. Do you need help with any specific section?",
    "The review generator uses AI to create detailed, persuasive product reviews. You can customize the style, tone, sections included, and SEO settings. What part are you interested in learning more about?"
  ],
  "generate": [
    "To generate a review, fill out the product details, select your review style and options, then click the Generate button. Would you like more specific guidance?",
    "Review generation takes about 30-60 seconds after you click the Generate button. Make sure all required fields are completed beforehand. Need help with any particular settings?",
    "Our AI generates reviews in a 5-phase approach for maximum quality. You'll need to provide basic product information and choose your preferred style. What step are you on?"
  ],
  "ai": [
    "We use Google's Gemini 2.5 Pro and Gemini 1.5 Pro models for superior content generation. Would you like to know more about how our AI works?",
    "Our AI models understand product features, benefits, and market positioning to create compelling reviews. The 5-phase approach ensures comprehensive analysis.",
    "The AI system analyzes your product from multiple perspectives to create balanced, thorough reviews that maintain objectivity while highlighting benefits."
  ],
  
  // SEO Features
  "seo": [
    "Our SEO features include structured data, keyword optimization, and content structure analysis. Would you like specific tips for your review?",
    "For better SEO performance, try using the target keyword in your title, introduction, and a few headings. Can I help you set up your keywords?",
    "The Pro Edition includes comprehensive SEO tools such as schema markup, keyword density analysis, and featured snippet optimization. What specific SEO aspect are you interested in?"
  ],
  "keyword": [
    "For optimal keyword usage, place your main keyword in the title, first paragraph, and a few headings. Secondary keywords can be spread throughout the content. Need help choosing keywords?",
    "Keyword research is crucial for review visibility. Use your main product name plus 'review' as your primary keyword, and include related terms as secondary keywords.",
    "We recommend a keyword density of 1.5-2.5% for your main keyword. Our system will help optimize placement for maximum SEO benefit."
  ],
  "schema": [
    "Schema markup (structured data) helps search engines understand your content and can lead to rich snippets in search results. Our system automatically generates appropriate schema.",
    "We support Product, Review, and FAQ schema types that can significantly increase your visibility in search results. These are automatically added when you enable structured data.",
    "Schema markup is added in JSON-LD format which is Google's preferred method. This doesn't affect how your review looks but improves how search engines interpret it."
  ],
  
  // Templates
  "template": [
    "Templates can save you time by reusing your favorite settings. Would you like to know how to create or load a template?",
    "You can save any review configuration as a template for future use. Would you like me to walk you through creating one?",
    "Templates store all your settings including review style, SEO options, and section preferences. You can access them from the Template Manager panel."
  ],
  "save": [
    "To save your current configuration as a template, click the 'Save as Template' button in the Template Manager panel and give it a descriptive name.",
    "Saved templates include all your settings and can be loaded with a single click. This is great for creating consistent reviews across multiple products.",
    "Pro users can export templates as JSON files to share with team members or use across different accounts."
  ],
  "load": [
    "To load a saved template, open the Template Manager dropdown, select your template, and click 'Load Template'. All settings will be automatically applied.",
    "Loading a template will replace your current settings. Make sure to save any important configurations first before loading a new template.",
    "You can search for templates by name, date, or category in the Template Manager if you have many saved configurations."
  ],
  
  // Technical Issues
  "error": [
    "I'm sorry you're experiencing an issue. Could you describe what's happening in more detail, and I'll try to help?",
    "Let's troubleshoot that problem. Can you tell me what you were doing when the error occurred?",
    "Technical issues can usually be resolved quickly. Please describe the exact error message or behavior you're seeing."
  ],
  "bug": [
    "Thanks for reporting a bug. Could you tell me what happened and what you expected to happen instead?",
    "Bug reports help us improve. Please describe the steps that led to the issue so we can reproduce and fix it.",
    "I'll help document this bug for our development team. Can you provide details about when it occurred and what you were doing?"
  ],
  "not working": [
    "I'm sorry to hear something isn't working. Let's figure out the issue - could you tell me exactly what feature you're trying to use?",
    "Technical issues can usually be resolved quickly. What specifically isn't working as expected?",
    "Let's troubleshoot this together. Please describe what you're trying to do and what happens instead of the expected behavior."
  ],
  
  // Account and Pricing
  "account": [
    "You can manage your account settings through the Settings dropdown in the top menu. What specifically would you like to change?",
    "Account preferences include display settings, interface options, and notification preferences. Need help with something specific?",
    "Your account details can be updated in the Account Preferences section. What would you like to modify?"
  ],
  "pricing": [
    "The Professional Edition includes all premium features for $29/month. Would you like information about what's included?",
    "Our pricing starts at $29/month for the Professional Edition with all features. We also offer a 7-day free trial. Would you like more details?",
    "The Pro plan includes unlimited reviews, all advanced features including SEO tools, and priority support. Would you like to know about specific features?"
  ],
  "subscription": [
    "You can manage your subscription in the Account section. Would you like to know about upgrading, downgrading, or cancellation?",
    "Subscription management is available in your account dashboard. What changes are you considering?",
    "All subscriptions include a 7-day money-back guarantee. What questions do you have about your current plan?"
  ],
  
  // Output and Export
  "export": [
    "You can export your review in HTML format by clicking the 'Copy HTML' button in the Output panel. This gives you code ready to paste into your website or CMS.",
    "The exported HTML includes all formatting, SEO elements, and structured data. You can paste it directly into most website editors.",
    "For exporting, you can choose between copying the full HTML or just the formatted text. What format works best for your needs?"
  ],
  "html": [
    "Our HTML output is optimized for web performance with clean code and efficient structure. It's ready to use on any website or blog.",
    "The HTML version includes proper semantic elements, structured data, and optimized markup. You can view it in the HTML tab of the Output panel.",
    "HTML output is designed to be compatible with all major CMS platforms including WordPress, Shopify, and custom websites."
  ],
  "copy": [
    "To copy your review, use the 'Copy HTML' or 'Copy Text' buttons in the Output panel depending on your needs.",
    "Copying the HTML gives you the complete formatted review with all styling and structured data included.",
    "After copying, you can paste the review directly into your website editor or CMS without any additional formatting needed."
  ],
  
  // Product Images
  "image": [
    "You can add product images in the Product Images panel. Each image can have a caption, alt text, and position setting.",
    "For best results, use high-quality product images that showcase the key features. We recommend at least one header image and 2-3 feature images.",
    "Product images are important for engagement and SEO. Make sure to add descriptive alt text and captions for each image you include."
  ],
  "picture": [
    "Product pictures can be added in the Product Images panel. You can specify where each image should appear in the review.",
    "Images can be positioned in specific sections like the introduction, features, or conclusion. What section would you like to enhance with images?",
    "Good product pictures improve your review's engagement. We support various image sizes and alignments to fit your design needs."
  ],
  
  // Additional Features
  "feature": [
    "Our key features include AI-powered content generation, SEO optimization tools, customizable templates, and responsive design elements.",
    "The Professional Edition includes additional features like advanced SEO tools, comparison tables, and shareable templates. What specific feature are you interested in?",
    "Features are organized by category in the interface. Would you like to know more about review options, SEO tools, or template management?"
  ],
  "compare": [
    "Comparison tables can be enabled in the Advanced Features panel. They allow you to contrast your product with competitors.",
    "To create a comparison table, enable the option and provide the names of competing products. The AI will generate relevant comparison points.",
    "Comparison tables are highly effective for conversion as they clearly show your product's advantages. Would you like help setting one up?"
  ],
  "testimonial": [
    "You can enable testimonial sections in the Advanced Features panel. These add social proof to your reviews.",
    "Testimonials are generated based on your product description and typical user experiences. You can also provide custom testimonials if you prefer.",
    "Adding testimonials can increase conversion rates by up to 34% according to our research. Would you like to include them in your review?"
  ],
  
  // Gratitude
  "thanks": [
    "You're welcome! Is there anything else I can help you with today?",
    "Happy to help! Let me know if you need assistance with anything else.",
    "It's my pleasure! Don't hesitate to reach out if you have more questions."
  ],
  "thank you": [
    "You're very welcome! Is there anything else you'd like to know about the Review Generator?",
    "I'm glad I could help! Feel free to ask if you have any other questions.",
    "Happy to be of assistance! Don't hesitate to chat again if you need more help."
  ],
  "great": [
    "Glad to hear that! Is there anything else you'd like to know about?",
    "Wonderful! Let me know if you need help with anything else.",
    "Excellent! I'm here if you have any other questions about the Review Generator."
  ],
  
  // Specific Products
  "jvzoo": [
    "Our system is optimized for JVZoo products with special templates and features designed for affiliate marketers.",
    "For JVZoo products, we recommend enabling the bonus section and CTA banners to maximize conversion rates.",
    "When reviewing JVZoo products, make sure to include your affiliate link in the Product Information panel for automatic insertion throughout the review."
  ],
  "affiliate": [
    "Affiliate links are automatically inserted at strategic points in your review when you provide them in the Product Information panel.",
    "For affiliate marketing, we recommend enabling CTA banners and using the promotional review style for better conversion rates.",
    "Our system automatically adds appropriate disclosure statements with affiliate links to maintain compliance with advertising regulations."
  ],
  "wordpress": [
    "Our HTML output is fully compatible with WordPress. Simply copy the HTML and paste it into the text/HTML editor in WordPress.",
    "For WordPress users, we recommend enabling the structured data option for better SEO integration with your site.",
    "The generated HTML works perfectly with WordPress. If you're using Gutenberg, paste it in the HTML block for best results."
  ],
  
  // Advanced FAQ Content
  "api key": [
    "You'll need a Google AI Studio API key to use our generator. You can get one by signing up at makersuite.google.com and creating a new API key.",
    "Your API key should be entered in the Configuration panel. We securely store it in your browser for convenience, but it's never shared with our servers.",
    "If you're having issues with your API key, make sure it has access to the Gemini models and that you haven't exceeded your quota limits."
  ],
  "quota": [
    "Google AI Studio provides a monthly quota for API usage. If you're seeing quota errors, you may need to wait until it refreshes or upgrade your Google AI account.",
    "The Professional edition is optimized to use tokens efficiently, so you can generate more reviews within your quota limits.",
    "You can check your current API quota usage in your Google AI Studio dashboard under the 'Usage' section."
  ],
  "model": [
    "We support Gemini 2.5 Pro and Gemini 1.5 Pro models for the best quality review generation. Gemini 2.5 Pro offers the most advanced capabilities.",
    "The model selection can be changed in the Configuration panel. Gemini 2.5 Pro is recommended for most reviews due to its enhanced reasoning abilities.",
    "Different models have different strengths - Gemini 2.5 Pro excels at creative content while Gemini 1.5 Pro may be more efficient for technical products."
  ],
  "style": [
    "We offer various review styles including balanced, promotional, analytical, and conversational. Each adapts the tone and structure of your review.",
    "The balanced style provides equal coverage of pros and cons, while promotional style emphasizes benefits. Analytical style focuses on detailed evaluation.",
    "You can select your preferred review style in the basic settings tab. This affects how the AI approaches your product evaluation."
  ],
  "tone": [
    "Review tone options include professional, casual, enthusiastic, and technical. This setting fine-tunes the writing voice used throughout your review.",
    "Professional tone is formal and authoritative, while casual is more conversational. Enthusiastic tone conveys excitement, and technical focuses on specifications.",
    "You can combine different styles and tones - for example, a balanced style with an enthusiastic tone creates an objective but engaging review."
  ],
  "wordcount": [
    "Standard reviews are approximately 1,500-2,000 words. Enabling the extended wordcount option increases this to 2,500-3,000 words with more detailed sections.",
    "Longer reviews provide more opportunity for keyword placement and in-depth analysis, which can benefit SEO performance.",
    "Extended wordcount reviews include more comprehensive comparisons, use cases, and technical details about the product."
  ],
  "phase": [
    "The 5-phase approach systematically analyzes your product through multiple perspectives for more comprehensive reviews.",
    "The phases include: 1) Initial product research, 2) Feature analysis, 3) Benefit mapping, 4) Competitive positioning, and 5) Final review construction.",
    "Enabling the phase approach produces more thorough reviews but may take slightly longer to generate. The result includes detailed analysis from each phase."
  ],
  "welcome tour": [
    "The welcome tour provides a comprehensive introduction to our platform with 10 guided steps covering all essential features. You'll learn about API setup, product details, review settings, SEO options, and more!",
    "Our interactive welcome tour guides you through the entire review creation process step-by-step. It points out each important panel and explains how to use it effectively.",
    "The welcome tour appears automatically for new users and can be accessed again anytime. It's the perfect way to get familiar with all the platform's capabilities."
  ],
  "tour": [
    "The welcome tour provides a guided introduction to the platform's key features. You can restart it anytime from the help menu.",
    "Each tour step highlights important functionality and provides context about how to use that feature effectively.",
    "The tour is automatically shown to new users but can be disabled in your preferences if you prefer."
  ],
  "faq": [
    "FAQ sections in reviews help address common questions potential buyers have. This improves user experience and can help with featured snippet SEO.",
    "Enable the FAQ section in the Review Options panel. The AI will generate relevant questions and answers based on your product information.",
    "FAQs also generate schema markup for search engines, increasing the chance of your content appearing in Google's rich results."
  ],
  "bonus": [
    "The bonus section allows you to offer special incentives to readers who purchase through your affiliate link.",
    "To add a bonus section, enable it in the Advanced Features panel and describe the bonuses you're offering. The AI will format them attractively.",
    "Effective bonuses typically offer complementary value to the main product and have a clear, tangible benefit to the customer."
  ],
  "cta": [
    "Call-to-action (CTA) banners are strategically placed buttons and messages that encourage readers to take action.",
    "Enable CTA banners in the Review Options panel. They'll be automatically inserted at optimal points in your review with your affiliate link.",
    "Effective CTAs create urgency and clearly communicate the value proposition of taking action now rather than later."
  ],
  "comparison": [
    "Comparison tables visually contrast your reviewed product with competitors across key features and benefits.",
    "To create one, enable comparison tables in Advanced Features and list competing product names. The AI will identify relevant comparison points.",
    "Comparison tables are powerful persuasion tools that help readers make informed decisions while highlighting your product's strengths."
  ],
  "rating": [
    "Product ratings provide a quick visual indicator of your overall assessment. They appear prominently at the top of the review.",
    "You can specify your product rating score in the Advanced Features panel. We recommend being honest yet strategic with ratings.",
    "Reviews with 4-4.7 star ratings often convert better than perfect 5-star ratings as they appear more credible to readers."
  ],
  "theme": [
    "Review themes affect the visual styling and layout of your generated review HTML.",
    "Options include Classic, Modern, Minimal, and Professional themes. Each has different heading styles, spacing, and visual elements.",
    "You can preview different themes in the Theme Selection panel to find the best match for your website's design."
  ],
  "features tour": [
    "The welcome tour provides a guided introduction to all key features of the platform. It's designed to help new users get started quickly.",
    "The tour highlights important panels and explains their purpose, helping you understand the workflow for creating effective reviews.",
    "You can access the welcome tour anytime from the help menu if you want to refresh your understanding of any feature."
  ],
  "how to start": [
    "To get started, first enter your API key in the Configuration panel, then fill out the Product Details with your product information.",
    "Next, configure your review settings in the Review Settings panel, choosing style, tone, and which sections to include.",
    "Finally, click the Generate Professional Review button to create your review. The whole process takes just a few minutes!"
  ],
  "best practices": [
    "For the best results, provide detailed product descriptions that highlight unique features and benefits.",
    "Enable SEO options and enter relevant keywords to make your review more discoverable in search engines.",
    "Use a balanced approach that honestly discusses both pros and cons to build reader trust."
  ],
  "google": [
    "Our system uses Google's Gemini AI models for review generation. These are some of the most advanced language models available.",
    "Google's models are particularly good at understanding product contexts and creating factually grounded content.",
    "The Google AI Studio API integration provides reliable, high-quality outputs with excellent performance."
  ],
  "format": [
    "Your review will be formatted with proper HTML structure, headings, paragraphs, and other elements for optimal readability.",
    "The formatting includes semantic HTML5 elements that improve both user experience and search engine optimization.",
    "You can customize aspects of the formatting by selecting different themes in the Theme Selection panel."
  ],
  "table of contents": [
    "A table of contents makes longer reviews more navigable and improves user experience.",
    "Enable the table of contents option in the SEO panel to automatically generate a clickable navigation menu at the top of your review.",
    "This feature also creates jump links that allow readers to quickly navigate to sections they're most interested in."
  ],
  "meta description": [
    "The meta description is a short summary that appears in search results below your title. It should entice clicks while including your target keyword.",
    "You can specify a custom meta description in the SEO Options panel, or let the system generate an optimized one for you.",
    "Effective meta descriptions are 150-160 characters long and include a call to action that encourages users to click."
  ],
  "open graph": [
    "Open Graph tags control how your review appears when shared on social media platforms like Facebook, Twitter, and LinkedIn.",
    "Enable Open Graph tags in the SEO Options panel to optimize social sharing with custom titles, descriptions, and images.",
    "These tags can significantly improve click-through rates when your review is shared on social networks."
  ],
  "canonical url": [
    "Canonical URLs tell search engines which version of a page is the master copy to prevent duplicate content issues.",
    "Enable this option in SEO settings if you plan to publish your review in multiple locations to ensure proper SEO attribution.",
    "The canonical tag will be included in your HTML output and should be updated to your primary URL when publishing."
  ],
  "snippet": [
    "Featured snippets are highlighted search results that appear at the top of Google searches. Our system optimizes for snippet selection.",
    "Enable the 'Target Featured Snippet' option in SEO settings to structure your content in ways that Google prefers for snippets.",
    "Featured snippets can dramatically increase visibility and traffic, particularly for how-to and definition-based queries."
  ]
};

// Default fallback responses when no keyword matches
const FALLBACK_RESPONSES = [
  "I'm here to help with your review generation. Could you tell me more about what you need? Some popular topics include generating reviews, SEO optimization, templates, or product settings.",
  "I'm not sure I understand. Could you rephrase your question? I can help with review generation, SEO settings, templates, account management, and technical support.",
  "Would you like help with creating a review, managing templates, optimizing SEO, or using any specific feature? I'm here to assist with any aspect of the Review Generator.",
  "I'm your review assistant. How can I help you with your product review today? You can ask about features, settings, SEO, or troubleshooting.",
  "I'd be happy to help! Some common topics users ask about include: how to generate reviews, setting up SEO, working with templates, or troubleshooting issues. What would you like to know?",
  "Let me know what you're looking to accomplish with the Review Generator, and I can guide you through the process. Would you like help with creating a review, templates, or SEO?",
  "I'm here to assist with any questions about our JVZoo Review Generator. What specific area do you need help with today?",
  "Feel free to ask about any feature or setting in the Review Generator. I can help with technical issues, content generation, or optimization questions.",
  "I'm not sure what you're asking, but I'm happy to help with review generation, SEO setup, template management, account settings, or technical support. Could you clarify your question?",
  "If you're not sure where to start, I recommend beginning with the basic review setup. Would you like me to guide you through creating your first review?",
  "Our welcome tour provides an excellent introduction to all key features. If you'd like to revisit any part of it, I can help explain specific features in more detail.",
  "As your AI assistant, I can help with any aspect of the review generation process. You might want to know about API setup, product details, review settings, or advanced features.",
  "I can provide detailed guidance on the 5-phase review approach, SEO optimization, template management, or any other feature you're interested in learning more about.",
  "If you're new to the platform, I recommend exploring our welcome tour which highlights all the key features. Can I help you understand any particular aspect in more detail?",
  "The welcome tour covers all the essential features, but I can provide more in-depth explanations of any aspect you'd like to understand better."
];

interface ChatDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ChatDialog({ isOpen, onClose }: ChatDialogProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      isUser: false,
      text: "👋 Hi there! I'm your Review Assistant. I can help with:\n• Creating product reviews\n• SEO optimization\n• Using templates\n• Troubleshooting issues\n\nWhat would you like help with today?",
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Focus input when dialog opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  // Function to generate automated response based on user input
  const generateResponse = (userMessage: string): string => {
    const lowercaseMessage = userMessage.toLowerCase();
    
    // Store matching keywords and their priority scores
    const matches: { keyword: string; priority: number }[] = [];
    
    // Check for keyword matches
    for (const [keyword, responses] of Object.entries(AUTO_RESPONSES)) {
      // Exact word match has highest priority (for words like "hi", "hey", etc.)
      const wordRegex = new RegExp(`\\b${keyword}\\b`, 'i');
      if (wordRegex.test(lowercaseMessage)) {
        matches.push({ keyword, priority: 3 });
        continue;
      }
      
      // Phrase match has medium priority
      if (lowercaseMessage.includes(keyword)) {
        // Longer keywords get higher priority (more specific)
        const priorityBoost = Math.min(keyword.length / 2, 1); // Max 1 point boost for length
        matches.push({ keyword, priority: 2 + priorityBoost });
        continue;
      }
      
      // Check for partial matches (for longer keywords)
      if (keyword.length > 4 && lowercaseMessage.includes(keyword.substring(0, 4))) {
        matches.push({ keyword, priority: 1 });
      }
    }
    
    // If we have matches, sort by priority and use the highest
    if (matches.length > 0) {
      matches.sort((a, b) => b.priority - a.priority);
      const bestMatch = matches[0].keyword;
      return AUTO_RESPONSES[bestMatch][Math.floor(Math.random() * AUTO_RESPONSES[bestMatch].length)];
    }
    
    // No match, use fallback
    return FALLBACK_RESPONSES[Math.floor(Math.random() * FALLBACK_RESPONSES.length)];
  };

  // Handle send message
  const handleSendMessage = () => {
    if (!inputValue.trim()) return;
    
    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      isUser: true,
      text: inputValue,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    
    // Simulate typing
    setIsTyping(true);
    
    // Add bot response after a delay
    setTimeout(() => {
      const botResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        isUser: false,
        text: generateResponse(userMessage.text),
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000); // Random delay between 1-2 seconds
  };

  // Handle key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Format timestamp
  const formatTime = (date: Date): string => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <i className="ri-customer-service-2-line text-green-600 mr-2"></i>
            Live Chat Support
          </DialogTitle>
          <DialogDescription>
            Our support assistant is here to help with your questions
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex flex-col h-80">
          <div className="flex-1 overflow-y-auto p-3 space-y-4 bg-gray-50 rounded-md">
            {messages.map((message) => (
              <div 
                key={message.id} 
                className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-[80%] rounded-lg p-3 ${
                    message.isUser 
                      ? 'bg-indigo-600 text-white rounded-tr-none' 
                      : 'bg-white border border-gray-200 rounded-tl-none'
                  }`}
                >
                  <p className="text-sm whitespace-pre-line">{message.text}</p>
                  <p 
                    className={`text-xs mt-1 text-right ${
                      message.isUser ? 'text-indigo-100' : 'text-gray-400'
                    }`}
                  >
                    {formatTime(message.timestamp)}
                  </p>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white border border-gray-200 rounded-lg rounded-tl-none p-3">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
          
          {/* Quick response buttons */}
          <div className="mt-1 mb-2">
            <div className="flex flex-wrap gap-2 justify-center">
              <button 
                onClick={() => {
                  setInputValue("Tell me about the welcome tour");
                  setTimeout(() => handleSendMessage(), 100);
                }}
                className="text-xs py-1 px-2 bg-indigo-100 hover:bg-indigo-200 text-indigo-700 rounded-full border border-indigo-300 transition-colors font-medium"
              >
                Welcome Tour
              </button>
              <button 
                onClick={() => {
                  setInputValue("How do I create a review?");
                  setTimeout(() => handleSendMessage(), 100);
                }}
                className="text-xs py-1 px-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-full border border-indigo-200 transition-colors"
              >
                How to create a review?
              </button>
              <button 
                onClick={() => {
                  setInputValue("SEO optimization tips");
                  setTimeout(() => handleSendMessage(), 100);
                }}
                className="text-xs py-1 px-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-full border border-indigo-200 transition-colors"
              >
                SEO tips
              </button>
              <button 
                onClick={() => {
                  setInputValue("How do I use templates?");
                  setTimeout(() => handleSendMessage(), 100);
                }}
                className="text-xs py-1 px-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-full border border-indigo-200 transition-colors"
              >
                Using templates
              </button>
              <button 
                onClick={() => {
                  setInputValue("Pricing information");
                  setTimeout(() => handleSendMessage(), 100);
                }}
                className="text-xs py-1 px-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-full border border-indigo-200 transition-colors"
              >
                Pricing info
              </button>
            </div>
          </div>
          
          <div className="flex">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            <Button 
              onClick={handleSendMessage} 
              className="rounded-l-none bg-green-600 hover:bg-green-700"
            >
              <i className="ri-send-plane-fill"></i>
            </Button>
          </div>
        </div>
        
        <DialogFooter>
          <div className="w-full text-xs text-gray-500">
            <p>Support hours: 9am-5pm EST, Mon-Fri</p>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}