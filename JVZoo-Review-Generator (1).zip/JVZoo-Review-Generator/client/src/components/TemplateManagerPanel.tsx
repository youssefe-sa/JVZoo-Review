import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { FormData } from "@/lib/types";
import { v4 as uuidv4 } from 'uuid';

interface TemplateManagerPanelProps {
  formData: FormData;
  onLoadTemplate: (template: any) => void;
}

// Mocked templates - this would actually use localStorage or the backend
const MOCK_TEMPLATES = [
  {
    id: "t1",
    templateName: "Professional Review",
    templateDescription: "Balanced professional review with all standard elements",
    createdAt: "2023-11-15T12:00:00Z",
    updatedAt: "2023-11-15T12:00:00Z"
  },
  {
    id: "t2",
    templateName: "Minimal Review",
    templateDescription: "Clean, minimalist review focusing on key benefits",
    createdAt: "2023-10-22T09:30:00Z",
    updatedAt: "2023-10-22T09:30:00Z"
  }
];

export default function TemplateManagerPanel({
  formData,
  onLoadTemplate
}: TemplateManagerPanelProps) {
  const { toast } = useToast();
  const [expanded, setExpanded] = useState(false);
  const [templates, setTemplates] = useState(MOCK_TEMPLATES);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [newTemplateName, setNewTemplateName] = useState("");
  const [newTemplateDescription, setNewTemplateDescription] = useState("");
  
  const handleSaveTemplate = () => {
    if (!newTemplateName.trim()) {
      toast({
        title: "Template name required",
        description: "Please enter a name for your template",
        variant: "destructive"
      });
      return;
    }
    
    // Create new template
    const newTemplate = {
      id: uuidv4(),
      templateName: newTemplateName,
      templateDescription: newTemplateDescription,
      templateConfig: { ...formData },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // In a real app, we'd save this to localStorage or the backend
    setTemplates([newTemplate, ...templates]);
    
    // Reset form and close dialog
    setNewTemplateName("");
    setNewTemplateDescription("");
    setShowSaveDialog(false);
    
    toast({
      title: "Template saved",
      description: "Your template has been saved successfully",
    });
  };
  
  const handleLoadTemplate = (templateId: string) => {
    // This would actually fetch the template from localStorage or backend
    // Simulating a template load
    toast({
      title: "Template loaded",
      description: "Template settings have been applied",
    });
    
    // Call parent's load handler
    onLoadTemplate({
      // Mocked template data - would come from storage in a real app
      productName: "Example Product",
      reviewStyle: "balanced",
      toneStyle: "professional",
      includePricingTable: true,
      // ...other properties would be here
    });
  };
  
  const handleDeleteTemplate = (templateId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    
    // Remove template from list
    setTemplates(templates.filter(t => t.id !== templateId));
    
    toast({
      title: "Template deleted",
      description: "Your template has been deleted",
    });
  };
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div 
        className="p-5 border-b border-gray-100 flex justify-between items-center cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center">
          <i className="ri-save-line text-lg text-indigo-600 mr-2"></i>
          <h2 className="text-lg font-semibold text-gray-800">Template Manager</h2>
        </div>
        <button 
          className="p-1 rounded-full hover:bg-gray-100 transition-all text-gray-500"
        >
          <i className={`ri-arrow-${expanded ? 'up' : 'down'}-s-line text-lg`}></i>
        </button>
      </div>
      
      <div className={`transition-all duration-300 ${expanded ? 'max-h-[800px]' : 'max-h-0'} overflow-hidden`}>
        <div className="p-5 border-t border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-gray-700">Saved Templates</h3>
            <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
              <DialogTrigger asChild>
                <Button size="sm" className="text-xs bg-indigo-600 hover:bg-indigo-700">
                  <i className="ri-add-line mr-1"></i> Save Current Settings
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Save as Template</DialogTitle>
                  <DialogDescription>
                    Save your current review settings as a reusable template
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label htmlFor="templateName" className="text-right text-sm font-medium col-span-1">
                      Name
                    </label>
                    <Input
                      id="templateName"
                      value={newTemplateName}
                      onChange={(e) => setNewTemplateName(e.target.value)}
                      placeholder="e.g., My Professional Template"
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <label htmlFor="templateDescription" className="text-right text-sm font-medium col-span-1">
                      Description
                    </label>
                    <Input
                      id="templateDescription"
                      value={newTemplateDescription}
                      onChange={(e) => setNewTemplateDescription(e.target.value)}
                      placeholder="Optional description"
                      className="col-span-3"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowSaveDialog(false)}>Cancel</Button>
                  <Button onClick={handleSaveTemplate}>Save Template</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          
          {templates.length > 0 ? (
            <div className="space-y-2">
              {templates.map((template) => (
                <div 
                  key={template.id}
                  onClick={() => handleLoadTemplate(template.id)}
                  className="p-3 border border-gray-200 rounded-lg hover:border-indigo-300 hover:bg-indigo-50 transition-all cursor-pointer"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-sm font-medium text-gray-800">{template.templateName}</h4>
                      {template.templateDescription && (
                        <p className="text-xs text-gray-500 mt-0.5">{template.templateDescription}</p>
                      )}
                      <p className="text-xs text-gray-400 mt-1">
                        Saved on {new Date(template.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex space-x-1">
                      <button 
                        className="p-1.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-100 rounded-full transition-all"
                        title="Load template"
                      >
                        <i className="ri-download-line text-sm"></i>
                      </button>
                      <button 
                        className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-100 rounded-full transition-all"
                        title="Delete template"
                        onClick={(e) => handleDeleteTemplate(template.id, e)}
                      >
                        <i className="ri-delete-bin-line text-sm"></i>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 flex flex-col items-center justify-center text-gray-500">
              <i className="ri-file-list-3-line text-4xl mb-2"></i>
              <p className="text-sm">No templates saved yet</p>
              <p className="text-xs mt-1">Save your current settings as a template to reuse later</p>
            </div>
          )}
          
          <div className="mt-4 pt-3 border-t border-gray-200">
            <p className="text-xs text-gray-500">
              Templates save all your current review settings for quick reuse in future projects.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}