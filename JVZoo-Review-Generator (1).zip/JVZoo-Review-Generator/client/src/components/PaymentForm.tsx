import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/AuthContext';
import { apiRequest } from '../lib/api';
import { CreditCardIcon, CheckIcon, ShieldCheckIcon, ArrowRightIcon } from '@heroicons/react/24/outline';

// Form validation schema
const paymentFormSchema = z.object({
  subscriptionPlanId: z.number().positive({ message: 'Valid subscription plan is required' }),
  cardName: z.string().min(2, { message: 'Name on card is required' }),
  cardNumber: z.string().min(16, { message: 'Valid card number is required' }).max(19),
  expiryMonth: z.string().min(1, { message: 'Required' }),
  expiryYear: z.string().min(1, { message: 'Required' }),
  cvv: z.string().min(3, { message: 'CVV is required' }).max(4),
  billingAddress: z.string().min(5, { message: 'Billing address is required' }),
  city: z.string().min(2, { message: 'City is required' }),
  state: z.string().min(2, { message: 'State is required' }),
  zipCode: z.string().min(4, { message: 'Zip code is required' }),
  country: z.string().min(2, { message: 'Country is required' }),
  includeTrial: z.boolean().default(false),
  agreeTerms: z.boolean().refine(val => val === true, { message: 'You must agree to the terms and conditions' }),
});

type PaymentFormValues = z.infer<typeof paymentFormSchema>;

export interface PlanDetails {
  id: number;
  name: string;
  price: string;
  billingCycle: 'monthly' | 'yearly' | 'trial';
  description: string;
  features: string[];
}

interface PaymentFormProps {
  plan: PlanDetails;
  onSuccess?: () => void;
  onCancel?: () => void; // New callback for cancellation
}

export function PaymentForm({ plan, onSuccess, onCancel }: PaymentFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { isAuthenticated, user } = useAuth();

  // Default form values
  const defaultValues: Partial<PaymentFormValues> = {
    cardName: '',
    cardNumber: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: '',
    billingAddress: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'US',
    agreeTerms: false,
  };

  const form = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues,
  });

  // Set subscription plan ID when the component mounts
  useEffect(() => {
    if (plan && plan.id) {
      form.setValue('subscriptionPlanId', plan.id);
    }
  }, [plan, form]);

  // Handle form submission
  const onSubmit = async (data: PaymentFormValues) => {
    setIsLoading(true);
    
    try {
      // Check if user is authenticated
      if (!isAuthenticated) {
        toast({
          title: "Authentication required",
          description: "Please log in or create an account to complete your purchase.",
          variant: "destructive",
        });
        return;
      }
      
      // In a production environment, you would securely tokenize the card info
      // with a payment processor like Stripe before sending to your server
      
      // Call the API to process the payment
      const response = await apiRequest('/api/process-payment', {
        method: 'POST',
        data: {
          ...data,
          // Extract the last 4 digits of the card number
          cardNumber: data.cardNumber.replace(/\s/g, ''),
          subscriptionPlanId: plan.id,
          billingCycle: plan.billingCycle
        }
      });
      
      if (response.success) {
        toast({
          title: "Payment successful!",
          description: `You are now subscribed to the ${plan.name} plan.`,
        });
        
        // If there's an onSuccess callback, call it
        if (onSuccess) {
          onSuccess();
        } else {
          // Redirect to the dashboard or a success page
          window.location.href = '/dashboard';
        }
      } else {
        throw new Error(response.message || 'Payment failed');
      }
    } catch (error) {
      console.error("Payment error:", error);
      toast({
        title: "Payment failed",
        description: error instanceof Error ? error.message : "There was an error processing your payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // A function to format card number with spaces
  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(' ');
    } else {
      return value;
    }
  };

  // Generate an array of years for expiry date
  const years = Array.from({ length: 10 }, (_, i) => (new Date().getFullYear() + i).toString());

  return (
    <div className="flex flex-col md:flex-row gap-8 max-w-6xl mx-auto p-4">
      {/* Left Side - Payment Form */}
      <div className="w-full md:w-2/3">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Complete Your Purchase</CardTitle>
            <CardDescription>
              Complete your payment details to get instant access to {plan.name} features
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Payment Information</h3>
                  
                  <div className="flex items-center gap-2 text-sm bg-blue-50 text-blue-700 p-3 rounded-md">
                    <ShieldCheckIcon className="h-5 w-5" />
                    <span>Your payment information is encrypted and secure</span>
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="cardName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name on Card</FormLabel>
                        <FormControl>
                          <Input placeholder="John Smith" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="cardNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Card Number</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input 
                              placeholder="4242 4242 4242 4242" 
                              maxLength={19}
                              {...field}
                              onChange={e => {
                                const formatted = formatCardNumber(e.target.value);
                                field.onChange(formatted);
                              }}
                            />
                            <CreditCardIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div className="col-span-1">
                      <FormField
                        control={form.control}
                        name="expiryMonth"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Expiry Month</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="MM" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {Array.from({ length: 12 }, (_, i) => {
                                  const month = (i + 1).toString().padStart(2, '0');
                                  return (
                                    <SelectItem key={month} value={month}>
                                      {month}
                                    </SelectItem>
                                  );
                                })}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="col-span-1">
                      <FormField
                        control={form.control}
                        name="expiryYear"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Expiry Year</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="YYYY" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {years.map(year => (
                                  <SelectItem key={year} value={year}>
                                    {year}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="col-span-1">
                      <FormField
                        control={form.control}
                        name="cvv"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>CVV</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="123" 
                                maxLength={4}
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <h3 className="text-lg font-medium">Billing Address</h3>
                  
                  <FormField
                    control={form.control}
                    name="billingAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Address</FormLabel>
                        <FormControl>
                          <Input placeholder="123 Main St" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>City</FormLabel>
                          <FormControl>
                            <Input placeholder="New York" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="state"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>State / Province</FormLabel>
                          <FormControl>
                            <Input placeholder="NY" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="zipCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ZIP / Postal Code</FormLabel>
                          <FormControl>
                            <Input placeholder="10001" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="country"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Country</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select Country" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="US">United States</SelectItem>
                              <SelectItem value="CA">Canada</SelectItem>
                              <SelectItem value="UK">United Kingdom</SelectItem>
                              <SelectItem value="AU">Australia</SelectItem>
                              <SelectItem value="DE">Germany</SelectItem>
                              <SelectItem value="FR">France</SelectItem>
                              <SelectItem value="JP">Japan</SelectItem>
                              <SelectItem value="IN">India</SelectItem>
                              <SelectItem value="BR">Brazil</SelectItem>
                              <SelectItem value="MX">Mexico</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <FormField
                    control={form.control}
                    name="agreeTerms"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4 border">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            I agree to the{" "}
                            <Link href="/terms" className="text-indigo-600 hover:underline">
                              Terms of Service
                            </Link>{" "}
                            and{" "}
                            <Link href="/privacy" className="text-indigo-600 hover:underline">
                              Privacy Policy
                            </Link>
                          </FormLabel>
                          <FormMessage />
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4">
                  {onCancel && (
                    <Button 
                      type="button" 
                      variant="outline"
                      className="w-full sm:w-auto" 
                      onClick={onCancel}
                      disabled={isLoading}
                    >
                      Back
                    </Button>
                  )}
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>Processing...</>
                    ) : (
                      <>
                        Complete Payment
                        <ArrowRightIcon className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex flex-col items-start">
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <ShieldCheckIcon className="h-4 w-4 text-gray-400" />
              <span>Your payment information is secure and encrypted</span>
            </div>
          </CardFooter>
        </Card>
      </div>

      {/* Right Side - Order Summary */}
      <div className="w-full md:w-1/3">
        <Card>
          <CardHeader>
            <CardTitle>Order Summary</CardTitle>
            <CardDescription>
              {plan.name} Plan - {plan.billingCycle === 'monthly' ? 'Monthly' : 'Annual'} Billing
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="font-medium">{plan.name} Plan</span>
                <span>${plan.price}/{plan.billingCycle === 'monthly' ? 'mo' : 'yr'}</span>
              </div>
              {plan.billingCycle === 'yearly' && (
                <div className="text-sm text-green-600 flex items-center">
                  <CheckIcon className="h-4 w-4 mr-1" />
                  <span>Save 25% with annual billing</span>
                </div>
              )}
            </div>
            
            <Separator />
            
            <div className="space-y-1">
              <h4 className="font-medium">What's included:</h4>
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <CheckIcon className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <Separator />
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Subtotal</span>
                <span className="text-sm">${plan.price}</span>
              </div>
              {/* If applicable, you can add tax or other charges */}
              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span>${plan.price}/{plan.billingCycle === 'monthly' ? 'mo' : 'yr'}</span>
              </div>
              <div className="text-xs text-gray-500">
                {plan.billingCycle === 'monthly' 
                  ? 'Billed monthly. Cancel anytime.' 
                  : 'Billed annually. Cancel anytime.'}
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium mb-2">100% Satisfaction Guarantee</h4>
              <p className="text-sm text-gray-600">
                Try ReviewPro risk-free for 14 days. If you're not completely satisfied, contact us for a full refund.
              </p>
            </div>
            
            <div className="flex items-center justify-center space-x-4">
              <img src="https://cdn-icons-png.flaticon.com/512/196/196578.png" alt="Visa" className="h-6" />
              <img src="https://cdn-icons-png.flaticon.com/512/196/196561.png" alt="MasterCard" className="h-6" />
              <img src="https://cdn-icons-png.flaticon.com/512/196/196539.png" alt="American Express" className="h-6" />
              <img src="https://cdn-icons-png.flaticon.com/512/196/196581.png" alt="PayPal" className="h-6" />
            </div>
          </CardContent>
        </Card>
        
        <div className="mt-4 text-center">
          <p className="text-sm text-gray-500">
            Need help? <Link href="/support/contact" className="text-indigo-600 hover:underline">Contact support</Link>
          </p>
        </div>
      </div>
    </div>
  );
}