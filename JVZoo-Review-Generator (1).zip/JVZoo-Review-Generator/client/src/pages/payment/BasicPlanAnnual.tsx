import React from 'react';
import Layout from '@/components/Layout';
import { PaymentForm } from '@/components/PaymentForm';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import { Link } from 'wouter';

export default function BasicPlanAnnual() {
  // Calculate annual price (monthly price * 12 with 25% discount)
  const monthlyPrice = 29;
  const annualPrice = Math.round(monthlyPrice * 12 * 0.75).toString();
  
  // Plan details
  const planDetails = {
    name: 'Basic',
    price: annualPrice,
    billingCycle: 'yearly' as const,
    description: 'Essential tools for creating professional product reviews',
    features: [
      '20 AI-generated reviews per month',
      'Basic SEO optimization for all reviews',
      '3 design themes to choose from',
      'Standard review templates for various products',
      'Email support with 24-hour response time',
      '14-day money-back guarantee',
      '25% discount with annual billing',
    ],
  };

  return (
    <Layout variant="landing">
      <div className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <Link href="/#pricing" className="inline-flex items-center text-indigo-600 hover:text-indigo-700">
              <ArrowLeftIcon className="h-4 w-4 mr-2" />
              Back to Pricing
            </Link>
            <h1 className="text-3xl font-bold mt-4 mb-2">Complete Your Basic Annual Plan Purchase</h1>
            <p className="text-gray-600">
              You're just a step away from creating professional product reviews with our Basic annual plan, with 25% savings.
            </p>
          </div>
          
          <PaymentForm plan={planDetails} />
        </div>
      </div>
    </Layout>
  );
}