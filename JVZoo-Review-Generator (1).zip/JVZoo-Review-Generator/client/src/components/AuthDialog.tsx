import { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/AuthContext';

// Form validation schemas
const loginSchema = z.object({
  usernameOrEmail: z.string().min(1, 'Username or email is required'),
  password: z.string().min(1, 'Password is required'),
});

const forgotPasswordSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
});

type LoginFormData = z.infer<typeof loginSchema>;
type ForgotPasswordFormData = z.infer<typeof forgotPasswordSchema>;

interface AuthDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess?: () => void; // Callback when authentication is successful
  defaultTab?: 'login' | 'register'; // Optional prop to set the default tab
}

export function AuthDialog({ isOpen, onClose, onAuthSuccess, defaultTab = 'login' }: AuthDialogProps) {
  const { login, isLoading, requestPasswordReset } = useAuth();
  const { toast } = useToast();
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotPasswordSuccess, setForgotPasswordSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'login' | 'register'>(defaultTab);
  
  // Login form
  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      usernameOrEmail: '',
      password: '',
    },
  });
  
  // Forgot password form
  const forgotPasswordForm = useForm<ForgotPasswordFormData>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      email: '',
    },
  });

  const handleLoginSubmit = async (data: LoginFormData) => {
    // Using updated auth API with usernameOrEmail
    const success = await login(data.usernameOrEmail, data.password);
    if (success) {
      loginForm.reset();
      // Call onAuthSuccess callback if provided
      if (onAuthSuccess) {
        onAuthSuccess();
      }
      onClose();
    }
  };
  
  const handleForgotPasswordSubmit = async (data: ForgotPasswordFormData) => {
    try {
      // Call the password reset API
      const success = await requestPasswordReset(data.email);
      
      if (success) {
        // Show success message
        setForgotPasswordSuccess(true);
        
        // Clear form and go back to login after 3 seconds
        setTimeout(() => {
          setShowForgotPassword(false);
          forgotPasswordForm.reset();
          setForgotPasswordSuccess(false);
        }, 3000);
        
        toast({
          title: "Request Submitted",
          description: "If an account with that email exists, a password reset link will be sent.",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process your request. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        {showForgotPassword ? (
          <Card className="border-0 shadow-none">
            <CardHeader>
              <CardTitle className="text-lg">Password Reset</CardTitle>
              <CardDescription>
                Enter your email address below and we'll send you a link to reset your password.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...forgotPasswordForm}>
                <form onSubmit={forgotPasswordForm.handleSubmit(handleForgotPasswordSubmit)} className="space-y-4">
                  <FormField
                    control={forgotPasswordForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email <span className="text-red-500">*</span></FormLabel>
                        <FormControl>
                          <Input 
                            type="email" 
                            placeholder="Enter your email address"
                            required 
                            disabled={isLoading || forgotPasswordSuccess}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {forgotPasswordSuccess && (
                    <Alert className="bg-green-50 border-green-200">
                      <AlertDescription className="text-green-800">
                        Password reset email sent! Check your inbox for instructions.
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="flex flex-col gap-2 pt-2">
                    <Button 
                      type="submit" 
                      disabled={isLoading || forgotPasswordSuccess}
                    >
                      {isLoading ? 'Sending...' : 'Send Reset Link'}
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => {
                        setShowForgotPassword(false);
                        forgotPasswordForm.reset();
                      }}
                      disabled={isLoading}
                    >
                      Back to Login
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>Login to ReviewPro</DialogTitle>
              <DialogDescription>
                Enter your credentials to access your account.
              </DialogDescription>
            </DialogHeader>
            
            <Form {...loginForm}>
              <form onSubmit={loginForm.handleSubmit(handleLoginSubmit)} className="space-y-4 py-4">
                <FormField
                  control={loginForm.control}
                  name="usernameOrEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username or Email <span className="text-red-500">*</span></FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your username or email" required {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password <span className="text-red-500">*</span></FormLabel>
                      <FormControl>
                        <Input 
                        type="password" 
                        placeholder="Enter your password" 
                        autoComplete="current-password"
                        required 
                        {...field} 
                      />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="text-right">
                  <Button 
                    variant="link" 
                    className="px-0 font-normal text-sm text-blue-600" 
                    type="button"
                    onClick={() => setShowForgotPassword(true)}
                  >
                    Forgot password?
                  </Button>
                </div>
                
                <DialogFooter>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? 'Logging in...' : 'Login'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}