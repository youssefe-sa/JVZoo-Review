import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { PaymentForm, PlanDetails } from '../../components/PaymentForm';
import { useAuth } from '@/lib/AuthContext';
import { AuthDialog } from '../../components/AuthDialog';
import { apiRequest } from '../../lib/api';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';

export default function PaymentPage() {
  const params = useParams<{ cycle: string, planId: string }>();
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const [plan, setPlan] = useState<PlanDetails | null>(null);
  const [isAuthDialogOpen, setIsAuthDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if we have plan details in session storage
    const storedPlan = sessionStorage.getItem('selectedPlan');
    
    if (storedPlan) {
      setPlan(JSON.parse(storedPlan));
      setIsLoading(false);
      return;
    }
    
    // If no stored plan, fetch from API using parameters
    const fetchPlanDetails = async () => {
      setIsLoading(true);
      
      try {
        // Try to fetch the plan from the API using the planId param
        if (params.planId) {
          const response = await apiRequest(`/api/subscription-plans/${params.planId}`);
          
          if (response.success && response.plan) {
            // Process the plan data
            const planData = {
              id: response.plan.id,
              name: response.plan.name,
              description: response.plan.description,
              price: response.plan.price,
              billingCycle: params.cycle as 'monthly' | 'yearly',
              features: typeof response.plan.features === 'string' 
                ? JSON.parse(response.plan.features) 
                : response.plan.features
            };
            
            // Store plan in session storage for later use
            sessionStorage.setItem('selectedPlan', JSON.stringify(planData));
            
            // Set the plan in state
            setPlan(planData);
            setIsLoading(false);
            return;
          }
        }
        
        // If we couldn't fetch the plan or there's no planId, redirect
        setLocation('/payment/plans');
      } catch (error) {
        console.error('Error fetching plan details:', error);
        setLocation('/payment/plans');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchPlanDetails();
  }, [params, setLocation]);

  // Show login dialog if not authenticated
  useEffect(() => {
    if (!isAuthenticated && !isAuthDialogOpen) {
      setIsAuthDialogOpen(true);
    }
  }, [isAuthenticated, isAuthDialogOpen]);

  // Handle successful payment
  const handlePaymentSuccess = () => {
    // Clear stored plan
    sessionStorage.removeItem('selectedPlan');
    
    // Redirect to success page or dashboard
    setLocation('/payment/success');
  };

  // Handle authentication dialog close
  const handleAuthDialogClose = () => {
    setIsAuthDialogOpen(false);
    
    // If still not authenticated, redirect back to plans
    if (!isAuthenticated) {
      setLocation('/payment/plans');
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-12 px-4 text-center">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-64 mb-8 mx-auto"></div>
          <div className="h-64 bg-gray-200 rounded-lg max-w-3xl mx-auto"></div>
        </div>
      </div>
    );
  }

  if (!plan) {
    return (
      <div className="container mx-auto py-12 px-4 text-center">
        <h2 className="text-2xl font-bold mb-4">Plan Not Found</h2>
        <p className="mb-6">Sorry, we couldn't find the plan you're looking for.</p>
        <Button onClick={() => setLocation('/payment/plans')}>
          Back to Plans
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <Button 
          variant="ghost" 
          onClick={() => setLocation('/payment/plans')}
          className="flex items-center gap-2"
        >
          ← Back to Plans
        </Button>
      </div>
      
      <h1 className="text-3xl font-bold mb-8 text-center">Checkout - {plan.name}</h1>
      
      {!isAuthenticated && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            You need to be logged in to complete your purchase. Please log in or create an account.
          </AlertDescription>
        </Alert>
      )}
      
      <PaymentForm plan={plan} onSuccess={handlePaymentSuccess} />
      
      {/* Login Dialog */}
      <AuthDialog 
        isOpen={isAuthDialogOpen} 
        onClose={handleAuthDialogClose} 
        defaultTab="login"
      />
    </div>
  );
}