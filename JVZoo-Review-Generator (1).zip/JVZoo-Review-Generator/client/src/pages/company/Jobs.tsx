import React from 'react';
import { Helmet } from "react-helmet";
import Layout from "@/components/Layout";
import { MapPin, Clock, Briefcase, Users, Sparkles, CheckCircle } from "lucide-react";

export default function Jobs() {
  // Sample job listings
  const jobs = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      department: "Engineering",
      type: "Full-time",
      location: "Remote (US/Europe)",
      posted: "2 weeks ago",
      description: "We're looking for a senior frontend developer with React expertise to help us build the next generation of our AI-powered review creation platform.",
      responsibilities: [
        "Lead development of key frontend features",
        "Collaborate with design and product teams to create intuitive user experiences",
        "Optimize application performance and responsiveness",
        "Mentor junior developers and conduct code reviews",
        "Participate in technical planning and architecture discussions"
      ],
      requirements: [
        "5+ years of frontend development experience",
        "Expert knowledge of React, TypeScript, and modern JavaScript",
        "Experience with CSS frameworks like Tailwind, styled-components",
        "Strong understanding of responsive design principles",
        "Familiarity with state management (Redux, Context API, etc.)",
        "Experience with testing frameworks (Jest, React Testing Library)"
      ]
    },
    {
      id: 2,
      title: "AI/ML Engineer",
      department: "AI Research",
      type: "Full-time",
      location: "Remote",
      posted: "1 week ago",
      description: "Join our AI team to develop cutting-edge natural language processing models that power our content generation capabilities.",
      responsibilities: [
        "Design, train and optimize NLP models for product review generation",
        "Collaborate with engineering teams to integrate AI capabilities into our platform",
        "Research and implement state-of-the-art techniques in text generation",
        "Develop evaluation metrics for generated content quality",
        "Create tools to fine-tune AI outputs based on user feedback"
      ],
      requirements: [
        "MS or PhD in Computer Science, Machine Learning, or related field",
        "Strong experience with NLP models and techniques (BERT, GPT, etc.)",
        "Proficiency in Python and ML frameworks (PyTorch, TensorFlow)",
        "Experience deploying and scaling ML models in production",
        "Strong understanding of language models and text generation",
        "Publications or demonstrable projects in NLP a plus"
      ]
    },
    {
      id: 3,
      title: "Digital Marketing Manager",
      department: "Marketing",
      type: "Full-time",
      location: "Remote",
      posted: "3 days ago",
      description: "Help grow ReviewPro by developing and executing digital marketing strategies that drive user acquisition and engagement.",
      responsibilities: [
        "Develop and manage digital marketing campaigns across channels",
        "Analyze campaign performance and optimize for conversion",
        "Create content strategy for blog, social media, and email marketing",
        "Collaborate with product team on user onboarding and retention initiatives",
        "Manage marketing budget and track ROI across initiatives"
      ],
      requirements: [
        "5+ years of digital marketing experience, preferably in SaaS",
        "Proven track record in managing successful acquisition campaigns",
        "Experience with SEO, content marketing, and social media",
        "Strong analytical skills and experience with marketing analytics tools",
        "Excellent writing and communication abilities",
        "Knowledge of affiliate marketing landscape a plus"
      ]
    }
  ];

  // Company benefits
  const benefits = [
    {
      title: "Health & Wellness",
      description: "Comprehensive health insurance, mental health resources, and wellness stipend to keep you at your best.",
      icon: <CheckCircle className="h-8 w-8 text-indigo-500" />
    },
    {
      title: "Flexible Work",
      description: "100% remote work with flexible hours, allowing you to work when and where you're most productive.",
      icon: <Clock className="h-8 w-8 text-indigo-500" />
    },
    {
      title: "Professional Growth",
      description: "Learning stipend, conference attendance, and career development opportunities to help you grow.",
      icon: <Sparkles className="h-8 w-8 text-indigo-500" />
    },
    {
      title: "Team Culture",
      description: "Collaborative environment with regular virtual team events and annual company retreats.",
      icon: <Users className="h-8 w-8 text-indigo-500" />
    }
  ];

  return (
    <Layout variant="landing">
      <Helmet>
        <title>Careers | ReviewPro</title>
        <meta name="description" content="Join the ReviewPro team and help revolutionize how marketers create product reviews. Explore current openings in engineering, AI research, marketing, and more." />
      </Helmet>
      
      <div className="bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Careers Header Section */}
          <div className="text-center">
            <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl lg:text-5xl">Join Our Team</h1>
            <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
              We're building the future of product review creation. Join us and make an impact.
            </p>
          </div>
          
          {/* Company Culture Section */}
          <div className="mt-20">
            <div className="lg:grid lg:grid-cols-12 lg:gap-8 items-center">
              <div className="lg:col-span-5">
                <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
                  Our Culture
                </h2>
                <p className="mt-3 text-lg text-gray-500">
                  At ReviewPro, we're passionate about using technology to solve real problems for content creators and marketers. We believe in building products that genuinely improve how people work.
                </p>
                <div className="mt-10 space-y-10">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white">
                        <Sparkles className="h-6 w-6" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Innovation-Driven</h3>
                      <p className="mt-2 text-base text-gray-500">
                        We push boundaries and embrace new ideas, constantly looking for better ways to solve problems.
                      </p>
                    </div>
                  </div>
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white">
                        <Users className="h-6 w-6" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Collaborative & Inclusive</h3>
                      <p className="mt-2 text-base text-gray-500">
                        We believe diverse perspectives lead to better outcomes and foster an environment where everyone can contribute.
                      </p>
                    </div>
                  </div>
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white">
                        <Briefcase className="h-6 w-6" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Impact-Focused</h3>
                      <p className="mt-2 text-base text-gray-500">
                        We measure success by the real impact we make for our users, not by hours worked or lines of code written.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-10 lg:mt-0 lg:col-span-7 pl-0 lg:pl-8">
                <div className="aspect-w-4 aspect-h-3 rounded-lg overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1516321497487-e288fb19713f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
                    alt="Team collaboration"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
          
          {/* Benefits Section */}
          <div className="mt-32">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
                Benefits & Perks
              </h2>
              <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
                We believe in taking care of our team with competitive compensation and benefits.
              </p>
            </div>
            
            <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {benefits.map((benefit, index) => (
                <div key={index} className="pt-6">
                  <div className="flow-root bg-gray-50 rounded-lg px-6 pb-8 h-full">
                    <div className="-mt-6">
                      <div>
                        <span className="inline-flex items-center justify-center p-3 bg-indigo-500 rounded-md shadow-lg">
                          {benefit.icon}
                        </span>
                      </div>
                      <h3 className="mt-8 text-lg font-medium text-gray-900 tracking-tight">
                        {benefit.title}
                      </h3>
                      <p className="mt-5 text-base text-gray-500">
                        {benefit.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Open Positions Section */}
          <div className="mt-32">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight sm:text-4xl">
                Open Positions
              </h2>
              <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
                Join our team and help shape the future of content creation.
              </p>
            </div>
            
            <div className="mt-12 space-y-10">
              {jobs.map((job) => (
                <div key={job.id} className="bg-white shadow-lg rounded-lg overflow-hidden border border-gray-100">
                  <div className="px-6 py-8">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-2xl font-bold text-gray-900">{job.title}</h3>
                        <div className="mt-2 flex items-center text-sm text-gray-500">
                          <Briefcase className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                          <span>{job.department}</span>
                          <span className="mx-2">•</span>
                          <Clock className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                          <span>{job.type}</span>
                          <span className="mx-2">•</span>
                          <MapPin className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                          <span>{job.location}</span>
                        </div>
                      </div>
                      <div className="hidden sm:block">
                        <span className="inline-flex px-3 py-1 text-xs font-semibold rounded-full bg-indigo-100 text-indigo-800">
                          {job.posted}
                        </span>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <p className="text-gray-600">{job.description}</p>
                    </div>
                    
                    <div className="mt-6 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
                      <div>
                        <h4 className="text-lg font-medium text-gray-900">Responsibilities</h4>
                        <ul className="mt-2 text-sm text-gray-500 space-y-2">
                          {job.responsibilities.map((item, index) => (
                            <li key={index} className="flex items-start">
                              <span className="mr-2">•</span>
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="text-lg font-medium text-gray-900">Requirements</h4>
                        <ul className="mt-2 text-sm text-gray-500 space-y-2">
                          {job.requirements.map((item, index) => (
                            <li key={index} className="flex items-start">
                              <span className="mr-2">•</span>
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    
                    <div className="mt-8">
                      <a
                        href="#"
                        className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
                      >
                        Apply Now
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Don't See a Role Section */}
          <div className="mt-16 bg-indigo-700 rounded-lg shadow-xl overflow-hidden">
            <div className="pt-10 pb-12 px-6 sm:pt-16 sm:px-16 lg:py-16 lg:pr-0 xl:py-20 xl:px-20">
              <div className="lg:self-center">
                <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
                  <span className="block">Don't see the right role?</span>
                </h2>
                <p className="mt-4 text-lg leading-6 text-indigo-200">
                  We're always looking for talented individuals to join our team. Send us your resume and let us know how you can contribute to ReviewPro.
                </p>
                <a
                  href="#"
                  className="mt-8 bg-white border border-transparent rounded-md shadow px-5 py-3 inline-flex items-center text-base font-medium text-indigo-600 hover:bg-indigo-50"
                >
                  Send Open Application
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}