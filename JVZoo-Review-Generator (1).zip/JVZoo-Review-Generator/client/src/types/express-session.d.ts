import 'express-session';

declare module 'express-session' {
  interface SessionData {
    userId: number;
    username: string;
    firebaseUid?: string; // Optional Firebase User ID for integration with Firebase Auth
  }
}