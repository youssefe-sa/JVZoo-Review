import React from 'react';
import { Helmet } from "react-helmet";
import Layout from "@/components/Layout";
import { Code, Zap, Shield, Database, Key, Layers, ArrowRight } from "lucide-react";

export default function API() {
  // Code examples
  const codeExamples = {
    generateReview: `// Generate a product review with ReviewPro API
fetch('https://api.reviewpro.com/v1/reviews/generate', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
    productName: 'Sony WH-1000XM4 Wireless Headphones',
    productCategory: 'Electronics',
    keyFeatures: [
      'Industry-leading noise cancellation',
      '30-hour battery life',
      'Touch controls'
    ],
    tone: 'informative',
    includeComparisonTable: true,
    competingProducts: 'Bose QuietComfort, Apple AirPods Max',
    targetWordCount: 1500
  })
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));`,

    retrieveTemplates: `// Retrieve available review templates
fetch('https://api.reviewpro.com/v1/templates', {
  method: 'GET',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY'
  }
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));`,

    seoAnalysis: `// Analyze review content for SEO
fetch('https://api.reviewpro.com/v1/seo/analyze', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
    content: "Your review content here...",
    targetKeywords: ["wireless headphones", "noise cancellation", "Sony headphones"],
    locale: "en-US"
  })
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));`
  };

  // API Endpoints
  const apiEndpoints = [
    {
      name: "Review Generation",
      endpoint: "POST /v1/reviews/generate",
      description: "Generate a complete product review based on provided parameters and preferences.",
      features: ["AI-powered content creation", "Customizable tone and style", "Multiple template options"]
    },
    {
      name: "Template Management",
      endpoint: "GET /v1/templates",
      description: "Retrieve available review templates or create custom templates for your content.",
      features: ["Fetch template library", "Create custom templates", "Update existing templates"]
    },
    {
      name: "SEO Analysis",
      endpoint: "POST /v1/seo/analyze",
      description: "Analyze review content for search engine optimization and get improvement suggestions.",
      features: ["Keyword optimization", "Readability analysis", "Structure recommendations"]
    },
    {
      name: "Comparison Tables",
      endpoint: "POST /v1/tables/generate",
      description: "Create comparison tables for multiple products with customizable features and styling.",
      features: ["Multi-product comparisons", "Custom feature highlighting", "Exportable formats"]
    }
  ];

  // Pricing tiers
  const pricingTiers = [
    {
      name: "Developer",
      price: "$49",
      description: "Perfect for individual developers and small projects",
      features: [
        "2,500 API requests per month",
        "5 requests per minute",
        "Standard review generation",
        "Basic SEO analysis",
        "Email support"
      ],
      cta: "Get Started"
    },
    {
      name: "Business",
      price: "$199",
      description: "Ideal for growing businesses with higher volume needs",
      features: [
        "25,000 API requests per month",
        "30 requests per minute",
        "Advanced review generation",
        "Full SEO analysis features",
        "Custom templates",
        "Priority email support"
      ],
      cta: "Contact Sales",
      highlighted: true
    },
    {
      name: "Enterprise",
      price: "Custom",
      description: "For large-scale implementations with custom requirements",
      features: [
        "Unlimited API requests",
        "Custom rate limits",
        "Premium review generation",
        "Advanced analytics",
        "Custom integrations",
        "Dedicated account manager",
        "24/7 support"
      ],
      cta: "Contact Sales"
    }
  ];

  return (
    <Layout variant="landing">
      <Helmet>
        <title>API Documentation | ReviewPro</title>
        <meta name="description" content="Integrate ReviewPro's powerful review generation and SEO optimization capabilities into your own applications with our API." />
      </Helmet>
      
      <div className="bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* API Header */}
          <div className="text-center">
            <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl lg:text-5xl">ReviewPro API</h1>
            <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
              Integrate our powerful review generation and SEO optimization capabilities into your own applications
            </p>
          </div>
          
          {/* API Overview */}
          <div className="mt-20">
            <div className="lg:grid lg:grid-cols-12 lg:gap-8 items-center">
              <div className="lg:col-span-5">
                <h2 className="text-2xl font-extrabold text-gray-900 tracking-tight sm:text-3xl">
                  API Overview
                </h2>
                <p className="mt-3 text-lg text-gray-500">
                  Our RESTful API gives you programmatic access to ReviewPro's content generation, SEO optimization, and template management capabilities.
                </p>
                <div className="mt-10 space-y-10">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white">
                        <Zap className="h-6 w-6" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Fast & Reliable</h3>
                      <p className="mt-2 text-base text-gray-500">
                        Built on a scalable cloud infrastructure with 99.9% uptime and fast response times.
                      </p>
                    </div>
                  </div>
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white">
                        <Shield className="h-6 w-6" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Secure</h3>
                      <p className="mt-2 text-base text-gray-500">
                        API access secured with authentication tokens and HTTPS encryption for all endpoints.
                      </p>
                    </div>
                  </div>
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white">
                        <Code className="h-6 w-6" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Developer Friendly</h3>
                      <p className="mt-2 text-base text-gray-500">
                        Comprehensive documentation, SDKs for popular languages, and interactive API reference.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-12 lg:mt-0 lg:col-span-7">
                <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden">
                  <div className="h-8 bg-gray-900 flex items-center px-4">
                    <div className="flex space-x-1.5">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                  </div>
                  <div className="px-5 py-6">
                    <pre className="language-javascript text-xs md:text-sm text-green-400 overflow-x-auto" style={{ whiteSpace: 'pre-wrap' }}>
                      {codeExamples.generateReview}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* API Endpoints */}
          <div className="mt-32">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">
                Core API Endpoints
              </h2>
              <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
                Our comprehensive API offers a wide range of functionality to power your content creation
              </p>
            </div>
            
            <div className="mt-16 grid gap-6 lg:grid-cols-2">
              {apiEndpoints.map((endpoint, index) => (
                <div key={index} className="bg-white rounded-lg border border-gray-200 shadow-md overflow-hidden">
                  <div className="px-6 py-8">
                    <div className="flex items-center">
                      <div className="flex-shrink-0">
                        <div className="flex items-center justify-center h-12 w-12 rounded-full bg-indigo-100 text-indigo-600">
                          {index === 0 ? <Layers className="h-6 w-6" /> : 
                          index === 1 ? <Database className="h-6 w-6" /> : 
                          index === 2 ? <Code className="h-6 w-6" /> : 
                          <Key className="h-6 w-6" />}
                        </div>
                      </div>
                      <div className="ml-4">
                        <h3 className="text-xl font-bold text-gray-900">{endpoint.name}</h3>
                        <div className="mt-1">
                          <code className="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded-md">
                            {endpoint.endpoint}
                          </code>
                        </div>
                      </div>
                    </div>
                    <p className="mt-4 text-gray-600">{endpoint.description}</p>
                    <ul className="mt-6 space-y-3">
                      {endpoint.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start">
                          <div className="flex-shrink-0">
                            <svg className="h-5 w-5 text-indigo-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                            </svg>
                          </div>
                          <span className="ml-2 text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Code Examples */}
          <div className="mt-32">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">
                Sample Code
              </h2>
              <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
                Get started quickly with these example implementations
              </p>
            </div>
            
            <div className="mt-12 space-y-8">
              <div className="bg-white rounded-lg border border-gray-200 shadow-md overflow-hidden">
                <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">Retrieve Templates</h3>
                </div>
                <div className="bg-gray-800 p-6">
                  <pre className="language-javascript text-sm text-green-400 overflow-x-auto">
                    {codeExamples.retrieveTemplates}
                  </pre>
                </div>
              </div>
              
              <div className="bg-white rounded-lg border border-gray-200 shadow-md overflow-hidden">
                <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900">SEO Analysis</h3>
                </div>
                <div className="bg-gray-800 p-6">
                  <pre className="language-javascript text-sm text-green-400 overflow-x-auto">
                    {codeExamples.seoAnalysis}
                  </pre>
                </div>
              </div>
            </div>
          </div>
          
          {/* API Pricing */}
          <div className="mt-32">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">
                API Pricing
              </h2>
              <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
                Flexible plans to meet your development needs
              </p>
            </div>
            
            <div className="mt-16 grid gap-6 lg:grid-cols-3">
              {pricingTiers.map((tier, index) => (
                <div key={index} className={`rounded-lg shadow-lg divide-y divide-gray-200 ${tier.highlighted ? 'border-2 border-indigo-500 relative' : 'border border-gray-200'}`}>
                  {tier.highlighted && (
                    <div className="absolute top-0 right-0 transform translate-x-1/4 -translate-y-1/2">
                      <span className="inline-flex px-4 py-1 rounded-full text-sm font-semibold tracking-wide uppercase bg-indigo-600 text-white">
                        Most Popular
                      </span>
                    </div>
                  )}
                  <div className="p-6">
                    <h3 className="text-lg font-medium text-gray-900">{tier.name}</h3>
                    <p className="mt-4">
                      <span className="text-3xl font-extrabold text-gray-900">{tier.price}</span>
                      {tier.price !== "Custom" && <span className="text-base font-medium text-gray-500">/month</span>}
                    </p>
                    <p className="mt-4 text-sm text-gray-500">{tier.description}</p>
                  </div>
                  <div className="pt-6 pb-8 px-6">
                    <ul className="space-y-4">
                      {tier.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start">
                          <div className="flex-shrink-0">
                            <svg className="h-5 w-5 text-indigo-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                            </svg>
                          </div>
                          <span className="ml-2 text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="mt-8">
                      <a
                        href="#"
                        className={`block w-full rounded-md px-4 py-2 text-center text-sm font-medium ${
                          tier.highlighted
                            ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                            : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'
                        }`}
                      >
                        {tier.cta}
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Documentation CTA */}
          <div className="mt-20 bg-indigo-700 rounded-lg shadow-xl overflow-hidden">
            <div className="pt-10 pb-12 px-6 sm:pt-16 sm:px-16 lg:py-16 lg:pr-0 xl:py-20 xl:px-20">
              <div className="lg:self-center">
                <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
                  <span className="block">Ready to get started?</span>
                </h2>
                <p className="mt-4 text-lg leading-6 text-indigo-200">
                  Check out our comprehensive API documentation to learn more about all available endpoints, parameters, and response formats.
                </p>
                <a
                  href="#"
                  className="mt-8 bg-white border border-transparent rounded-md shadow px-5 py-3 inline-flex items-center text-base font-medium text-indigo-600 hover:bg-indigo-50"
                >
                  View Full Documentation
                  <ArrowRight className="ml-3 -mr-1 h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}