import { useState, useEffect } from 'react';

/**
 * Custom hook for interacting with localStorage
 */
export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T) => void] {
  // State to store our value
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      // Get from local storage by key
      const item = window.localStorage.getItem(key);
      // Parse stored json or if none return initialValue
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      // If error also return initialValue
      console.error('Error reading from localStorage:', error);
      return initialValue;
    }
  });

  // Return a wrapped version of useState's setter function that persists the new value to localStorage
  const setValue = (value: T) => {
    try {
      // Allow value to be a function
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      
      // Save state
      setStoredValue(valueToStore);
      
      // Save to local storage
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.error('Error writing to localStorage:', error);
    }
  };

  return [storedValue, setValue];
}

/**
 * Save a review configuration to localStorage
 */
export function saveReviewConfig(config: any) {
  try {
    const savedConfigs = JSON.parse(localStorage.getItem('savedReviewConfigs') || '[]');
    
    // Add timestamp for sorting
    const configWithTimestamp = {
      ...config,
      savedAt: new Date().toISOString(),
    };
    
    // Add to beginning of array (most recent first)
    savedConfigs.unshift(configWithTimestamp);
    
    // Keep only the most recent 10 configs
    const trimmedConfigs = savedConfigs.slice(0, 10);
    
    localStorage.setItem('savedReviewConfigs', JSON.stringify(trimmedConfigs));
    return true;
  } catch (error) {
    console.error('Error saving config to localStorage:', error);
    return false;
  }
}

/**
 * Get saved review configurations from localStorage
 */
export function getSavedReviewConfigs() {
  try {
    return JSON.parse(localStorage.getItem('savedReviewConfigs') || '[]');
  } catch (error) {
    console.error('Error reading configs from localStorage:', error);
    return [];
  }
}
