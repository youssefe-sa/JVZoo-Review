/**
 * Type definitions for the application
 */

export interface ProductImage {
  url: string;
  caption: string;
  altText: string;
  position: "header" | "introduction" | "features" | "prosCons" | "pricing" | "caseStudy" | "conclusion" | "galleryOnly";
  size: "small" | "medium" | "large" | "fullWidth";
  alignment: "left" | "center" | "right";
  style: "noBorder" | "standard" | "shadow" | "rounded";
}

export interface FormData {
  apiKey: string;
  model: string;
  productName: string;
  productDescription: string;
  offerLink: string;
  jvDoc: string;
  affiliateLink: string;
  bundleLink: string;
  reviewStyle: string;
  toneStyle: string;
  includePricingTable: boolean;
  includeProsConsSection: boolean;
  includeCtaBanner: boolean;
  includeProductImages: boolean;
  includeFaqSection: boolean;
  
  // Content Structure Elements
  includeIntroduction?: boolean;
  includeCaseStudy?: boolean;
  includeConclusion?: boolean;
  
  // SEO and Keyword Options
  targetKeyword?: string;
  secondaryKeywords?: string;
  includeTableOfContents?: boolean;
  metaDescription?: string;
  focusKeyphrase?: string;
  includeSeoMetaTags?: boolean;
  includeStructuredData?: boolean;
  includeOpenGraph?: boolean;
  includeTwitterCard?: boolean;
  includeCanonicalUrl?: boolean;
  optimizeSlugs?: boolean;
  optimizeImages?: boolean;
  keywordSynonyms?: string;
  includeFaq?: boolean;
  includeHowTo?: boolean;
  longTailKeywords?: string;
  keywordPosition?: string;
  keywordDensity?: number;
  targetSearchIntent?: string;
  targetFeaturedSnippet?: boolean;
  
  // Theme Configuration
  reviewTheme?: string;
  
  // Enhanced Content Elements
  includeComparisonTable?: boolean;
  includeTestimonials?: boolean;
  includeProductRating?: boolean;
  productRatingScore?: string;
  competingProducts?: string;
  includeBonusSection?: boolean;
  bonusContent?: string;
  
  // Product Images
  productImagesList?: ProductImage[];
  
  // Advanced Professional Features (New)
  usePhaseApproach?: boolean;
  useMarketingCopywriting?: boolean;
  extendedWordCount?: boolean;
  includeSeoSchema?: boolean;
}

export interface ReviewResponse {
  success: boolean;
  content: string;
  error?: string;
  seoScore?: number;
  readabilityScore?: number;
  keywordDensity?: Record<string, number>;
}

export interface SavedReview {
  id: string;
  productName: string;
  savedAt: string;
  content: string;
  config: FormData;
}

export interface ReviewTemplate {
  id: string;
  templateName: string;
  templateDescription?: string;
  templateConfig: FormData;
  isPublic: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface SeoAnalysis {
  score: number;
  keywordDensity: Record<string, number>;
  suggestions: string[];
  wordCount: number;
  readabilityScore: number;
  seoChecks?: Array<{
    title: string;
    passed: boolean;
    importance: 'high' | 'medium' | 'low';
  }>;
  readingTimeMinutes?: number;
}

export interface ThemeOption {
  id: string;
  name: string;
  description: string;
  previewImage?: string;
}

export const REVIEW_THEMES: ThemeOption[] = [
  {
    id: 'classic',
    name: 'Classic Review',
    description: 'Traditional review layout with clean typography and balanced sections'
  },
  {
    id: 'modern',
    name: 'Modern Style',
    description: 'Contemporary design with card-based sections and vibrant accents'
  },
  {
    id: 'minimal',
    name: 'Minimalist',
    description: 'Clean and simple design focusing on content with minimal distractions'
  },
  {
    id: 'premium',
    name: 'Premium Review',
    description: 'Luxury-oriented design with elegant typography and sophisticated elements'
  },
  {
    id: 'comparison',
    name: 'Comparison Focused',
    description: 'Emphasizes side-by-side comparisons with competing products'
  }
];
