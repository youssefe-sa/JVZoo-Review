import React, { useEffect, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { Redirect } from 'wouter';
import Layout from '../components/Layout';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { CalendarIcon, CheckIcon, LineChart, Settings, FileText, Star, Award, Gift, ArrowUpCircle } from 'lucide-react';

export default function Dashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const [stats, setStats] = useState({
    reviewsGenerated: 0,
    savedTemplates: 0,
    publishedReviews: 0
  });

  useEffect(() => {
    // In a real app, we would fetch user-specific stats
    // For now, we'll simulate this with random data
    if (isAuthenticated) {
      setStats({
        reviewsGenerated: Math.floor(Math.random() * 10),
        savedTemplates: Math.floor(Math.random() * 5),
        publishedReviews: Math.floor(Math.random() * 3)
      });
    }
  }, [isAuthenticated]);

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-10">
          <div className="flex items-center justify-center h-[60vh]">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  // Determine plan features based on subscription
  const planName = user?.subscriptionPlan?.name || 'Basic';
  const planStatus = user?.subscriptionPlan?.status || 'inactive';
  const planExpiry = user?.subscriptionPlan?.endDate;

  const planFeatures = {
    'Basic': {
      reviewsPerMonth: 5,
      templates: 3,
      supportLevel: 'Email',
      advancedFeatures: false,
      seoAnalysis: false,
      aiAssistant: false,
      multiPlatformPublishing: false,
      customBranding: false
    },
    'Pro': {
      reviewsPerMonth: 20,
      templates: 10,
      supportLevel: 'Priority Email',
      advancedFeatures: true,
      seoAnalysis: true,
      aiAssistant: false,
      multiPlatformPublishing: true,
      customBranding: false
    },
    'Agency': {
      reviewsPerMonth: 100,
      templates: 'Unlimited',
      supportLevel: '24/7 Support',
      advancedFeatures: true,
      seoAnalysis: true,
      aiAssistant: true,
      multiPlatformPublishing: true,
      customBranding: true
    }
  };

  const currentPlanFeatures = planFeatures[planName as keyof typeof planFeatures] || planFeatures.Basic;

  return (
    <Layout>
      <div className="container mx-auto py-8">
        <div className="flex flex-col sm:flex-row justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-bold">Welcome, {user?.username}</h1>
            <p className="text-muted-foreground mt-1">Your dashboard and content overview</p>
          </div>
          <div className="mt-4 sm:mt-0">
            <Button variant="outline" className="mr-2">
              <Settings className="h-4 w-4 mr-2" />
              Account Settings
            </Button>
            <Button>
              <FileText className="h-4 w-4 mr-2" />
              New Review
            </Button>
          </div>
        </div>

        {/* Subscription Info */}
        <Card className="mb-8">
          <CardHeader className="bg-muted/50">
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Your Subscription</CardTitle>
                <CardDescription>Current plan and status</CardDescription>
              </div>
              <Badge variant={planStatus === 'active' ? 'default' : 'secondary'}>
                {planStatus === 'active' ? 'Active' : 'Inactive'}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h3 className="text-lg font-semibold flex items-center">
                  <Star className="h-5 w-5 mr-2 text-yellow-500" />
                  {planName} Plan
                  {planStatus === 'trial' && (
                    <Badge className="ml-2 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700">
                      Free Trial
                    </Badge>
                  )}
                </h3>
                {user?.trialEndsAt && planStatus === 'trial' ? (
                  <p className="text-sm text-muted-foreground flex items-center mt-1">
                    <CalendarIcon className="h-4 w-4 mr-1" />
                    Trial ends on {new Date(user.trialEndsAt).toLocaleDateString()}
                  </p>
                ) : planExpiry && (
                  <p className="text-sm text-muted-foreground flex items-center mt-1">
                    <CalendarIcon className="h-4 w-4 mr-1" />
                    Expires on {planExpiry.toLocaleDateString()}
                  </p>
                )}
              </div>
              <div>
                <h3 className="text-sm font-medium">Plan Limits</h3>
                <ul className="mt-2 space-y-1">
                  <li className="text-sm flex items-center">
                    <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                    {currentPlanFeatures.reviewsPerMonth} reviews/month
                  </li>
                  <li className="text-sm flex items-center">
                    <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                    {currentPlanFeatures.templates} templates
                  </li>
                  <li className="text-sm flex items-center">
                    <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                    {currentPlanFeatures.supportLevel} support
                  </li>
                </ul>
              </div>
              <div className="flex justify-end items-center">
                {planStatus !== 'active' ? (
                  <Button>Activate Plan</Button>
                ) : (
                  <Button variant="outline">Upgrade Plan</Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Reviews Generated</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.reviewsGenerated}</div>
              <p className="text-xs text-muted-foreground mt-1">
                out of {currentPlanFeatures.reviewsPerMonth} this month
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Saved Templates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.savedTemplates}</div>
              <p className="text-xs text-muted-foreground mt-1">
                out of {currentPlanFeatures.templates === 'Unlimited' ? '∞' : currentPlanFeatures.templates} allowed
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Published Reviews</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.publishedReviews}</div>
              <p className="text-xs text-muted-foreground mt-1">
                across all platforms
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="features">
          <TabsList className="mb-4">
            <TabsTrigger value="features">Plan Features</TabsTrigger>
            <TabsTrigger value="activity">Recent Activity</TabsTrigger>
            <TabsTrigger value="templates">Your Templates</TabsTrigger>
          </TabsList>
          
          <TabsContent value="features">
            <Card>
              <CardHeader>
                <CardTitle>Available Features</CardTitle>
                <CardDescription>
                  Features included in your {planName} plan
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h3 className="font-medium">Core Features</h3>
                    <ul className="space-y-1">
                      <li className="text-sm flex items-center">
                        <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                        Product review generation
                      </li>
                      <li className="text-sm flex items-center">
                        <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                        Basic templates
                      </li>
                      <li className="text-sm flex items-center">
                        <CheckIcon className="h-4 w-4 mr-2 text-green-500" />
                        HTML export
                      </li>
                    </ul>

                    <h3 className="font-medium mt-4">Advanced Features</h3>
                    <ul className="space-y-1">
                      <li className="text-sm flex items-center">
                        <CheckIcon className={`h-4 w-4 mr-2 ${currentPlanFeatures.advancedFeatures ? 'text-green-500' : 'text-gray-300'}`} />
                        <span className={!currentPlanFeatures.advancedFeatures ? 'text-muted-foreground' : ''}>
                          Comparison tables
                          {!currentPlanFeatures.advancedFeatures && ' (Pro+)'}
                        </span>
                      </li>
                      <li className="text-sm flex items-center">
                        <CheckIcon className={`h-4 w-4 mr-2 ${currentPlanFeatures.advancedFeatures ? 'text-green-500' : 'text-gray-300'}`} />
                        <span className={!currentPlanFeatures.advancedFeatures ? 'text-muted-foreground' : ''}>
                          Testimonial generation
                          {!currentPlanFeatures.advancedFeatures && ' (Pro+)'}
                        </span>
                      </li>
                      <li className="text-sm flex items-center">
                        <CheckIcon className={`h-4 w-4 mr-2 ${currentPlanFeatures.advancedFeatures ? 'text-green-500' : 'text-gray-300'}`} />
                        <span className={!currentPlanFeatures.advancedFeatures ? 'text-muted-foreground' : ''}>
                          Bonus section management
                          {!currentPlanFeatures.advancedFeatures && ' (Pro+)'}
                        </span>
                      </li>
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-medium">SEO & Analytics</h3>
                    <ul className="space-y-1">
                      <li className="text-sm flex items-center">
                        <CheckIcon className={`h-4 w-4 mr-2 ${currentPlanFeatures.seoAnalysis ? 'text-green-500' : 'text-gray-300'}`} />
                        <span className={!currentPlanFeatures.seoAnalysis ? 'text-muted-foreground' : ''}>
                          SEO keyword optimization
                          {!currentPlanFeatures.seoAnalysis && ' (Pro+)'}
                        </span>
                      </li>
                      <li className="text-sm flex items-center">
                        <CheckIcon className={`h-4 w-4 mr-2 ${currentPlanFeatures.seoAnalysis ? 'text-green-500' : 'text-gray-300'}`} />
                        <span className={!currentPlanFeatures.seoAnalysis ? 'text-muted-foreground' : ''}>
                          Readability analysis
                          {!currentPlanFeatures.seoAnalysis && ' (Pro+)'}
                        </span>
                      </li>
                    </ul>

                    <h3 className="font-medium mt-4">Premium Features</h3>
                    <ul className="space-y-1">
                      <li className="text-sm flex items-center">
                        <CheckIcon className={`h-4 w-4 mr-2 ${currentPlanFeatures.aiAssistant ? 'text-green-500' : 'text-gray-300'}`} />
                        <span className={!currentPlanFeatures.aiAssistant ? 'text-muted-foreground' : ''}>
                          AI content assistant
                          {!currentPlanFeatures.aiAssistant && ' (Agency)'}
                        </span>
                      </li>
                      <li className="text-sm flex items-center">
                        <CheckIcon className={`h-4 w-4 mr-2 ${currentPlanFeatures.multiPlatformPublishing ? 'text-green-500' : 'text-gray-300'}`} />
                        <span className={!currentPlanFeatures.multiPlatformPublishing ? 'text-muted-foreground' : ''}>
                          Multi-platform publishing
                          {!currentPlanFeatures.multiPlatformPublishing && ' (Pro+)'}
                        </span>
                      </li>
                      <li className="text-sm flex items-center">
                        <CheckIcon className={`h-4 w-4 mr-2 ${currentPlanFeatures.customBranding ? 'text-green-500' : 'text-gray-300'}`} />
                        <span className={!currentPlanFeatures.customBranding ? 'text-muted-foreground' : ''}>
                          Custom branding
                          {!currentPlanFeatures.customBranding && ' (Agency)'}
                        </span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-muted/30 flex justify-between">
                <span className="text-sm text-muted-foreground">
                  Not seeing what you need? Consider upgrading your plan.
                </span>
                <Button variant="outline" size="sm">
                  <ArrowUpCircle className="h-4 w-4 mr-2" />
                  Upgrade
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="activity">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>
                  Your latest actions and content
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-5">
                  {stats.reviewsGenerated > 0 ? (
                    [...Array(Math.min(stats.reviewsGenerated, 3))].map((_, i) => (
                      <div key={i} className="flex items-start space-x-4">
                        <div className="bg-primary/10 rounded-full p-2">
                          <FileText className="h-4 w-4 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">Amazon Echo Review</p>
                          <p className="text-xs text-muted-foreground">
                            Generated review for "Amazon Echo" (Smart Speaker)
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {Math.floor(Math.random() * 24) + 1} hours ago
                          </p>
                        </div>
                        <Button variant="ghost" size="sm">View</Button>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">No recent activity yet</p>
                      <Button variant="outline" className="mt-4">
                        <FileText className="h-4 w-4 mr-2" />
                        Create Your First Review
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="templates">
            <Card>
              <CardHeader>
                <CardTitle>Your Templates</CardTitle>
                <CardDescription>
                  Save and reuse your favorite review templates
                </CardDescription>
              </CardHeader>
              <CardContent>
                {stats.savedTemplates > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[...Array(stats.savedTemplates)].map((_, i) => (
                      <Card key={i} className="overflow-hidden">
                        <div className="bg-primary/10 h-3"></div>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-base">Template {i + 1}</CardTitle>
                          <CardDescription className="text-xs">
                            Created {Math.floor(Math.random() * 30) + 1} days ago
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <p className="text-sm text-muted-foreground truncate">
                            A comprehensive review template with product comparison...
                          </p>
                        </CardContent>
                        <CardFooter className="justify-between bg-muted/30 pt-2 pb-2">
                          <span className="text-xs text-muted-foreground">
                            Used {Math.floor(Math.random() * 5) + 1} times
                          </span>
                          <Button variant="ghost" size="sm">Use</Button>
                        </CardFooter>
                      </Card>
                    ))}
                    
                    {currentPlanFeatures.templates !== 'Unlimited' && 
                      stats.savedTemplates < (currentPlanFeatures.templates as number) && (
                      <div className="border-2 border-dashed rounded-lg flex items-center justify-center h-[190px]">
                        <Button variant="outline">
                          Create New Template
                        </Button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No templates saved yet</p>
                    <Button variant="outline" className="mt-4">
                      Create Your First Template
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}