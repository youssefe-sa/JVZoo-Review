import React from 'react';
import { Helmet } from "react-helmet";
import Layout from "@/components/Layout";
import { Calendar, CheckCircle, CircleDashed, Clock } from "lucide-react";

export default function Roadmap() {
  // Roadmap items categorized by status
  const roadmapItems = {
    launched: [
      {
        title: "AI-Powered Review Generation",
        description: "Generate complete product reviews using our advanced AI models trained on high-converting content.",
        date: "Q1 2023",
        icon: <CheckCircle className="h-6 w-6 text-green-500" />,
        isNew: false
      },
      {
        title: "Template Library Launch",
        description: "Access 20+ customizable review templates optimized for different product categories and audiences.",
        date: "Q1 2023",
        icon: <CheckCircle className="h-6 w-6 text-green-500" />,
        isNew: false
      },
      {
        title: "SEO Optimization Tools",
        description: "Analyze and optimize reviews for search engines with keyword suggestions, readability scores, and more.",
        date: "Q2 2023",
        icon: <CheckCircle className="h-6 w-6 text-green-500" />,
        isNew: false
      },
      {
        title: "WordPress Integration",
        description: "Publish reviews directly to WordPress sites with full formatting and SEO metadata preservation.",
        date: "Q2 2023",
        icon: <CheckCircle className="h-6 w-6 text-green-500" />,
        isNew: true
      },
      {
        title: "Comparison Table Generator",
        description: "Create visually appealing product comparison tables that boost conversion rates.",
        date: "Q3 2023",
        icon: <CheckCircle className="h-6 w-6 text-green-500" />,
        isNew: true
      }
    ],
    inProgress: [
      {
        title: "Enhanced Analytics Dashboard",
        description: "Track review performance with detailed analytics on traffic, conversion rates, and engagement metrics.",
        date: "Q4 2023",
        icon: <Clock className="h-6 w-6 text-indigo-500" />,
        progress: 70
      },
      {
        title: "Multi-Platform Publishing",
        description: "Publish to additional platforms including Shopify, Medium, and Wix with optimized formatting for each.",
        date: "Q4 2023",
        icon: <Clock className="h-6 w-6 text-indigo-500" />,
        progress: 55
      },
      {
        title: "AI Image Generator Integration",
        description: "Generate product-specific images and graphics using AI to enhance your reviews visually.",
        date: "Q4 2023",
        icon: <Clock className="h-6 w-6 text-indigo-500" />,
        progress: 40
      }
    ],
    planned: [
      {
        title: "Team Collaboration Features",
        description: "Enable team workflows with collaborative editing, approval processes, and role-based permissions.",
        date: "Q1 2024",
        icon: <CircleDashed className="h-6 w-6 text-gray-400" />
      },
      {
        title: "Custom AI Training",
        description: "Train our AI on your existing content to match your brand voice and style more precisely.",
        date: "Q1 2024",
        icon: <CircleDashed className="h-6 w-6 text-gray-400" />
      },
      {
        title: "Video Review Generation",
        description: "Create video script outlines and talking points based on your written review content.",
        date: "Q2 2024",
        icon: <CircleDashed className="h-6 w-6 text-gray-400" />
      },
      {
        title: "Amazon Integration",
        description: "Pull product data directly from Amazon and optimize reviews for Amazon affiliate partners.",
        date: "Q2 2024",
        icon: <CircleDashed className="h-6 w-6 text-gray-400" />
      },
      {
        title: "Mobile App Launch",
        description: "Access ReviewPro on-the-go with our iOS and Android mobile applications.",
        date: "Q3 2024",
        icon: <CircleDashed className="h-6 w-6 text-gray-400" />
      }
    ]
  };

  return (
    <Layout variant="landing">
      <Helmet>
        <title>Product Roadmap | ReviewPro</title>
        <meta name="description" content="Explore ReviewPro's product roadmap to see recently launched features, what we're currently working on, and what's coming in the future." />
      </Helmet>
      
      <div className="bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Roadmap Header */}
          <div className="text-center">
            <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl lg:text-5xl">Product Roadmap</h1>
            <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
              See what we've built, what we're building, and what's coming next
            </p>
          </div>
          
          {/* Recently Launched Section */}
          <div className="mt-20">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-100 text-green-600">
                  <CheckCircle className="h-6 w-6" />
                </div>
              </div>
              <div className="ml-4">
                <h2 className="text-2xl font-bold text-gray-900">Recently Launched</h2>
                <p className="text-gray-500">Features we've shipped in the last two quarters</p>
              </div>
            </div>
            
            <div className="mt-10 space-y-8">
              {roadmapItems.launched.map((item, index) => (
                <div key={index} className="bg-white rounded-lg shadow-md border border-gray-100 p-6">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      {item.icon}
                    </div>
                    <div className="ml-4">
                      <div className="flex items-center">
                        <h3 className="text-xl font-semibold text-gray-900">{item.title}</h3>
                        {item.isNew && (
                          <span className="ml-3 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            NEW
                          </span>
                        )}
                      </div>
                      <p className="mt-2 text-gray-600">{item.description}</p>
                      <div className="mt-2 flex items-center text-sm text-gray-500">
                        <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        Launched: {item.date}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* In Progress Section */}
          <div className="mt-20">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-100 text-indigo-600">
                  <Clock className="h-6 w-6" />
                </div>
              </div>
              <div className="ml-4">
                <h2 className="text-2xl font-bold text-gray-900">In Progress</h2>
                <p className="text-gray-500">Features we're actively working on right now</p>
              </div>
            </div>
            
            <div className="mt-10 space-y-8">
              {roadmapItems.inProgress.map((item, index) => (
                <div key={index} className="bg-white rounded-lg shadow-md border border-gray-100 p-6">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      {item.icon}
                    </div>
                    <div className="ml-4 flex-1">
                      <h3 className="text-xl font-semibold text-gray-900">{item.title}</h3>
                      <p className="mt-2 text-gray-600">{item.description}</p>
                      <div className="mt-4">
                        <div className="flex items-center">
                          <span className="text-sm font-medium text-indigo-600">
                            {item.progress}% complete
                          </span>
                          <div className="ml-4 flex-1">
                            <div className="bg-gray-200 rounded-full h-2.5 w-full">
                              <div 
                                className="bg-indigo-600 h-2.5 rounded-full"
                                style={{ width: `${item.progress}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="mt-2 flex items-center text-sm text-gray-500">
                        <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        Target: {item.date}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Planned Section */}
          <div className="mt-20">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-gray-100 text-gray-600">
                  <CircleDashed className="h-6 w-6" />
                </div>
              </div>
              <div className="ml-4">
                <h2 className="text-2xl font-bold text-gray-900">Planned</h2>
                <p className="text-gray-500">Features on our radar for future development</p>
              </div>
            </div>
            
            <div className="mt-10 space-y-8">
              {roadmapItems.planned.map((item, index) => (
                <div key={index} className="bg-white rounded-lg shadow-md border border-gray-100 p-6">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      {item.icon}
                    </div>
                    <div className="ml-4">
                      <h3 className="text-xl font-semibold text-gray-900">{item.title}</h3>
                      <p className="mt-2 text-gray-600">{item.description}</p>
                      <div className="mt-2 flex items-center text-sm text-gray-500">
                        <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                        Planned: {item.date}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Feature Request CTA */}
          <div className="mt-20 bg-indigo-50 rounded-lg py-12 px-6 sm:py-16 sm:px-12 lg:flex lg:items-center lg:p-16">
            <div className="lg:w-0 lg:flex-1">
              <h2 className="text-3xl font-extrabold tracking-tight text-gray-900">
                Have a feature idea?
              </h2>
              <p className="mt-4 max-w-3xl text-lg text-gray-500">
                We love hearing from our users. Let us know what features would help you create better product reviews.
              </p>
            </div>
            <div className="mt-12 sm:w-full sm:max-w-md lg:mt-0 lg:ml-8 lg:flex-1">
              <a
                href="/support/contact"
                className="w-full flex items-center justify-center px-6 py-4 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 md:text-lg"
              >
                Submit Feature Request
              </a>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}