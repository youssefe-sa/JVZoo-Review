import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Tooltip } from "@/components/ui/tooltip";
import { TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  ChevronDown, 
  ChevronUp, 
  Search, 
  LightbulbIcon, 
  Globe, 
  BookOpen, 
  Hash, 
  Link2, 
  BarChart2, 
  Share, 
  Star,
  Zap,
  FileJson 
} from "lucide-react";

interface SeoOptionsPanelProps {
  targetKeyword: string;
  secondaryKeywords: string;
  includeTableOfContents: boolean;
  updateFormData: (data: Partial<{
    targetKeyword: string;
    secondaryKeywords: string;
    includeTableOfContents: boolean;
    metaDescription?: string;
    focusKeyphrase?: string;
    includeSeoMetaTags?: boolean;
    includeStructuredData?: boolean;
    includeOpenGraph?: boolean;
    includeTwitterCard?: boolean;
    includeCanonicalUrl?: boolean;
    optimizeSlugs?: boolean;
    optimizeImages?: boolean;
    keywordSynonyms?: string;
    includeFaq?: boolean;
    includeHowTo?: boolean;
    longTailKeywords?: string;
    keywordPosition?: string;
    keywordDensity?: number;
    targetSearchIntent?: string;
    targetFeaturedSnippet?: boolean;
  }>) => void;
  metaDescription?: string;
  focusKeyphrase?: string;
  includeSeoMetaTags?: boolean;
  includeStructuredData?: boolean;
  includeOpenGraph?: boolean;
  includeTwitterCard?: boolean;
  includeCanonicalUrl?: boolean;
  optimizeSlugs?: boolean;
  optimizeImages?: boolean;
  keywordSynonyms?: string;
  includeFaq?: boolean;
  includeHowTo?: boolean;
  longTailKeywords?: string;
  keywordPosition?: string;
  keywordDensity?: number;
  targetSearchIntent?: string;
  targetFeaturedSnippet?: boolean;
}

export default function SeoOptionsPanel({
  targetKeyword,
  secondaryKeywords,
  includeTableOfContents,
  updateFormData,
  metaDescription = "",
  focusKeyphrase = "",
  includeSeoMetaTags = true,
  includeStructuredData = true,
  includeOpenGraph = true,
  includeTwitterCard = true,
  includeCanonicalUrl = true,
  optimizeSlugs = true,
  optimizeImages = true,
  keywordSynonyms = "",
  includeFaq = false,
  includeHowTo = false,
  longTailKeywords = "",
  keywordPosition = "balanced",
  keywordDensity = 1.5,
  targetSearchIntent = "informational",
  targetFeaturedSnippet = true
}: SeoOptionsPanelProps) {
  const [expanded, setExpanded] = useState(false);
  const [contentHeight, setContentHeight] = useState(0);
  const contentRef = useRef<HTMLDivElement>(null);
  const [activeTab, setActiveTab] = useState("keyword-strategy");
  
  // Calculate SEO Score based on filled options
  const calculateSeoScore = () => {
    let score = 0;
    const total = 15; // Total number of factors we're checking
    
    if (targetKeyword) score++;
    if (secondaryKeywords) score++;
    if (includeTableOfContents) score++;
    if (metaDescription) score++;
    if (metaDescription && metaDescription.length > 120 && metaDescription.length < 160) score++;
    if (focusKeyphrase) score++;
    if (includeSeoMetaTags) score++;
    if (includeStructuredData) score++;
    if (includeOpenGraph) score++;
    if (includeTwitterCard) score++;
    if (includeCanonicalUrl) score++;
    if (optimizeSlugs) score++;
    if (optimizeImages) score++;
    if (keywordSynonyms) score++;
    if (targetFeaturedSnippet) score++;
    
    return Math.round((score / total) * 100);
  };
  
  const seoScore = calculateSeoScore();
  
  // Get SEO score color based on value
  const getSeoScoreColor = (score: number) => {
    if (score >= 80) return "bg-green-500";
    if (score >= 60) return "bg-yellow-500";
    return "bg-red-500";
  };
  
  // Update content height whenever expanded state changes
  useEffect(() => {
    // Using a timeout to ensure the DOM has updated
    const timer = setTimeout(() => {
      if (contentRef.current) {
        setContentHeight(contentRef.current.scrollHeight);
      }
    }, 10);
    
    return () => clearTimeout(timer);
  }, [expanded, targetKeyword, secondaryKeywords, activeTab]);
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div 
        className="p-6 border-b border-gray-100 flex justify-between items-center cursor-pointer hover:bg-gray-50 transition-colors duration-200"
        onClick={() => setExpanded(!expanded)}
        aria-expanded={expanded}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            setExpanded(!expanded);
            e.preventDefault();
          }
        }}
      >
        <div className="flex items-center flex-grow">
          <svg className="h-5 w-5 text-indigo-600 mr-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
          <h2 className="text-lg font-semibold text-gray-800 whitespace-nowrap mr-3">SEO Optimization</h2>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-xs text-indigo-600 font-medium whitespace-nowrap mr-1">
            {expanded ? 'Hide Options' : 'Show Options'}
          </span>
          <button 
            className="p-1 rounded-full hover:bg-indigo-100 transition-all text-indigo-600 flex items-center justify-center"
            aria-label={expanded ? "Collapse panel" : "Expand panel"}
            onClick={(e) => {
              e.stopPropagation();
              setExpanded(!expanded);
            }}
          >
            {expanded ? 
              <ChevronUp className="h-5 w-5" /> : 
              <ChevronDown className="h-5 w-5" />
            }
          </button>
        </div>
      </div>
      
      <div 
        ref={contentRef}
        style={{ 
          maxHeight: expanded ? `${contentHeight}px` : '0',
          opacity: expanded ? 1 : 0
        }}
        className="transition-all duration-300 ease-in-out overflow-hidden"
      >
        <div className="p-4 border-t border-gray-100 bg-gray-50">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center">
              <div className="relative mr-3">
                <div className={`w-14 h-14 rounded-full flex items-center justify-center ${getSeoScoreColor(seoScore)} text-white text-base font-medium shadow-sm`}>
                  {seoScore}%
                </div>
                <div className="absolute -top-1 -right-1 w-5 h-5 bg-white rounded-full flex items-center justify-center shadow-sm">
                  {seoScore >= 80 ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-green-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-yellow-500" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  )}
                </div>
              </div>
              <div>
                <h3 className="text-sm font-medium">SEO Score</h3>
                <p className="text-xs text-gray-500">
                  {seoScore >= 80 
                    ? "Excellent! Your review is well-optimized" 
                    : seoScore >= 60 
                      ? "Good. Some optimizations recommended" 
                      : "Needs improvement for better ranking"}
                </p>
              </div>
            </div>
            
            <div>
              <Badge variant="outline" className="bg-white border-indigo-200 text-indigo-700 px-3 py-1.5 text-xs rounded-full whitespace-nowrap">
                Professional SEO
              </Badge>
            </div>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 mb-4 bg-gray-100 p-1 rounded-lg">
              <TabsTrigger value="keyword-strategy" className="text-xs py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm transition-all duration-200">
                <Hash className="h-3.5 w-3.5 mr-1.5" />
                Keyword Strategy
              </TabsTrigger>
              <TabsTrigger value="technical-seo" className="text-xs py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm transition-all duration-200">
                <Globe className="h-3.5 w-3.5 mr-1.5" />
                Technical SEO
              </TabsTrigger>
              <TabsTrigger value="content-optimization" className="text-xs py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm transition-all duration-200">
                <BookOpen className="h-3.5 w-3.5 mr-1.5" />
                Content Optimization
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="keyword-strategy" className="space-y-4 mt-0">
              <div>
                <div className="flex items-center mb-1">
                  <label htmlFor="targetKeyword" className="block text-sm font-medium text-gray-700">
                    Primary Target Keyword
                  </label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          The main keyword you want to rank for. It will be used in headings, title, and throughout the review
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <input
                  type="text"
                  id="targetKeyword"
                  value={targetKeyword}
                  onChange={(e) => updateFormData({ targetKeyword: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                  placeholder="e.g., JVZoo product review"
                />
              </div>
              
              <div>
                <div className="flex items-center mb-1">
                  <label htmlFor="focusKeyphrase" className="block text-sm font-medium text-gray-700">
                    Focus Keyphrase (For Title & H1)
                  </label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          The exact phrase to use in page title and H1 heading
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <input
                  type="text"
                  id="focusKeyphrase"
                  value={focusKeyphrase}
                  onChange={(e) => updateFormData({ focusKeyphrase: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                  placeholder="e.g., Best [Product Name] Review 2025"
                />
              </div>
              
              <div>
                <div className="flex items-center mb-1">
                  <label htmlFor="secondaryKeywords" className="block text-sm font-medium text-gray-700">
                    Secondary Keywords
                  </label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          Additional keywords to include throughout the review. Separate with commas.
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <input
                  type="text"
                  id="secondaryKeywords"
                  value={secondaryKeywords}
                  onChange={(e) => updateFormData({ secondaryKeywords: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                  placeholder="e.g., best price, discount, bonuses, alternatives"
                />
                <p className="text-xs text-gray-500 mt-1">Separate multiple keywords with commas</p>
              </div>
              
              <div>
                <div className="flex items-center mb-1">
                  <label htmlFor="keywordSynonyms" className="block text-sm font-medium text-gray-700">
                    LSI Keywords & Synonyms
                  </label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          Semantically related terms that help Google understand your content's context
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <input
                  type="text"
                  id="keywordSynonyms"
                  value={keywordSynonyms}
                  onChange={(e) => updateFormData({ keywordSynonyms: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                  placeholder="e.g., evaluation, assessment, analysis, critique"
                />
              </div>
              
              <div>
                <div className="flex items-center mb-1">
                  <label htmlFor="longTailKeywords" className="block text-sm font-medium text-gray-700">
                    Long-tail Keywords
                  </label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          Longer, more specific keyword phrases that visitors are more likely to use when closer to point-of-purchase
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <input
                  type="text"
                  id="longTailKeywords"
                  value={longTailKeywords}
                  onChange={(e) => updateFormData({ longTailKeywords: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                  placeholder="e.g., is [product] worth the money, [product] honest review 2025"
                />
              </div>
              
              <div>
                <div className="flex items-center mb-1">
                  <label htmlFor="keywordPosition" className="block text-sm font-medium text-gray-700">
                    Keyword Positioning Strategy
                  </label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          How to distribute keywords throughout the content
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <select
                  id="keywordPosition"
                  value={keywordPosition}
                  onChange={(e) => updateFormData({ keywordPosition: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                >
                  <option value="balanced">Balanced (Even distribution)</option>
                  <option value="top-heavy">Top-heavy (More in beginning)</option>
                  <option value="section-focused">Section-focused (Each section optimized)</option>
                  <option value="strategic">Strategic placement in key areas only</option>
                </select>
              </div>
              
              <div>
                <div className="flex items-center mb-1">
                  <label htmlFor="keywordDensity" className="block text-sm font-medium text-gray-700">
                    Target Keyword Density (%)
                  </label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          The percentage of times a keyword appears in the text compared to the total word count
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <input
                  type="range"
                  id="keywordDensity"
                  min="0.5"
                  max="3"
                  step="0.1"
                  value={keywordDensity}
                  onChange={(e) => updateFormData({ keywordDensity: parseFloat(e.target.value) })}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-gray-500">0.5%</span>
                  <span className="text-xs font-medium text-indigo-600">{keywordDensity}%</span>
                  <span className="text-xs text-gray-500">3.0%</span>
                </div>
              </div>
              
              <div>
                <div className="flex items-center mb-1">
                  <label htmlFor="targetSearchIntent" className="block text-sm font-medium text-gray-700">
                    Target Search Intent
                  </label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          The purpose behind a searcher's query that your content should address
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <select
                  id="targetSearchIntent"
                  value={targetSearchIntent}
                  onChange={(e) => updateFormData({ targetSearchIntent: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                >
                  <option value="informational">Informational (Learn about product)</option>
                  <option value="commercial">Commercial (Compare options)</option>
                  <option value="transactional">Transactional (Ready to buy)</option>
                  <option value="navigational">Navigational (Find specific brand/product)</option>
                </select>
              </div>
            </TabsContent>
            
            <TabsContent value="technical-seo" className="space-y-4 mt-0">
              <div>
                <div className="flex items-center mb-1">
                  <label htmlFor="metaDescription" className="block text-sm font-medium text-gray-700">
                    Meta Description
                  </label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          A brief summary that appears in search results. Should be 120-160 characters.
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <textarea
                  id="metaDescription"
                  value={metaDescription}
                  onChange={(e) => updateFormData({ metaDescription: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                  placeholder="Enter a compelling meta description that includes your target keyword"
                  rows={3}
                ></textarea>
                <div className="flex justify-between mt-1">
                  <p className="text-xs text-gray-500">
                    {metaDescription.length} / 160 characters
                  </p>
                  {metaDescription.length > 0 && (
                    <p className={`text-xs ${
                      metaDescription.length > 120 && metaDescription.length < 160 
                        ? "text-green-600" 
                        : "text-yellow-600"
                    }`}>
                      {metaDescription.length > 120 && metaDescription.length < 160 
                        ? "Optimal length ✓" 
                        : metaDescription.length < 120 
                          ? "Too short" 
                          : "Too long"}
                    </p>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <span className="text-sm text-gray-700">Include Meta Tags</span>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="ml-1 text-gray-400 hover:text-gray-600">
                            <i className="ri-question-line"></i>
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="text-xs max-w-xs">
                            Creates basic SEO meta tags like title, description, and keywords
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <div className="relative inline-block w-10 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      id="includeSeoMetaTags" 
                      className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                      checked={includeSeoMetaTags}
                      onChange={(e) => updateFormData({ includeSeoMetaTags: e.target.checked })}
                      style={{ 
                        right: includeSeoMetaTags ? '0' : 'auto',
                        borderColor: includeSeoMetaTags ? '#4F46E5' : 'transparent'
                      }}
                    />
                    <label 
                      htmlFor="includeSeoMetaTags" 
                      className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                      style={{ backgroundColor: includeSeoMetaTags ? '#4F46E5' : '#D1D5DB' }}
                    ></label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <span className="text-sm text-gray-700">Structured Data</span>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="ml-1 text-gray-400 hover:text-gray-600">
                            <i className="ri-question-line"></i>
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="text-xs max-w-xs">
                            Add JSON-LD schema markup for rich snippets in search results
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <div className="relative inline-block w-10 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      id="includeStructuredData" 
                      className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                      checked={includeStructuredData}
                      onChange={(e) => updateFormData({ includeStructuredData: e.target.checked })}
                      style={{ 
                        right: includeStructuredData ? '0' : 'auto',
                        borderColor: includeStructuredData ? '#4F46E5' : 'transparent'
                      }}
                    />
                    <label 
                      htmlFor="includeStructuredData" 
                      className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                      style={{ backgroundColor: includeStructuredData ? '#4F46E5' : '#D1D5DB' }}
                    ></label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <span className="text-sm text-gray-700">Open Graph Tags</span>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="ml-1 text-gray-400 hover:text-gray-600">
                            <i className="ri-question-line"></i>
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="text-xs max-w-xs">
                            Meta tags for better sharing on Facebook and other social platforms
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <div className="relative inline-block w-10 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      id="includeOpenGraph" 
                      className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                      checked={includeOpenGraph}
                      onChange={(e) => updateFormData({ includeOpenGraph: e.target.checked })}
                      style={{ 
                        right: includeOpenGraph ? '0' : 'auto',
                        borderColor: includeOpenGraph ? '#4F46E5' : 'transparent'
                      }}
                    />
                    <label 
                      htmlFor="includeOpenGraph" 
                      className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                      style={{ backgroundColor: includeOpenGraph ? '#4F46E5' : '#D1D5DB' }}
                    ></label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <span className="text-sm text-gray-700">Twitter Card</span>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="ml-1 text-gray-400 hover:text-gray-600">
                            <i className="ri-question-line"></i>
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="text-xs max-w-xs">
                            Meta tags for better sharing on Twitter with rich media
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <div className="relative inline-block w-10 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      id="includeTwitterCard" 
                      className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                      checked={includeTwitterCard}
                      onChange={(e) => updateFormData({ includeTwitterCard: e.target.checked })}
                      style={{ 
                        right: includeTwitterCard ? '0' : 'auto',
                        borderColor: includeTwitterCard ? '#4F46E5' : 'transparent'
                      }}
                    />
                    <label 
                      htmlFor="includeTwitterCard" 
                      className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                      style={{ backgroundColor: includeTwitterCard ? '#4F46E5' : '#D1D5DB' }}
                    ></label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <span className="text-sm text-gray-700">Canonical URL</span>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="ml-1 text-gray-400 hover:text-gray-600">
                            <i className="ri-question-line"></i>
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="text-xs max-w-xs">
                            Helps prevent duplicate content issues by specifying the preferred URL
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <div className="relative inline-block w-10 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      id="includeCanonicalUrl" 
                      className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                      checked={includeCanonicalUrl}
                      onChange={(e) => updateFormData({ includeCanonicalUrl: e.target.checked })}
                      style={{ 
                        right: includeCanonicalUrl ? '0' : 'auto',
                        borderColor: includeCanonicalUrl ? '#4F46E5' : 'transparent'
                      }}
                    />
                    <label 
                      htmlFor="includeCanonicalUrl" 
                      className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                      style={{ backgroundColor: includeCanonicalUrl ? '#4F46E5' : '#D1D5DB' }}
                    ></label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <span className="text-sm text-gray-700">Optimize URL Slug</span>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button className="ml-1 text-gray-400 hover:text-gray-600">
                            <i className="ri-question-line"></i>
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="text-xs max-w-xs">
                            Creates a search-friendly URL structure including target keywords
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <div className="relative inline-block w-10 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      id="optimizeSlugs" 
                      className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                      checked={optimizeSlugs}
                      onChange={(e) => updateFormData({ optimizeSlugs: e.target.checked })}
                      style={{ 
                        right: optimizeSlugs ? '0' : 'auto',
                        borderColor: optimizeSlugs ? '#4F46E5' : 'transparent'
                      }}
                    />
                    <label 
                      htmlFor="optimizeSlugs" 
                      className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                      style={{ backgroundColor: optimizeSlugs ? '#4F46E5' : '#D1D5DB' }}
                    ></label>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="content-optimization" className="space-y-4 mt-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <span className="text-sm text-gray-700">Table of Contents</span>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          A table of contents helps with SEO and improves user experience by making the content more navigable
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="relative inline-block w-10 mr-2 align-middle select-none">
                  <input 
                    type="checkbox" 
                    name="includeTableOfContents" 
                    id="includeTableOfContents" 
                    className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                    checked={includeTableOfContents}
                    onChange={(e) => updateFormData({ includeTableOfContents: e.target.checked })}
                    style={{ 
                      right: includeTableOfContents ? '0' : 'auto',
                      borderColor: includeTableOfContents ? '#4F46E5' : 'transparent'
                    }}
                  />
                  <label 
                    htmlFor="includeTableOfContents" 
                    className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                    style={{ backgroundColor: includeTableOfContents ? '#4F46E5' : '#D1D5DB' }}
                  ></label>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <span className="text-sm text-gray-700">Image Optimization</span>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          Add SEO-friendly alt text and descriptions to all images
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="relative inline-block w-10 mr-2 align-middle select-none">
                  <input 
                    type="checkbox" 
                    id="optimizeImages" 
                    className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                    checked={optimizeImages}
                    onChange={(e) => updateFormData({ optimizeImages: e.target.checked })}
                    style={{ 
                      right: optimizeImages ? '0' : 'auto',
                      borderColor: optimizeImages ? '#4F46E5' : 'transparent'
                    }}
                  />
                  <label 
                    htmlFor="optimizeImages" 
                    className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                    style={{ backgroundColor: optimizeImages ? '#4F46E5' : '#D1D5DB' }}
                  ></label>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <span className="text-sm text-gray-700">Featured Snippet Optimization</span>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          Structure content to target position zero with featured snippets
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="relative inline-block w-10 mr-2 align-middle select-none">
                  <input 
                    type="checkbox" 
                    id="targetFeaturedSnippet" 
                    className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                    checked={targetFeaturedSnippet}
                    onChange={(e) => updateFormData({ targetFeaturedSnippet: e.target.checked })}
                    style={{ 
                      right: targetFeaturedSnippet ? '0' : 'auto',
                      borderColor: targetFeaturedSnippet ? '#4F46E5' : 'transparent'
                    }}
                  />
                  <label 
                    htmlFor="targetFeaturedSnippet" 
                    className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                    style={{ backgroundColor: targetFeaturedSnippet ? '#4F46E5' : '#D1D5DB' }}
                  ></label>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <span className="text-sm text-gray-700">FAQ Schema Section</span>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          Adds FAQ section with structured data for potential featured snippets
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="relative inline-block w-10 mr-2 align-middle select-none">
                  <input 
                    type="checkbox" 
                    id="includeFaq" 
                    className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                    checked={includeFaq}
                    onChange={(e) => updateFormData({ includeFaq: e.target.checked })}
                    style={{ 
                      right: includeFaq ? '0' : 'auto',
                      borderColor: includeFaq ? '#4F46E5' : 'transparent'
                    }}
                  />
                  <label 
                    htmlFor="includeFaq" 
                    className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                    style={{ backgroundColor: includeFaq ? '#4F46E5' : '#D1D5DB' }}
                  ></label>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <span className="text-sm text-gray-700">HowTo Schema Section</span>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button className="ml-1 text-gray-400 hover:text-gray-600">
                          <i className="ri-question-line"></i>
                        </button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">
                          Adds step-by-step section with structured data for rich results
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="relative inline-block w-10 mr-2 align-middle select-none">
                  <input 
                    type="checkbox" 
                    id="includeHowTo" 
                    className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                    checked={includeHowTo}
                    onChange={(e) => updateFormData({ includeHowTo: e.target.checked })}
                    style={{ 
                      right: includeHowTo ? '0' : 'auto',
                      borderColor: includeHowTo ? '#4F46E5' : 'transparent'
                    }}
                  />
                  <label 
                    htmlFor="includeHowTo" 
                    className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                    style={{ backgroundColor: includeHowTo ? '#4F46E5' : '#D1D5DB' }}
                  ></label>
                </div>
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="mt-4 pt-3 border-t border-gray-200">
            <div className="bg-blue-50 border-l-4 border-blue-400 p-3 rounded-md text-blue-700 text-sm">
              <div className="flex">
                <LightbulbIcon className="h-4 w-4 mt-0.5 mr-2 flex-shrink-0" />
                <div>
                  <p className="font-medium">Pro SEO Strategy Tips</p>
                  <ul className="text-xs mt-1 space-y-1.5 list-disc pl-4">
                    <li>Use exact-match keyword in H1 and page title for maximum relevance</li>
                    <li>Include keywords in the first 100 words for better indexing</li>
                    <li>Add internal links to increase site authority and visitor time</li>
                    <li>Optimize content for featured snippets with concise answers to common questions</li>
                    <li>Use proper heading structure (H1, H2, H3) with keywords for better content hierarchy</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}