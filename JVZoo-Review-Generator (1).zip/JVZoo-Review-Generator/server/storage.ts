import { 
  users, 
  reviewConfigs, 
  reviewTemplates, 
  reviewResponses,
  subscriptionPlans,
  type User, 
  type InsertUser,
  type ReviewConfig,
  type InsertReviewConfig,
  type ReviewTemplate,
  type InsertReviewTemplate,
  type ReviewResponse,
  type InsertReviewResponse,
  type SubscriptionPlan,
  type InsertSubscriptionPlan
} from "@shared/schema";
import * as crypto from 'crypto';
import { db } from './db';
import { eq, and, or } from 'drizzle-orm';

// Utility function to hash passwords
function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

// Utility function to verify passwords
function verifyPassword(storedPassword: string, suppliedPassword: string): boolean {
  const [salt, hash] = storedPassword.split(':');
  const suppliedHash = crypto.pbkdf2Sync(suppliedPassword, salt, 1000, 64, 'sha512').toString('hex');
  return hash === suppliedHash;
}

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  authenticateUser(usernameOrEmail: string, password: string): Promise<User | null>;
  userExists(username: string): Promise<boolean>;
  updateUserSubscription(userId: number, subscriptionData: {
    subscriptionPlanId?: number;
    subscriptionStatus?: string;
    subscriptionStartDate?: Date;
    subscriptionEndDate?: Date;
    trialEndsAt?: Date | undefined;
  }): Promise<User | undefined>;
  
  // Subscription Plan methods
  getSubscriptionPlans(): Promise<SubscriptionPlan[]>;
  getSubscriptionPlan(id: number): Promise<SubscriptionPlan | undefined>;
  createSubscriptionPlan(plan: InsertSubscriptionPlan): Promise<SubscriptionPlan>;
  updateSubscriptionPlan(id: number, plan: Partial<InsertSubscriptionPlan>): Promise<SubscriptionPlan | undefined>;
  deleteSubscriptionPlan(id: number): Promise<boolean>;
  
  // Review Configuration methods
  getReviewConfigs(userId: number): Promise<ReviewConfig[]>;
  getReviewConfig(id: number): Promise<ReviewConfig | undefined>;
  createReviewConfig(config: InsertReviewConfig, userId: number): Promise<ReviewConfig>;
  updateReviewConfig(id: number, config: Partial<InsertReviewConfig>): Promise<ReviewConfig | undefined>;
  deleteReviewConfig(id: number): Promise<boolean>;
  
  // Review Template methods
  getReviewTemplates(userId: number): Promise<ReviewTemplate[]>;
  getReviewTemplate(id: number): Promise<ReviewTemplate | undefined>;
  createReviewTemplate(template: InsertReviewTemplate, userId: number): Promise<ReviewTemplate>;
  updateReviewTemplate(id: number, template: Partial<InsertReviewTemplate>): Promise<ReviewTemplate | undefined>;
  deleteReviewTemplate(id: number): Promise<boolean>;
  
  // Review Response methods
  getReviewResponses(configId: number): Promise<ReviewResponse[]>;
  getReviewResponse(id: number): Promise<ReviewResponse | undefined>;
  createReviewResponse(response: InsertReviewResponse): Promise<ReviewResponse>;
}

// PostgreSQL storage implementation
export class PostgresStorage implements IStorage {
  constructor() {
    // Initialize the database by creating a demo user if none exists
    this.initializeDatabase();
  }

  private async initializeDatabase() {
    try {
      // Wait a bit for database to be ready
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if we have any users
      const existingUsers = await db.select().from(users).limit(1);
      
      // If no users exist, create a demo user
      if (existingUsers.length === 0) {
        await this.createUser({
          username: 'demo',
          email: 'demo@example.com',
          password: 'demo123'
        });
      }

      // Check if we have any subscription plans
      const existingPlans = await db.select().from(subscriptionPlans).limit(1);
      
      // If no subscription plans exist, create default ones
      if (existingPlans.length === 0) {
        await this.createDefaultSubscriptionPlans();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
    }
  }

  private async createDefaultSubscriptionPlans() {
    try {
      console.log('Creating default subscription plans...');
      
      // Free Trial Plan
      await this.createSubscriptionPlan({
        name: 'Free Trial',
        description: 'Experience ReviewPro features for 3 days at no cost',
        price: '0.00',
        billingCycle: 'trial',
        features: JSON.stringify([
          'Generate up to 3 reviews',
          'Basic SEO optimization',
          'Standard templates',
          'Limited features for 3 days'
        ])
      });
      
      // Basic Plan (Monthly)
      await this.createSubscriptionPlan({
        name: 'Basic Plan (Monthly)',
        description: 'Essential features for small businesses and individual creators',
        price: '49.99',
        billingCycle: 'monthly',
        features: JSON.stringify([
          'Generate up to 5 reviews per month',
          'Basic SEO optimization',
          'Standard templates',
          'Email support'
        ])
      });
      
      // Basic Plan (Yearly)
      await this.createSubscriptionPlan({
        name: 'Basic Plan (Yearly)',
        description: 'Essential features for small businesses and individual creators',
        price: '499.99',
        billingCycle: 'yearly',
        features: JSON.stringify([
          'Generate up to 5 reviews per month',
          'Basic SEO optimization',
          'Standard templates',
          'Email support',
          '16% savings over monthly billing'
        ])
      });
      
      // Pro Plan (Monthly)
      await this.createSubscriptionPlan({
        name: 'Pro Plan (Monthly)',
        description: 'Advanced features for growing businesses and professional marketers',
        price: '99.99',
        billingCycle: 'monthly',
        features: JSON.stringify([
          'Generate up to 20 reviews per month',
          'Advanced SEO optimization',
          'Premium templates',
          'Priority email support',
          'Review analytics',
          'Multi-platform publishing'
        ])
      });
      
      // Pro Plan (Yearly)
      await this.createSubscriptionPlan({
        name: 'Pro Plan (Yearly)',
        description: 'Advanced features for growing businesses and professional marketers',
        price: '999.99',
        billingCycle: 'yearly',
        features: JSON.stringify([
          'Generate up to 20 reviews per month',
          'Advanced SEO optimization',
          'Premium templates',
          'Priority email support',
          'Review analytics',
          'Multi-platform publishing',
          '16% savings over monthly billing'
        ])
      });
      
      // Agency Plan (Monthly)
      await this.createSubscriptionPlan({
        name: 'Agency Plan (Monthly)',
        description: 'Complete solution for agencies and enterprise clients',
        price: '249.99',
        billingCycle: 'monthly',
        features: JSON.stringify([
          'Generate unlimited reviews',
          'Enterprise-grade SEO optimization',
          'Custom templates',
          'Dedicated account manager',
          'Advanced analytics dashboard',
          'White-label options',
          'API access',
          'Multi-user accounts'
        ])
      });
      
      // Agency Plan (Yearly)
      await this.createSubscriptionPlan({
        name: 'Agency Plan (Yearly)',
        description: 'Complete solution for agencies and enterprise clients',
        price: '2499.99',
        billingCycle: 'yearly',
        features: JSON.stringify([
          'Generate unlimited reviews',
          'Enterprise-grade SEO optimization',
          'Custom templates',
          'Dedicated account manager',
          'Advanced analytics dashboard',
          'White-label options',
          'API access',
          'Multi-user accounts',
          '16% savings over monthly billing'
        ])
      });
      
      console.log('Default subscription plans created successfully');
    } catch (error) {
      console.error('Failed to create default subscription plans:', error);
    }
  }

  // ======== User Methods ========
  async getUser(id: number): Promise<User | undefined> {
    try {
      const result = await db.select().from(users).where(eq(users.id, id));
      return result[0];
    } catch (error) {
      console.error('Error getting user by ID:', error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const result = await db.select().from(users).where(eq(users.username, username));
      return result[0];
    } catch (error) {
      console.error('Error getting user by username:', error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      // Hash the password before storing
      const userData = {
        ...insertUser,
        password: hashPassword(insertUser.password)
      };
      
      const result = await db.insert(users).values(userData).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }
  
  async userExists(username: string): Promise<boolean> {
    try {
      const user = await this.getUserByUsername(username);
      return !!user;
    } catch (error) {
      console.error('Error checking if user exists:', error);
      return false;
    }
  }
  
  async authenticateUser(usernameOrEmail: string, password: string): Promise<User | null> {
    try {
      // Get user by username or email
      const result = await db.select().from(users).where(
        or(
          eq(users.username, usernameOrEmail),
          eq(users.email, usernameOrEmail)
        )
      );
      
      const user = result[0];
      
      if (!user) {
        return null;
      }
      
      // Verify the password
      if (verifyPassword(user.password, password)) {
        return user;
      }
      
      return null;
    } catch (error) {
      console.error('Error authenticating user:', error);
      return null;
    }
  }

  // ======== Review Configuration Methods ========
  async getReviewConfigs(userId: number): Promise<ReviewConfig[]> {
    try {
      return await db.select().from(reviewConfigs).where(eq(reviewConfigs.userId, userId));
    } catch (error) {
      console.error('Error getting review configs:', error);
      return [];
    }
  }
  
  async getReviewConfig(id: number): Promise<ReviewConfig | undefined> {
    try {
      const result = await db.select().from(reviewConfigs).where(eq(reviewConfigs.id, id));
      return result[0];
    } catch (error) {
      console.error('Error getting review config:', error);
      return undefined;
    }
  }
  
  async createReviewConfig(config: InsertReviewConfig, userId: number): Promise<ReviewConfig> {
    try {
      const now = new Date().toISOString();
      const configData = {
        ...config,
        userId,
        createdAt: now
      };
      
      const result = await db.insert(reviewConfigs).values(configData).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating review config:', error);
      throw error;
    }
  }
  
  async updateReviewConfig(id: number, config: Partial<InsertReviewConfig>): Promise<ReviewConfig | undefined> {
    try {
      const result = await db
        .update(reviewConfigs)
        .set(config)
        .where(eq(reviewConfigs.id, id))
        .returning();
      return result[0];
    } catch (error) {
      console.error('Error updating review config:', error);
      return undefined;
    }
  }
  
  async deleteReviewConfig(id: number): Promise<boolean> {
    try {
      await db.delete(reviewConfigs).where(eq(reviewConfigs.id, id));
      return true;
    } catch (error) {
      console.error('Error deleting review config:', error);
      return false;
    }
  }
  
  // ======== Review Template Methods ========
  async getReviewTemplates(userId: number): Promise<ReviewTemplate[]> {
    try {
      return await db.select().from(reviewTemplates).where(eq(reviewTemplates.userId, userId));
    } catch (error) {
      console.error('Error getting review templates:', error);
      return [];
    }
  }
  
  async getReviewTemplate(id: number): Promise<ReviewTemplate | undefined> {
    try {
      const result = await db.select().from(reviewTemplates).where(eq(reviewTemplates.id, id));
      return result[0];
    } catch (error) {
      console.error('Error getting review template:', error);
      return undefined;
    }
  }
  
  async createReviewTemplate(template: InsertReviewTemplate, userId: number): Promise<ReviewTemplate> {
    try {
      const now = new Date().toISOString();
      const templateData = {
        ...template,
        userId,
        createdAt: now,
        updatedAt: now
      };
      
      const result = await db.insert(reviewTemplates).values(templateData).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating review template:', error);
      throw error;
    }
  }
  
  async updateReviewTemplate(id: number, template: Partial<InsertReviewTemplate>): Promise<ReviewTemplate | undefined> {
    try {
      const now = new Date().toISOString();
      const templateData = {
        ...template,
        updatedAt: now
      };
      
      const result = await db
        .update(reviewTemplates)
        .set(templateData)
        .where(eq(reviewTemplates.id, id))
        .returning();
      return result[0];
    } catch (error) {
      console.error('Error updating review template:', error);
      return undefined;
    }
  }
  
  async deleteReviewTemplate(id: number): Promise<boolean> {
    try {
      await db.delete(reviewTemplates).where(eq(reviewTemplates.id, id));
      return true;
    } catch (error) {
      console.error('Error deleting review template:', error);
      return false;
    }
  }
  
  // ======== Review Response Methods ========
  async getReviewResponses(configId: number): Promise<ReviewResponse[]> {
    try {
      return await db.select().from(reviewResponses).where(eq(reviewResponses.configId, configId));
    } catch (error) {
      console.error('Error getting review responses:', error);
      return [];
    }
  }
  
  async getReviewResponse(id: number): Promise<ReviewResponse | undefined> {
    try {
      const result = await db.select().from(reviewResponses).where(eq(reviewResponses.id, id));
      return result[0];
    } catch (error) {
      console.error('Error getting review response:', error);
      return undefined;
    }
  }
  
  async createReviewResponse(response: InsertReviewResponse): Promise<ReviewResponse> {
    try {
      const now = new Date().toISOString();
      const responseData = {
        ...response,
        createdAt: now
      };
      
      const result = await db.insert(reviewResponses).values(responseData).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating review response:', error);
      throw error;
    }
  }

  // ======== Subscription Methods ========
  async updateUserSubscription(userId: number, subscriptionData: {
    subscriptionPlanId?: number;
    subscriptionStatus?: string;
    subscriptionStartDate?: Date;
    subscriptionEndDate?: Date;
    trialEndsAt?: Date | undefined;
  }): Promise<User | undefined> {
    try {
      const result = await db
        .update(users)
        .set(subscriptionData)
        .where(eq(users.id, userId))
        .returning();
      return result[0];
    } catch (error) {
      console.error('Error updating user subscription:', error);
      return undefined;
    }
  }

  async getSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    try {
      return await db.select().from(subscriptionPlans);
    } catch (error) {
      console.error('Error getting subscription plans:', error);
      return [];
    }
  }

  async getSubscriptionPlan(id: number): Promise<SubscriptionPlan | undefined> {
    try {
      const result = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.id, id));
      return result[0];
    } catch (error) {
      console.error('Error getting subscription plan:', error);
      return undefined;
    }
  }

  async createSubscriptionPlan(plan: InsertSubscriptionPlan): Promise<SubscriptionPlan> {
    try {
      const result = await db.insert(subscriptionPlans).values(plan).returning();
      return result[0];
    } catch (error) {
      console.error('Error creating subscription plan:', error);
      throw error;
    }
  }

  async updateSubscriptionPlan(id: number, plan: Partial<InsertSubscriptionPlan>): Promise<SubscriptionPlan | undefined> {
    try {
      const result = await db
        .update(subscriptionPlans)
        .set(plan)
        .where(eq(subscriptionPlans.id, id))
        .returning();
      return result[0];
    } catch (error) {
      console.error('Error updating subscription plan:', error);
      return undefined;
    }
  }

  async deleteSubscriptionPlan(id: number): Promise<boolean> {
    try {
      await db.delete(subscriptionPlans).where(eq(subscriptionPlans.id, id));
      return true;
    } catch (error) {
      console.error('Error deleting subscription plan:', error);
      return false;
    }
  }
}

// In-memory storage implementation (for fallback or testing)
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private reviewConfigs: Map<number, ReviewConfig>;
  private reviewTemplates: Map<number, ReviewTemplate>;
  private reviewResponses: Map<number, ReviewResponse>;
  private subscriptionPlans: Map<number, SubscriptionPlan>;
  private userIdCounter: number;
  private configIdCounter: number;
  private templateIdCounter: number;
  private responseIdCounter: number;
  private planIdCounter: number;

  constructor() {
    this.users = new Map();
    this.reviewConfigs = new Map();
    this.reviewTemplates = new Map();
    this.reviewResponses = new Map();
    this.subscriptionPlans = new Map();
    this.userIdCounter = 1;
    this.configIdCounter = 1;
    this.templateIdCounter = 1;
    this.responseIdCounter = 1;
    this.planIdCounter = 1;
    
    // Add a demo user
    this.createUser({
      username: 'demo',
      email: 'demo@example.com',
      password: 'demo123'
    });
  }

  // ===== User Methods =====
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    // Hash the password before storing
    const user: User = { 
      id,
      username: insertUser.username,
      email: insertUser.email,
      password: hashPassword(insertUser.password),
      firebaseUid: insertUser.firebaseUid || null,
      subscriptionPlanId: null,
      subscriptionStatus: "inactive",
      subscriptionStartDate: null,
      subscriptionEndDate: null,
      trialEndsAt: null,
      createdAt: now
    };
    this.users.set(id, user);
    return user;
  }
  
  async userExists(username: string): Promise<boolean> {
    const user = await this.getUserByUsername(username);
    return !!user;
  }
  
  async authenticateUser(usernameOrEmail: string, password: string): Promise<User | null> {
    console.log('Authenticating user in MemStorage:', usernameOrEmail);
    
    // Find user by username
    let user = await this.getUserByUsername(usernameOrEmail);
    
    // If not found by username, try to find by email
    if (!user) {
      user = Array.from(this.users.values()).find(
        (u) => u.email === usernameOrEmail
      );
    }
    
    if (!user) {
      console.log('User not found in MemStorage');
      return null;
    }
    
    console.log('User found in MemStorage, verifying password');
    
    // For Firebase users, we can just pretend the password matches
    // This allows for seamless integration with Firebase Auth
    const isFirebaseAuth = user.firebaseUid && password === 'firebase-authenticated';
    
    // Verify the password or accept Firebase authentication
    if (isFirebaseAuth || verifyPassword(user.password, password)) {
      console.log('Authentication successful');
      return user;
    }
    
    console.log('Password verification failed');
    return null;
  }

  // ===== Review Config Methods =====
  async getReviewConfigs(userId: number): Promise<ReviewConfig[]> {
    return Array.from(this.reviewConfigs.values()).filter(
      (config) => config.userId === userId
    );
  }

  async getReviewConfig(id: number): Promise<ReviewConfig | undefined> {
    return this.reviewConfigs.get(id);
  }

  async createReviewConfig(config: InsertReviewConfig, userId: number): Promise<ReviewConfig> {
    const id = this.configIdCounter++;
    const now = new Date().toISOString();
    
    // Initialize with safe default values and then override with provided config
    const reviewConfig: ReviewConfig = {
      id,
      userId,
      productName: config.productName || '',
      productDescription: config.productDescription || null,
      offerLink: config.offerLink || null,
      jvDoc: config.jvDoc || null,
      affiliateLink: config.affiliateLink || null,
      bundleLink: config.bundleLink || null,
      reviewStyle: config.reviewStyle || '',
      toneStyle: config.toneStyle || '',
      includePricingTable: config.includePricingTable ?? true,
      includeProsConsSection: config.includeProsConsSection ?? true,
      includeCtaBanner: config.includeCtaBanner ?? true,
      includeProductImages: config.includeProductImages ?? true,
      includeFaqSection: config.includeFaqSection ?? false,
      targetKeyword: config.targetKeyword || null,
      secondaryKeywords: config.secondaryKeywords || null,
      includeTableOfContents: config.includeTableOfContents ?? true,
      reviewTheme: config.reviewTheme || 'classic',
      includeComparisonTable: config.includeComparisonTable ?? false,
      includeTestimonials: config.includeTestimonials ?? false,
      includeProductRating: config.includeProductRating ?? true,
      productRatingScore: config.productRatingScore || null,
      competingProducts: config.competingProducts || null,
      includeBonusSection: config.includeBonusSection ?? false,
      bonusContent: config.bonusContent || null,
      usePhaseApproach: config.usePhaseApproach ?? false,
      useMarketingCopywriting: config.useMarketingCopywriting ?? false,
      extendedWordCount: config.extendedWordCount ?? false,
      includeSeoSchema: config.includeSeoSchema ?? false,
      createdAt: now,
      generatedContent: null,
    };
    
    this.reviewConfigs.set(id, reviewConfig);
    return reviewConfig;
  }

  async updateReviewConfig(id: number, config: Partial<InsertReviewConfig>): Promise<ReviewConfig | undefined> {
    const existingConfig = this.reviewConfigs.get(id);
    
    if (!existingConfig) {
      return undefined;
    }
    
    const updatedConfig: ReviewConfig = {
      ...existingConfig,
      ...config,
    };
    
    this.reviewConfigs.set(id, updatedConfig);
    return updatedConfig;
  }

  async deleteReviewConfig(id: number): Promise<boolean> {
    return this.reviewConfigs.delete(id);
  }

  // ===== Review Template Methods =====
  async getReviewTemplates(userId: number): Promise<ReviewTemplate[]> {
    return Array.from(this.reviewTemplates.values()).filter(
      (template) => template.userId === userId
    );
  }

  async getReviewTemplate(id: number): Promise<ReviewTemplate | undefined> {
    return this.reviewTemplates.get(id);
  }

  async createReviewTemplate(template: InsertReviewTemplate, userId: number): Promise<ReviewTemplate> {
    const id = this.templateIdCounter++;
    const now = new Date().toISOString();
    
    const reviewTemplate: ReviewTemplate = {
      id,
      userId,
      templateName: template.templateName,
      templateDescription: template.templateDescription || null,
      templateConfig: template.templateConfig,
      isPublic: template.isPublic ?? false,
      createdAt: now,
      updatedAt: now,
    };
    
    this.reviewTemplates.set(id, reviewTemplate);
    return reviewTemplate;
  }

  async updateReviewTemplate(id: number, template: Partial<InsertReviewTemplate>): Promise<ReviewTemplate | undefined> {
    const existingTemplate = this.reviewTemplates.get(id);
    
    if (!existingTemplate) {
      return undefined;
    }
    
    const now = new Date().toISOString();
    const updatedTemplate: ReviewTemplate = {
      ...existingTemplate,
      ...template,
      updatedAt: now,
    };
    
    this.reviewTemplates.set(id, updatedTemplate);
    return updatedTemplate;
  }

  async deleteReviewTemplate(id: number): Promise<boolean> {
    return this.reviewTemplates.delete(id);
  }

  // ===== Review Response Methods =====
  async getReviewResponses(configId: number): Promise<ReviewResponse[]> {
    return Array.from(this.reviewResponses.values()).filter(
      (response) => response.configId === configId
    );
  }

  async getReviewResponse(id: number): Promise<ReviewResponse | undefined> {
    return this.reviewResponses.get(id);
  }

  async createReviewResponse(response: InsertReviewResponse): Promise<ReviewResponse> {
    const id = this.responseIdCounter++;
    const now = new Date().toISOString();
    
    const reviewResponse: ReviewResponse = {
      id,
      configId: response.configId,
      content: response.content,
      htmlContent: response.htmlContent || null,
      seoScore: response.seoScore || null,
      readabilityScore: response.readabilityScore || null,
      keywordDensity: response.keywordDensity || null,
      createdAt: now,
    };
    
    this.reviewResponses.set(id, reviewResponse);
    return reviewResponse;
  }

  // ===== Subscription Methods =====
  async updateUserSubscription(userId: number, subscriptionData: {
    subscriptionPlanId?: number;
    subscriptionStatus?: string;
    subscriptionStartDate?: Date;
    subscriptionEndDate?: Date;
    trialEndsAt?: Date | undefined;
  }): Promise<User | undefined> {
    const user = this.users.get(userId);
    
    if (!user) {
      return undefined;
    }
    
    const updatedUser = {
      ...user,
      ...subscriptionData
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    return Array.from(this.subscriptionPlans.values());
  }

  async getSubscriptionPlan(id: number): Promise<SubscriptionPlan | undefined> {
    return this.subscriptionPlans.get(id);
  }

  async createSubscriptionPlan(plan: InsertSubscriptionPlan): Promise<SubscriptionPlan> {
    const id = this.planIdCounter++;
    const now = new Date();
    
    const subscriptionPlan: SubscriptionPlan = {
      id,
      name: plan.name,
      description: plan.description || null,
      price: plan.price,
      billingCycle: plan.billingCycle,
      features: plan.features,
      createdAt: now
    };
    
    this.subscriptionPlans.set(id, subscriptionPlan);
    return subscriptionPlan;
  }

  async updateSubscriptionPlan(id: number, plan: Partial<InsertSubscriptionPlan>): Promise<SubscriptionPlan | undefined> {
    const existingPlan = this.subscriptionPlans.get(id);
    
    if (!existingPlan) {
      return undefined;
    }
    
    const updatedPlan = {
      ...existingPlan,
      ...plan
    };
    
    this.subscriptionPlans.set(id, updatedPlan);
    return updatedPlan;
  }

  async deleteSubscriptionPlan(id: number): Promise<boolean> {
    return this.subscriptionPlans.delete(id);
  }
}

// Use PostgresStorage since we have a PostgreSQL database available
export const storage = new PostgresStorage();
