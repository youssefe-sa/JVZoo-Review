import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { User, LogOut, UserPlus, LogIn, Settings, Palette, PanelLeft, Save, FileDigit, Trash2, LayoutDashboard } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { AuthDialog } from './AuthDialog';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

export function UserMenu() {
  const { user, isAuthenticated, logout } = useAuth();
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [authDialogTab, setAuthDialogTab] = useState<'login' | 'register'>('login');
  const { toast } = useToast();
  
  // Settings related dialog states
  const [isAccountDialogOpen, setIsAccountDialogOpen] = useState(false);
  const [isThemeDialogOpen, setIsThemeDialogOpen] = useState(false);
  const [isAutoSaveDialogOpen, setIsAutoSaveDialogOpen] = useState(false);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  const [isClearDataDialogOpen, setIsClearDataDialogOpen] = useState(false);
  
  // User preferences states
  const [compactMode, setCompactMode] = useState(false);
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(true);
  const [enableNotifications, setEnableNotifications] = useState(true);
  
  // Theme settings states
  const [themeMode, setThemeMode] = useState<'light' | 'dark' | 'system'>('light');
  const [accentColor, setAccentColor] = useState<string>('indigo');
  const [borderRadius, setBorderRadius] = useState<number>(75); // 0-100%
  
  // Auto-save settings states
  const [autoSaveEnabled, setAutoSaveEnabled] = useState<boolean>(true);
  const [autoSaveInterval, setAutoSaveInterval] = useState<string>('1m');
  const [customIntervalMinutes, setCustomIntervalMinutes] = useState<number>(2);
  const [versionHistory, setVersionHistory] = useState<string>('20');
  
  // Clear data state
  const [clearDataConfirmed, setClearDataConfirmed] = useState({
    understood: false,
    irreversible: false
  });
  
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileData, setProfileData] = useState({
    displayName: '',
    email: '',
    role: 'Member',
    memberSince: 'April 2025',
    bio: ''
  });
  
  // Template manager state
  const [templateSort, setTemplateSort] = useState<string>('recent');
  const [templateSearchTerm, setTemplateSearchTerm] = useState<string>('');

  const handleOpenAuthDialog = (tab: 'login' | 'register') => {
    setAuthDialogTab(tab);
    setAuthDialogOpen(true);
  };
  
  // Save account preferences
  const saveAccountPreferences = () => {
    // In a real application, this would save to a database via API
    toast({
      title: "Account settings saved",
      description: "Your account preferences have been updated",
    });
    setIsAccountDialogOpen(false);
  };
  
  // Apply theme settings
  const applyThemeSettings = () => {
    // In a real application, this would update theme in localStorage or API
    toast({
      title: "Theme updated",
      description: `Theme set to ${themeMode} mode with ${accentColor} accent`,
    });
    setIsThemeDialogOpen(false);
  };
  
  // Save auto-save settings
  const saveAutoSaveSettings = () => {
    // In a real application, this would configure auto-save timers
    const intervalText = autoSaveInterval === 'custom' 
      ? `${customIntervalMinutes} minutes` 
      : autoSaveInterval === '30s' ? '30 seconds' : autoSaveInterval === '1m' ? '1 minute' : '5 minutes';
      
    toast({
      title: autoSaveEnabled ? "Auto-save enabled" : "Auto-save disabled",
      description: autoSaveEnabled ? `Will save every ${intervalText}` : "Auto-save has been turned off",
    });
    setIsAutoSaveDialogOpen(false);
  };
  
  // Save profile changes
  const saveProfileChanges = () => {
    // In a real application, this would update user profile in database
    toast({
      title: "Profile updated",
      description: "Your profile information has been updated successfully",
    });
  };

  // Confirm data clearing
  const confirmClearData = () => {
    if (clearDataConfirmed.understood && clearDataConfirmed.irreversible) {
      // In a real application, this would clear user data from database
      toast({
        title: "Data cleared",
        description: "All your data has been permanently deleted",
        variant: "destructive"
      });
      setClearDataConfirmed({ understood: false, irreversible: false });
      setIsClearDataDialogOpen(false);
    } else {
      toast({
        title: "Action required",
        description: "Please confirm both checkboxes to continue",
        variant: "destructive"
      });
    }
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="rounded-full">
            <User className="h-5 w-5" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          {isAuthenticated ? (
            <>
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem disabled>
                <User className="mr-2 h-4 w-4" />
                <span>Signed in as <b>{user?.username}</b></span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <Link href="/dashboard" className="w-full">
                <DropdownMenuItem>
                  <LayoutDashboard className="mr-2 h-4 w-4 text-indigo-600" />
                  <span>User Dashboard</span>
                </DropdownMenuItem>
              </Link>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setIsAccountDialogOpen(true)}>
                <Settings className="mr-2 h-4 w-4 text-indigo-600" />
                <span>Account Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setIsAutoSaveDialogOpen(true)}>
                <Save className="mr-2 h-4 w-4 text-indigo-600" />
                <span>Auto-save Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setIsTemplateDialogOpen(true)}>
                <FileDigit className="mr-2 h-4 w-4 text-indigo-600" />
                <span>Template Manager</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setIsClearDataDialogOpen(true)}>
                <Trash2 className="mr-2 h-4 w-4 text-red-500" />
                <span className="text-red-500">Clear All Data</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => logout()}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </>
          ) : (
            <>
              <DropdownMenuLabel>Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => handleOpenAuthDialog('login')}>
                <LogIn className="mr-2 h-4 w-4" />
                <span>Log in</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleOpenAuthDialog('register')}>
                <UserPlus className="mr-2 h-4 w-4" />
                <span>Sign up</span>
              </DropdownMenuItem>
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      <AuthDialog 
        isOpen={authDialogOpen} 
        onClose={() => setAuthDialogOpen(false)} 
        defaultTab={authDialogTab} 
      />

      {/* Account Settings Dialog */}
      <Dialog open={isAccountDialogOpen} onOpenChange={setIsAccountDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-lg flex items-center">
              <Settings className="text-indigo-600 mr-2 h-5 w-5" />
              Account Settings
            </DialogTitle>
            <DialogDescription>
              Customize your account settings and preferences
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 mt-2">
            <div className="bg-white rounded-lg border border-gray-200 divide-y divide-gray-200">
              <div className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-gray-800">Profile Information</h3>
                    <p className="text-sm text-gray-500">Your basic account details</p>
                  </div>
                  <Button 
                    size="sm" 
                    variant={isEditingProfile ? "default" : "outline"}
                    className={isEditingProfile ? "bg-indigo-600 text-white hover:bg-indigo-700" : ""}
                    onClick={() => setIsEditingProfile(!isEditingProfile)}
                  >
                    {isEditingProfile ? "Cancel" : "Edit"}
                  </Button>
                </div>
                
                {!isEditingProfile ? (
                  <div className="mt-3 grid grid-cols-2 gap-y-4 gap-x-6 text-sm">
                    <div>
                      <p className="text-gray-500">Display Name</p>
                      <p className="font-medium">{profileData.displayName || user?.username || "User"}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Username</p>
                      <p className="font-medium">{user?.username || "User"}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Email</p>
                      <p className="font-medium">{profileData.email || "email@example.com"}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Role</p>
                      <p className="font-medium">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                          {profileData.role || "Member"}
                        </span>
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-500">Member Since</p>
                      <p className="font-medium">{profileData.memberSince || "April 2025"}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Account Status</p>
                      <p className="font-medium">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Active
                        </span>
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="mt-4 space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label htmlFor="display-name" className="text-xs font-medium text-gray-700">Display Name</label>
                        <input 
                          type="text" 
                          id="display-name" 
                          value={profileData.displayName || user?.username || ""}
                          onChange={(e) => setProfileData({...profileData, displayName: e.target.value})}
                          className="w-full p-2 text-sm border border-gray-300 rounded bg-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label htmlFor="username" className="text-xs font-medium text-gray-700">Username</label>
                        <input 
                          type="text" 
                          id="username" 
                          value={user?.username || ""}
                          disabled
                          className="w-full p-2 text-sm border border-gray-200 rounded bg-gray-50 text-gray-500"
                        />
                        <p className="text-xs text-gray-500">Cannot be changed</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label htmlFor="email" className="text-xs font-medium text-gray-700">Email Address</label>
                        <input 
                          type="email" 
                          id="email" 
                          value={profileData.email || ""}
                          onChange={(e) => setProfileData({...profileData, email: e.target.value})}
                          className="w-full p-2 text-sm border border-gray-300 rounded bg-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label htmlFor="bio" className="text-xs font-medium text-gray-700">Short Bio</label>
                        <input 
                          type="text" 
                          id="bio" 
                          value={profileData.bio || ""}
                          onChange={(e) => setProfileData({...profileData, bio: e.target.value})}
                          className="w-full p-2 text-sm border border-gray-300 rounded bg-white"
                          placeholder="Tell us about yourself"
                        />
                      </div>
                    </div>
                    
                    <Button 
                      size="sm" 
                      className="mt-2 bg-indigo-600 text-white hover:bg-indigo-700"
                      onClick={() => {
                        saveProfileChanges();
                        setIsEditingProfile(false);
                      }}
                    >
                      Save Changes
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-gray-800">Interface Preferences</h3>
                    <p className="text-sm text-gray-500">Customize the application interface</p>
                  </div>
                </div>
                
                <div className="mt-3 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Compact Interface Mode</span>
                    <button 
                      className={`relative inline-flex h-6 w-11 items-center rounded-full ${compactMode ? 'bg-indigo-600' : 'bg-gray-200'}`}
                      onClick={() => setCompactMode(!compactMode)}
                    >
                      <span className="sr-only">Enable compact mode</span>
                      <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${compactMode ? 'translate-x-6' : 'translate-x-1'}`}></span>
                    </button>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Show Advanced Options by Default</span>
                    <button 
                      className={`relative inline-flex h-6 w-11 items-center rounded-full ${showAdvancedOptions ? 'bg-indigo-600' : 'bg-gray-200'}`}
                      onClick={() => setShowAdvancedOptions(!showAdvancedOptions)}
                    >
                      <span className="sr-only">Enable advanced options</span>
                      <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${showAdvancedOptions ? 'translate-x-6' : 'translate-x-1'}`}></span>
                    </button>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Enable In-App Notifications</span>
                    <button 
                      className={`relative inline-flex h-6 w-11 items-center rounded-full ${enableNotifications ? 'bg-indigo-600' : 'bg-gray-200'}`}
                      onClick={() => setEnableNotifications(!enableNotifications)}
                    >
                      <span className="sr-only">Enable notifications</span>
                      <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${enableNotifications ? 'translate-x-6' : 'translate-x-1'}`}></span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsAccountDialogOpen(false)}
            >
              Close
            </Button>
            <Button 
              className="bg-indigo-600 hover:bg-indigo-700 text-white"
              onClick={saveAccountPreferences}
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Theme Settings Dialog */}
      <Dialog open={isThemeDialogOpen} onOpenChange={setIsThemeDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-lg flex items-center">
              <Palette className="text-indigo-600 mr-2 h-5 w-5" />
              Theme Settings
            </DialogTitle>
            <DialogDescription>
              Customize the appearance of your review generator
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-2 gap-4">
            <div 
              className={`border ${themeMode === 'light' ? 'border-indigo-400 ring-2 ring-indigo-200' : 'border-indigo-200'} hover:border-indigo-400 p-4 rounded-lg transition-all cursor-pointer relative`}
              style={{ background: 'linear-gradient(to bottom right, #EBF4FF, #E6FFFA)' }}
              onClick={() => setThemeMode('light')}
            >
              {themeMode === 'light' && (
                <div className="absolute top-2 right-2 bg-white rounded-full h-5 w-5 flex items-center justify-center border border-indigo-300">
                  <div className="bg-indigo-600 rounded-full h-3 w-3"></div>
                </div>
              )}
              <h3 className="font-medium text-gray-800 mb-1">Light Mode</h3>
              <p className="text-xs text-gray-500">Bright, clean interface.</p>
            </div>
            
            <div 
              className={`border ${themeMode === 'dark' ? 'border-indigo-400 ring-2 ring-indigo-200' : 'border-indigo-200'} hover:border-indigo-400 p-4 rounded-lg transition-all cursor-pointer relative`}
              style={{ background: 'linear-gradient(to bottom right, #312E81, #1E3A8A)' }}
              onClick={() => setThemeMode('dark')}
            >
              {themeMode === 'dark' && (
                <div className="absolute top-2 right-2 bg-gray-800 rounded-full h-5 w-5 flex items-center justify-center border border-indigo-500">
                  <div className="bg-indigo-400 rounded-full h-3 w-3"></div>
                </div>
              )}
              <h3 className="font-medium text-white mb-1">Dark Mode</h3>
              <p className="text-xs text-indigo-200">Reduces eye strain.</p>
            </div>
            
            <div 
              className={`border ${themeMode === 'system' ? 'border-indigo-400 ring-2 ring-indigo-200' : 'border-indigo-200'} hover:border-indigo-400 p-4 rounded-lg transition-all cursor-pointer col-span-2 relative`}
              style={{ background: 'linear-gradient(to right, #EBF4FF 50%, #312E81 50%)' }}
              onClick={() => setThemeMode('system')}
            >
              {themeMode === 'system' && (
                <div className="absolute top-2 right-2 bg-gradient-to-br from-white to-gray-800 rounded-full h-5 w-5 flex items-center justify-center border border-indigo-300">
                  <div className="bg-indigo-500 rounded-full h-3 w-3"></div>
                </div>
              )}
              <h3 className="font-medium text-gray-800 mb-1">System Preference</h3>
              <p className="text-xs text-gray-600">Automatically adjusts based on your device settings.</p>
            </div>
          </div>
          
          <div className="space-y-4 mt-4">
            <div>
              <label className="text-sm font-medium text-gray-700 block mb-1">
                Accent Color
              </label>
              <div className="grid grid-cols-5 gap-2">
                <div 
                  className={`h-8 rounded-md cursor-pointer ${accentColor === 'indigo' ? 'ring-2 ring-offset-2 ring-indigo-400' : ''}`}
                  style={{ backgroundColor: '#6366F1' }}
                  onClick={() => setAccentColor('indigo')}
                ></div>
                <div 
                  className={`h-8 rounded-md cursor-pointer ${accentColor === 'violet' ? 'ring-2 ring-offset-2 ring-violet-400' : ''}`}
                  style={{ backgroundColor: '#8B5CF6' }}
                  onClick={() => setAccentColor('violet')}
                ></div>
                <div 
                  className={`h-8 rounded-md cursor-pointer ${accentColor === 'blue' ? 'ring-2 ring-offset-2 ring-blue-400' : ''}`}
                  style={{ backgroundColor: '#3B82F6' }}
                  onClick={() => setAccentColor('blue')}
                ></div>
                <div 
                  className={`h-8 rounded-md cursor-pointer ${accentColor === 'emerald' ? 'ring-2 ring-offset-2 ring-emerald-400' : ''}`}
                  style={{ backgroundColor: '#10B981' }}
                  onClick={() => setAccentColor('emerald')}
                ></div>
                <div 
                  className={`h-8 rounded-md cursor-pointer ${accentColor === 'rose' ? 'ring-2 ring-offset-2 ring-rose-400' : ''}`}
                  style={{ backgroundColor: '#F43F5E' }}
                  onClick={() => setAccentColor('rose')}
                ></div>
              </div>
            </div>
            
            <div>
              <label className="text-sm font-medium text-gray-700 flex justify-between mb-1">
                Border Radius
                <span className="text-gray-500">{borderRadius}%</span>
              </label>
              <input 
                type="range" 
                min="0" 
                max="100" 
                value={borderRadius}
                onChange={(e) => setBorderRadius(parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Square</span>
                <span>Rounded</span>
                <span>Pill</span>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsThemeDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              className="bg-indigo-600 hover:bg-indigo-700 text-white"
              onClick={applyThemeSettings}
            >
              Apply Theme
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Auto-Save Settings Dialog */}
      <Dialog open={isAutoSaveDialogOpen} onOpenChange={setIsAutoSaveDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-lg flex items-center">
              <Save className="text-indigo-600 mr-2 h-5 w-5" />
              Auto-Save Settings
            </DialogTitle>
            <DialogDescription>
              Configure automatic saving preferences for your reviews
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 mt-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Enable Auto-Save</span>
              <button 
                className={`relative inline-flex h-6 w-11 items-center rounded-full ${autoSaveEnabled ? 'bg-indigo-600' : 'bg-gray-200'}`}
                onClick={() => setAutoSaveEnabled(!autoSaveEnabled)}
              >
                <span className="sr-only">Enable auto-save</span>
                <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${autoSaveEnabled ? 'translate-x-6' : 'translate-x-1'}`}></span>
              </button>
            </div>
            
            <div className={autoSaveEnabled ? 'opacity-100' : 'opacity-50 pointer-events-none'}>
              <label className="text-sm font-medium text-gray-700 block mb-2">
                Auto-Save Interval
              </label>
              
              <div className="grid grid-cols-4 gap-2">
                <div 
                  className={`p-2 border ${autoSaveInterval === '30s' ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-gray-200 hover:border-gray-300'} rounded-md cursor-pointer text-center transition-colors`}
                  onClick={() => setAutoSaveInterval('30s')}
                >
                  <div className="font-medium">30s</div>
                  <div className="text-xs">seconds</div>
                </div>
                <div 
                  className={`p-2 border ${autoSaveInterval === '1m' ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-gray-200 hover:border-gray-300'} rounded-md cursor-pointer text-center transition-colors`}
                  onClick={() => setAutoSaveInterval('1m')}
                >
                  <div className="font-medium">1m</div>
                  <div className="text-xs">minute</div>
                </div>
                <div 
                  className={`p-2 border ${autoSaveInterval === '5m' ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-gray-200 hover:border-gray-300'} rounded-md cursor-pointer text-center transition-colors`}
                  onClick={() => setAutoSaveInterval('5m')}
                >
                  <div className="font-medium">5m</div>
                  <div className="text-xs">minutes</div>
                </div>
                <div 
                  className={`p-2 border ${autoSaveInterval === 'custom' ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-gray-200 hover:border-gray-300'} rounded-md cursor-pointer text-center transition-colors`}
                  onClick={() => setAutoSaveInterval('custom')}
                >
                  <div className="font-medium">Custom</div>
                  <div className="text-xs">interval</div>
                </div>
              </div>
              
              {autoSaveInterval === 'custom' && (
                <div className="mt-3 flex items-center">
                  <input 
                    type="number" 
                    min="1" 
                    max="60"
                    value={customIntervalMinutes}
                    onChange={(e) => setCustomIntervalMinutes(Math.max(1, Math.min(60, parseInt(e.target.value) || 1)))}
                    className="w-16 p-1 text-sm border border-gray-300 rounded mr-2"
                  />
                  <span className="text-sm text-gray-600">minutes between auto-saves</span>
                </div>
              )}
            </div>
            
            <div className={autoSaveEnabled ? 'opacity-100' : 'opacity-50 pointer-events-none'}>
              <label className="text-sm font-medium text-gray-700 block mb-2">
                Version History
              </label>
              
              <div className="grid grid-cols-4 gap-2">
                <div 
                  className={`p-2 border ${versionHistory === '5' ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-gray-200 hover:border-gray-300'} rounded-md cursor-pointer text-center transition-colors`}
                  onClick={() => setVersionHistory('5')}
                >
                  <div className="font-medium">5</div>
                  <div className="text-xs">versions</div>
                </div>
                <div 
                  className={`p-2 border ${versionHistory === '10' ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-gray-200 hover:border-gray-300'} rounded-md cursor-pointer text-center transition-colors`}
                  onClick={() => setVersionHistory('10')}
                >
                  <div className="font-medium">10</div>
                  <div className="text-xs">versions</div>
                </div>
                <div 
                  className={`p-2 border ${versionHistory === '20' ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-gray-200 hover:border-gray-300'} rounded-md cursor-pointer text-center transition-colors`}
                  onClick={() => setVersionHistory('20')}
                >
                  <div className="font-medium">20</div>
                  <div className="text-xs">versions</div>
                </div>
                <div 
                  className={`p-2 border ${versionHistory === 'unlimited' ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-gray-200 hover:border-gray-300'} rounded-md cursor-pointer text-center transition-colors`}
                  onClick={() => setVersionHistory('unlimited')}
                >
                  <div className="font-medium">All</div>
                  <div className="text-xs">unlimited</div>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsAutoSaveDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              className="bg-indigo-600 hover:bg-indigo-700 text-white"
              onClick={saveAutoSaveSettings}
            >
              Save Settings
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Template Manager Dialog */}
      <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader className="px-1">
            <DialogTitle className="text-lg flex items-center">
              <FileDigit className="text-indigo-600 mr-2 h-5 w-5" />
              Template Manager
            </DialogTitle>
            <DialogDescription>
              Browse, search, and organize your saved review templates
            </DialogDescription>
          </DialogHeader>
          
          <div className="mt-2 space-y-4 max-h-[60vh] overflow-y-auto pr-2">
            <div className="flex justify-between items-center mb-3">
              <div className="relative w-64">
                <input 
                  type="text" 
                  placeholder="Search templates..." 
                  className="w-full pl-8 pr-3 py-1.5 text-sm border border-gray-300 rounded bg-white focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                  value={templateSearchTerm}
                  onChange={(e) => setTemplateSearchTerm(e.target.value)}
                />
                <div className="absolute left-2.5 top-1/2 transform -translate-y-1/2 text-gray-400">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
              </div>
              <div className="flex gap-2">
                <select 
                  className="text-xs p-1.5 border border-gray-300 rounded bg-white"
                  value={templateSort}
                  onChange={(e) => setTemplateSort(e.target.value)}
                >
                  <option value="recent">Sort by: Recent</option>
                  <option value="name">Sort by: Name</option>
                  <option value="type">Sort by: Type</option>
                </select>
                <Button size="sm" variant="outline" className="text-xs">
                  New Template
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Template Card 1 */}
              <div className="border border-gray-200 rounded-lg overflow-hidden hover:border-indigo-300 transition-colors">
                <div className="bg-gradient-to-r from-indigo-50 to-blue-50 p-3 border-b border-gray-200">
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium text-indigo-900">Product Review Template</h3>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      Pro
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Comprehensive product review structure with pros/cons</p>
                </div>
                <div className="p-3 bg-white">
                  <div className="flex gap-1 text-xs mb-2">
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Review</span>
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Product</span>
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">SEO</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">Last used: 2 days ago</span>
                    <div className="flex gap-1">
                      <button className="p-1.5 text-gray-400 hover:text-indigo-600 rounded-full hover:bg-indigo-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                        </svg>
                      </button>
                      <button className="p-1.5 text-gray-400 hover:text-indigo-600 rounded-full hover:bg-indigo-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                      </button>
                      <button className="p-1.5 text-gray-400 hover:text-red-600 rounded-full hover:bg-red-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Template Card 2 */}
              <div className="border border-gray-200 rounded-lg overflow-hidden hover:border-indigo-300 transition-colors">
                <div className="bg-gradient-to-r from-green-50 to-teal-50 p-3 border-b border-gray-200">
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium text-teal-900">Affiliate Review</h3>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-teal-100 text-teal-800">
                      Standard
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Optimized for affiliate marketing with CTA sections</p>
                </div>
                <div className="p-3 bg-white">
                  <div className="flex gap-1 text-xs mb-2">
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Review</span>
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Affiliate</span>
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Marketing</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">Last used: 5 hours ago</span>
                    <div className="flex gap-1">
                      <button className="p-1.5 text-gray-400 hover:text-indigo-600 rounded-full hover:bg-indigo-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                        </svg>
                      </button>
                      <button className="p-1.5 text-gray-400 hover:text-indigo-600 rounded-full hover:bg-indigo-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                      </button>
                      <button className="p-1.5 text-gray-400 hover:text-red-600 rounded-full hover:bg-red-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Template Card 3 */}
              <div className="border border-gray-200 rounded-lg overflow-hidden hover:border-indigo-300 transition-colors">
                <div className="bg-gradient-to-r from-amber-50 to-yellow-50 p-3 border-b border-gray-200">
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium text-amber-900">Case Study Review</h3>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                      Pro
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Evidence-based review with real user results</p>
                </div>
                <div className="p-3 bg-white">
                  <div className="flex gap-1 text-xs mb-2">
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Review</span>
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Case Study</span>
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Detailed</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">Last used: 1 week ago</span>
                    <div className="flex gap-1">
                      <button className="p-1.5 text-gray-400 hover:text-indigo-600 rounded-full hover:bg-indigo-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                        </svg>
                      </button>
                      <button className="p-1.5 text-gray-400 hover:text-indigo-600 rounded-full hover:bg-indigo-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                      </button>
                      <button className="p-1.5 text-gray-400 hover:text-red-600 rounded-full hover:bg-red-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Template Card 4 */}
              <div className="border border-gray-200 rounded-lg overflow-hidden hover:border-indigo-300 transition-colors">
                <div className="bg-gradient-to-r from-purple-50 to-fuchsia-50 p-3 border-b border-gray-200">
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium text-purple-900">Comparison Review</h3>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                      Pro
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Side-by-side product comparison with tables</p>
                </div>
                <div className="p-3 bg-white">
                  <div className="flex gap-1 text-xs mb-2">
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Review</span>
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Comparison</span>
                    <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Table</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-500">Last used: 3 days ago</span>
                    <div className="flex gap-1">
                      <button className="p-1.5 text-gray-400 hover:text-indigo-600 rounded-full hover:bg-indigo-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                        </svg>
                      </button>
                      <button className="p-1.5 text-gray-400 hover:text-indigo-600 rounded-full hover:bg-indigo-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                      </button>
                      <button className="p-1.5 text-gray-400 hover:text-red-600 rounded-full hover:bg-red-50 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter className="pt-4 border-t mt-auto">
            <Button 
              variant="outline" 
              onClick={() => setIsTemplateDialogOpen(false)}
            >
              Close
            </Button>
            <Button 
              className="bg-indigo-600 hover:bg-indigo-700 text-white"
              onClick={() => {
                toast({
                  title: "Template selected",
                  description: "The selected template has been loaded",
                });
                setIsTemplateDialogOpen(false);
              }}
            >
              Apply Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Clear Data Dialog */}
      <Dialog open={isClearDataDialogOpen} onOpenChange={setIsClearDataDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-lg flex items-center text-red-600">
              <Trash2 className="text-red-600 mr-2 h-5 w-5" />
              Clear All Data
            </DialogTitle>
            <DialogDescription>
              This action will permanently delete all your data
            </DialogDescription>
          </DialogHeader>
          
          <div className="p-4 mt-2 border border-red-200 bg-red-50 rounded-md">
            <p className="text-sm text-red-800 mb-4">
              Please read carefully. This action will erase all your data including:
            </p>
            <ul className="text-sm text-red-700 space-y-1 mb-4 list-disc pl-5">
              <li>All your saved review templates</li>
              <li>Generated review content</li>
              <li>Custom settings and preferences</li>
              <li>Saved API keys and configuration</li>
            </ul>
            <p className="text-sm text-red-800 font-medium">
              This action cannot be undone.
            </p>
          </div>
          
          <div className="space-y-3 mt-3">
            <div className="flex items-start gap-2">
              <input 
                type="checkbox" 
                id="understand-data-loss" 
                className="mt-1"
                checked={clearDataConfirmed.understood}
                onChange={() => setClearDataConfirmed({...clearDataConfirmed, understood: !clearDataConfirmed.understood})}
              />
              <label htmlFor="understand-data-loss" className="text-sm text-gray-700">
                I understand this will permanently delete all my data
              </label>
            </div>
            <div className="flex items-start gap-2">
              <input 
                type="checkbox" 
                id="understand-irreversible" 
                className="mt-1"
                checked={clearDataConfirmed.irreversible}
                onChange={() => setClearDataConfirmed({...clearDataConfirmed, irreversible: !clearDataConfirmed.irreversible})}
              />
              <label htmlFor="understand-irreversible" className="text-sm text-gray-700">
                I understand this action is irreversible and cannot be undone
              </label>
            </div>
          </div>
          
          <DialogFooter className="mt-4">
            <Button 
              variant="outline" 
              onClick={() => {
                setClearDataConfirmed({ understood: false, irreversible: false });
                setIsClearDataDialogOpen(false);
              }}
            >
              Cancel
            </Button>
            <Button 
              className="bg-red-600 hover:bg-red-700 text-white"
              onClick={confirmClearData}
            >
              Clear All Data
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}