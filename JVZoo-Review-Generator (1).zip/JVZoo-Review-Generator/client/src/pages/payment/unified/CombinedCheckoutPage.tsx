import React, { useState, useEffect } from 'react';
import { useRoute, useLocation } from 'wouter';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { ArrowRightIcon, CheckIcon, ArrowLeftIcon } from '@heroicons/react/24/outline';
import { useAuth } from '@/lib/AuthContext';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { PaymentForm, PlanDetails } from '@/components/PaymentForm';

// Define plan types
type PlanType = 'free' | 'basic' | 'pro' | 'agency';
type BillingCycle = 'monthly' | 'yearly' | 'trial';

// Define plan structure
interface Plan {
  id: number;
  name: string;
  description: string;
  price: string;
  billingCycle: BillingCycle;
  features: string[];
}

// Registration form schema
const registerSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters').max(20, 'Username cannot exceed 20 characters'),
  email: z.string().email('Valid email is required'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  confirmPassword: z.string().min(1, 'Please confirm your password'),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Passwords do not match',
  path: ['confirmPassword'],
});

type RegisterFormData = z.infer<typeof registerSchema>;

export default function CombinedCheckoutPage() {
  // Use wouter route to extract parameters
  const [matched, params] = useRoute('/checkout/:planType?/:cycle?');
  const [, navigate] = useLocation();

  // Default to 'pro' plan and 'monthly' billing if not specified
  const initialPlanType = params?.planType as PlanType || 'pro';
  const initialCycle = params?.cycle as BillingCycle || 'monthly';

  // Use state to track the selected plan and billing cycle
  const [selectedPlanType, setSelectedPlanType] = useState<PlanType>(initialPlanType);
  const [billingCycle, setBillingCycle] = useState<BillingCycle>(initialCycle);
  // If a plan is specified in the URL parameters, skip directly to registration/payment
  const [step, setStep] = useState<'plan-select' | 'registration-payment'>(
    params?.planType ? 'registration-payment' : 'plan-select'
  );
  const [isLoading, setIsLoading] = useState(false);
  
  // Get authentication status
  const { isAuthenticated, register, user } = useAuth();
  const { toast } = useToast();

  // When URL parameters change, update the state with validation
  useEffect(() => {
    if (params?.planType) {
      // Make sure planType is valid
      const planType = params.planType as string;
      if (Object.keys(planData).includes(planType)) {
        setSelectedPlanType(planType as PlanType);
      }
    }
    if (params?.cycle) {
      // Make sure cycle is valid
      const cycle = params.cycle as string;
      if (['monthly', 'yearly', 'trial'].includes(cycle)) {
        setBillingCycle(cycle as BillingCycle);
      }
    }
  }, [params]);

  // Plan data - Each plan type has monthly and yearly options
  const planData: Record<PlanType, { monthly: Plan, yearly: Plan, trial?: Plan }> = {
    free: {
      monthly: {
        id: 1, // Free Trial Plan ID from database
        name: 'Free Trial',
        description: 'Experience ReviewPro features for 3 days at no cost',
        price: '0',
        billingCycle: 'monthly',
        features: [
          'Generate up to 3 reviews',
          'Basic SEO optimization',
          'Standard templates',
          'Limited features for 3 days',
          'No credit card required'
        ]
      },
      yearly: {
        id: 1, // Free Trial Plan ID from database
        name: 'Free Trial',
        description: 'Experience ReviewPro features for 3 days at no cost',
        price: '0',
        billingCycle: 'yearly',
        features: [
          'Generate up to 3 reviews',
          'Basic SEO optimization',
          'Standard templates',
          'Limited features for 3 days',
          'No credit card required'
        ]
      },
      trial: {
        id: 1, // Free Trial Plan ID from database
        name: 'Free Trial',
        description: 'Experience ReviewPro features for 3 days at no cost',
        price: '0',
        billingCycle: 'trial',
        features: [
          'Generate up to 3 reviews',
          'Basic SEO optimization',
          'Standard templates',
          'Limited features for 3 days',
          'No credit card required'
        ]
      }
    },
    basic: {
      monthly: {
        id: 2, // Basic Monthly Plan ID from database
        name: 'Basic',
        description: 'Perfect for beginners and small websites starting with review content.',
        price: '49.99',
        billingCycle: 'monthly',
        features: [
          '5 AI-generated reviews per month',
          'Basic SEO optimization',
          'Standard templates',
          'Email support'
        ]
      },
      yearly: {
        id: 3, // Basic Yearly Plan ID from database
        name: 'Basic',
        description: 'Perfect for beginners and small websites starting with review content.',
        price: '499.99',
        billingCycle: 'yearly',
        features: [
          '5 AI-generated reviews per month',
          'Basic SEO optimization',
          'Standard templates',
          'Email support',
          '16% savings over monthly billing'
        ]
      },
      trial: {
        id: 2, // Fallback to monthly plan ID
        name: 'Basic',
        description: 'Perfect for beginners and small websites starting with review content.',
        price: '49.99',
        billingCycle: 'monthly',
        features: [
          '5 AI-generated reviews per month',
          'Basic SEO optimization',
          'Standard templates',
          'Email support'
        ]
      }
    },
    pro: {
      monthly: {
        id: 4, // Pro Monthly Plan ID from database
        name: 'Pro',
        description: 'Advanced features for growing businesses and professional marketers',
        price: '99.99',
        billingCycle: 'monthly',
        features: [
          'Generate up to 20 reviews per month',
          'Advanced SEO optimization',
          'Premium templates',
          'Priority email support',
          'Review analytics',
          'Multi-platform publishing'
        ]
      },
      yearly: {
        id: 5, // Pro Yearly Plan ID from database
        name: 'Pro',
        description: 'Advanced features for growing businesses and professional marketers',
        price: '999.99',
        billingCycle: 'yearly',
        features: [
          'Generate up to 20 reviews per month',
          'Advanced SEO optimization',
          'Premium templates',
          'Priority email support',
          'Review analytics',
          'Multi-platform publishing',
          '16% savings over monthly billing'
        ]
      },
      trial: {
        id: 4, // Fallback to monthly plan ID
        name: 'Pro',
        description: 'Advanced features for growing businesses and professional marketers',
        price: '99.99',
        billingCycle: 'monthly',
        features: [
          'Generate up to 20 reviews per month',
          'Advanced SEO optimization',
          'Premium templates',
          'Priority email support',
          'Review analytics',
          'Multi-platform publishing'
        ]
      }
    },
    agency: {
      monthly: {
        id: 6, // Agency Monthly Plan ID from database
        name: 'Agency',
        description: 'Complete solution for agencies and enterprise clients',
        price: '249.99',
        billingCycle: 'monthly',
        features: [
          'Generate unlimited reviews',
          'Enterprise-grade SEO optimization',
          'Custom templates',
          'Dedicated account manager',
          'Advanced analytics dashboard',
          'White-label options',
          'API access',
          'Multi-user accounts'
        ]
      },
      yearly: {
        id: 7, // Agency Yearly Plan ID from database
        name: 'Agency',
        description: 'Complete solution for agencies and enterprise clients',
        price: '2499.99',
        billingCycle: 'yearly',
        features: [
          'Generate unlimited reviews',
          'Enterprise-grade SEO optimization',
          'Custom templates',
          'Dedicated account manager',
          'Advanced analytics dashboard',
          'White-label options',
          'API access',
          'Multi-user accounts',
          '16% savings over monthly billing'
        ]
      },
      trial: {
        id: 6, // Fallback to monthly plan ID
        name: 'Agency',
        description: 'Complete solution for agencies and enterprise clients',
        price: '249.99',
        billingCycle: 'monthly',
        features: [
          'Generate unlimited reviews',
          'Enterprise-grade SEO optimization',
          'Custom templates',
          'Dedicated account manager',
          'Advanced analytics dashboard',
          'White-label options',
          'API access',
          'Multi-user accounts'
        ]
      }
    }
  };

  // Default to pro/monthly if the selected plan type doesn't exist
  const validPlanType = Object.keys(planData).includes(selectedPlanType) ? selectedPlanType : 'pro';
  const validBillingCycle = ['monthly', 'yearly', 'trial'].includes(billingCycle) ? billingCycle : 'monthly';
  
  // Get the selected plan based on current state with validation
  // If the specified billing cycle isn't available, fall back to monthly
  const selectedPlan = planData[validPlanType][validBillingCycle] || planData[validPlanType]['monthly'];

  // Handle plan selection
  const handlePlanSelect = (plan: Plan) => {
    setSelectedPlanType(plan.name.toLowerCase() as PlanType);
    const planPath = `/checkout/${plan.name.toLowerCase()}/${billingCycle}`;
    navigate(planPath);
  };

  // Handle billing cycle change
  const handleBillingCycleChange = (cycle: BillingCycle) => {
    setBillingCycle(cycle);
    const planPath = `/checkout/${selectedPlanType}/${cycle}`;
    navigate(planPath);
  };

  // Initialize the form
  const registerForm = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
    },
  });

  // Handle continue to registration/payment
  const handleContinue = () => {
    setStep('registration-payment');
  };

  // Handle back to plan selection
  const handleBackToPlanSelect = () => {
    setStep('plan-select');
  };

  // Handle registration form submission
  const handleRegisterSubmit = async (data: RegisterFormData) => {
    setIsLoading(true);
    try {
      // Register the user with selected plan
      const success = await register(data.username, data.email, data.password, selectedPlan.id);
      
      if (success) {
        toast({
          title: "Registration successful!",
          description: "Your account has been created. You can now complete your payment.",
        });
        registerForm.reset();
      } else {
        throw new Error("Registration failed");
      }
    } catch (error) {
      console.error("Registration error:", error);
      toast({
        title: "Registration failed",
        description: error instanceof Error ? error.message : "There was an error creating your account. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle payment success
  const handlePaymentSuccess = () => {
    // Redirect to app after successful payment
    navigate('/app');
  };

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-4">
            {params?.planType ? `Complete Your ${selectedPlan.name} Plan Purchase` : 'Choose Your Plan'}
          </h1>
          <p className="text-lg text-gray-500 max-w-2xl mx-auto">
            {params?.planType 
              ? 'Complete your registration and payment to start creating amazing product reviews that convert.' 
              : 'Select your ideal plan to start creating amazing product reviews that convert.'}
          </p>
        </div>

        {/* Progress steps - Simplified when plan is already selected from landing page */}
        <div className="mb-10">
          {params?.planType ? (
            <div className="text-center">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-100 text-indigo-800">
                <CheckIcon className="h-4 w-4 mr-1" /> {selectedPlan.name} Plan Selected ({
                  billingCycle === 'monthly' ? 'Monthly' : 
                  billingCycle === 'yearly' ? 'Annual' : 
                  'Trial'
                })
              </span>
            </div>
          ) : (
            <div className="flex justify-center items-center space-x-4">
              <div className={`flex items-center ${step === 'plan-select' ? 'text-indigo-600 font-bold' : 'text-gray-500'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${step === 'plan-select' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                  1
                </div>
                <span>Choose Plan</span>
              </div>
              <div className="w-12 h-0.5 bg-gray-200"></div>
              <div className={`flex items-center ${step === 'registration-payment' ? 'text-indigo-600 font-bold' : 'text-gray-500'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${step === 'registration-payment' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                  2
                </div>
                <span>Registration & Payment</span>
              </div>
            </div>
          )}
        </div>

        {/* Plan selection */}
        {step === 'plan-select' && (
          <div className="space-y-8">
            {/* Billing toggle */}
            <div className="flex flex-col md:flex-row items-center justify-center mb-8 space-y-4 md:space-y-0">
              <span className={`text-lg ${billingCycle === 'monthly' ? 'font-semibold text-gray-900' : 'text-gray-500'}`}>
                Monthly Billing
              </span>
              <div className="mx-4 flex items-center">
                <Switch
                  checked={billingCycle === 'yearly'}
                  onCheckedChange={(checked) => handleBillingCycleChange(checked ? 'yearly' : 'monthly')}
                  className="mx-4"
                />
              </div>
              <div className="flex items-center">
                <span className={`text-lg ${billingCycle === 'yearly' ? 'font-semibold text-gray-900' : 'text-gray-500'}`}>
                  Annual Billing
                </span>
                <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  Save 20%
                </span>
              </div>
            </div>

            {/* Plan cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Basic Plan */}
              <Card 
                className={`shadow-lg transition-all duration-300 hover:shadow-xl ${selectedPlanType === 'basic' ? 'ring-2 ring-indigo-500' : ''}`}
                onClick={() => {
                  const plan = planData.basic[billingCycle] || planData.basic['monthly'];
                  handlePlanSelect(plan);
                }}
              >
                <CardHeader>
                  <CardTitle>{(planData.basic[billingCycle] || planData.basic['monthly']).name}</CardTitle>
                  <CardDescription>{(planData.basic[billingCycle] || planData.basic['monthly']).description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-3xl font-extrabold text-gray-900">${(planData.basic[billingCycle] || planData.basic['monthly']).price}</span>
                    <span className="text-gray-500">/{
                      billingCycle === 'monthly' ? 'mo' : 
                      billingCycle === 'yearly' ? 'yr' : 
                      'trial'
                    }</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {(planData.basic[billingCycle] || planData.basic['monthly']).features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckIcon className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    variant={selectedPlanType === 'basic' ? 'default' : 'outline'} 
                    className="w-full mt-6"
                    onClick={() => {
                      const plan = planData.basic[billingCycle] || planData.basic['monthly'];
                      handlePlanSelect(plan);
                    }}
                  >
                    {selectedPlanType === 'basic' ? 'Selected' : 'Select Basic'}
                  </Button>
                </CardContent>
              </Card>

              {/* Pro Plan */}
              <Card 
                className={`shadow-lg transition-all duration-300 hover:shadow-xl ${selectedPlanType === 'pro' ? 'ring-2 ring-indigo-500' : ''}`}
                onClick={() => {
                  const plan = planData.pro[billingCycle] || planData.pro['monthly'];
                  handlePlanSelect(plan);
                }}
              >
                <div className="py-1 px-4 bg-indigo-500 text-white text-center text-xs font-semibold">
                  MOST POPULAR
                </div>
                <CardHeader>
                  <CardTitle>{(planData.pro[billingCycle] || planData.pro['monthly']).name}</CardTitle>
                  <CardDescription>{(planData.pro[billingCycle] || planData.pro['monthly']).description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-3xl font-extrabold text-gray-900">${(planData.pro[billingCycle] || planData.pro['monthly']).price}</span>
                    <span className="text-gray-500">/{
                      billingCycle === 'monthly' ? 'mo' : 
                      billingCycle === 'yearly' ? 'yr' : 
                      'trial'
                    }</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {(planData.pro[billingCycle] || planData.pro['monthly']).features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckIcon className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    variant={selectedPlanType === 'pro' ? 'default' : 'outline'} 
                    className="w-full mt-6"
                    onClick={() => {
                      const plan = planData.pro[billingCycle] || planData.pro['monthly'];
                      handlePlanSelect(plan);
                    }}
                  >
                    {selectedPlanType === 'pro' ? 'Selected' : 'Select Pro'}
                  </Button>
                </CardContent>
              </Card>

              {/* Agency Plan */}
              <Card 
                className={`shadow-lg transition-all duration-300 hover:shadow-xl ${selectedPlanType === 'agency' ? 'ring-2 ring-indigo-500' : ''}`}
                onClick={() => {
                  const plan = planData.agency[billingCycle] || planData.agency['monthly'];
                  handlePlanSelect(plan);
                }}
              >
                <CardHeader>
                  <CardTitle>{(planData.agency[billingCycle] || planData.agency['monthly']).name}</CardTitle>
                  <CardDescription>{(planData.agency[billingCycle] || planData.agency['monthly']).description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-3xl font-extrabold text-gray-900">${(planData.agency[billingCycle] || planData.agency['monthly']).price}</span>
                    <span className="text-gray-500">/{
                      billingCycle === 'monthly' ? 'mo' : 
                      billingCycle === 'yearly' ? 'yr' : 
                      'trial'
                    }</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {(planData.agency[billingCycle] || planData.agency['monthly']).features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckIcon className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    variant={selectedPlanType === 'agency' ? 'default' : 'outline'} 
                    className="w-full mt-6"
                    onClick={() => {
                      const plan = planData.agency[billingCycle] || planData.agency['monthly'];
                      handlePlanSelect(plan);
                    }}
                  >
                    {selectedPlanType === 'agency' ? 'Selected' : 'Select Agency'}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Continue button */}
            <div className="flex justify-center mt-10">
              <Button 
                size="lg" 
                className="px-10"
                onClick={handleContinue}
              >
                Continue to Checkout <ArrowRightIcon className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        )}

        {/* Registration & Payment step - Combined */}
        {step === 'registration-payment' && (
          <div className="space-y-8">
            {/* Only show back button if user came from the base checkout page, not from landing page links */}
            {!params?.planType && (
              <Button 
                variant="outline" 
                onClick={handleBackToPlanSelect}
                className="mb-4"
              >
                <ArrowLeftIcon className="h-4 w-4 mr-2" /> Back to Plan Selection
              </Button>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left: Account creation */}
              <div className={`${selectedPlanType === 'free' ? 'lg:col-span-12' : 'lg:col-span-5'} space-y-6`}>
                <Card>
                  <CardHeader>
                    <CardTitle>
                      {selectedPlanType === 'free' 
                        ? 'Create Your Free Trial Account' 
                        : 'Create Your Account'}
                    </CardTitle>
                    <CardDescription>
                      {selectedPlanType === 'free' 
                        ? 'Set up your account to start your free trial - no credit card required'
                        : 'Set up your ReviewPro account to get started'}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isAuthenticated ? (
                      <div className="bg-green-50 p-4 rounded-md text-green-800 flex items-start">
                        <CheckIcon className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="font-medium">Account created</p>
                          <p className="text-sm">Logged in as {user?.email}</p>
                          {selectedPlanType === 'free' && (
                            <div className="mt-4">
                              <Button onClick={() => navigate('/dashboard')} className="w-full">
                                Go to Dashboard
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <Form {...registerForm}>
                        <form onSubmit={registerForm.handleSubmit(handleRegisterSubmit)} className="space-y-4">
                          <FormField
                            control={registerForm.control}
                            name="username"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Username <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input placeholder="Choose a username" required {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={registerForm.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Email <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input type="email" placeholder="Enter your email address" required {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={registerForm.control}
                            name="password"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Password <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input 
                                    type="password" 
                                    placeholder="Create a password" 
                                    autoComplete="new-password"
                                    required 
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={registerForm.control}
                            name="confirmPassword"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Confirm Password <span className="text-red-500">*</span></FormLabel>
                                <FormControl>
                                  <Input 
                                    type="password" 
                                    placeholder="Confirm your password" 
                                    autoComplete="new-password"
                                    required 
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <Button type="submit" className="w-full" disabled={isLoading}>
                            {isLoading 
                              ? 'Creating account...' 
                              : selectedPlanType === 'free' 
                                ? 'Start Free Trial' 
                                : 'Create Account & Continue'
                            }
                          </Button>
                          
                          {selectedPlanType === 'free' && (
                            <p className="text-sm text-center text-gray-500 mt-2">
                              No credit card required for the free trial
                            </p>
                          )}
                        </form>
                      </Form>
                    )}
                  </CardContent>
                </Card>

                {/* Plan summary */}
                <Card>
                  <CardHeader>
                    <CardTitle>Order Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{selectedPlan.name} Plan</span>
                        <span>${selectedPlan.price} /{
                          billingCycle === 'monthly' ? 'mo' : 
                          billingCycle === 'yearly' ? 'yr' : 
                          'trial'
                        }</span>
                      </div>
                      <div className="flex justify-between text-sm text-gray-500">
                        <span>Billing cycle</span>
                        <span>{
                          billingCycle === 'monthly' ? 'Monthly' : 
                          billingCycle === 'yearly' ? 'Annual' : 
                          'Trial'
                        }</span>
                      </div>
                      <div className="pt-3 border-t border-gray-200 font-medium flex justify-between">
                        <span>Total</span>
                        <span>${selectedPlan.price} /{
                          billingCycle === 'monthly' ? 'mo' : 
                          billingCycle === 'yearly' ? 'yr' : 
                          'trial'
                        }</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Right: Payment information - only show for paid plans */}
              {selectedPlanType !== 'free' && (
                <div className="lg:col-span-7">
                  {isAuthenticated ? (
                    <PaymentForm 
                      plan={{
                        id: selectedPlan.id,
                        name: selectedPlan.name,
                        price: selectedPlan.price,
                        billingCycle: billingCycle,
                        description: selectedPlan.description,
                        features: selectedPlan.features
                      }}
                      onSuccess={handlePaymentSuccess}
                      onCancel={params?.planType ? () => navigate('/') : handleBackToPlanSelect}
                    />
                  ) : (
                    <Card>
                      <CardHeader>
                        <CardTitle>Payment Information</CardTitle>
                        <CardDescription>
                          Create your account first to proceed to payment
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="flex flex-col items-center justify-center p-8">
                        <div className="text-gray-400 mb-4">
                          <ArrowRightIcon className="h-12 w-12 mx-auto mb-3" />
                          <p className="text-center">Complete your account creation to proceed to payment</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}