import React from 'react';

export default function PrivacyPolicy() {
  return (
    <div className="bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-10">
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl mb-4">Privacy Policy</h1>
          <p className="text-gray-500">Last updated: {new Date().toLocaleDateString()}</p>
        </div>

        <div className="prose prose-indigo max-w-none">
          <h2>1. Introduction</h2>
          <p>
            Thank you for choosing ReviewPro ("we," "us," "our"). We are committed to protecting your personal information and your right to privacy. This Privacy Policy explains how we collect, use, disclose, and protect your information when you use our website and services.
          </p>
          
          <h2>2. Information We Collect</h2>
          <p>
            We collect personal information that you voluntarily provide to us when you register for the service, express interest in obtaining information about our products, or otherwise contact us.
          </p>
          <p>
            The personal information we collect may include:
          </p>
          <ul>
            <li>Name and contact data (email address, phone number)</li>
            <li>Credentials (password and similar security information)</li>
            <li>Payment information (if you subscribe to our premium services)</li>
            <li>Usage data (how you interact with our platform)</li>
            <li>Content data (reviews, templates, and configurations you create)</li>
          </ul>
          
          <h2>3. How We Use Your Information</h2>
          <p>
            We use the information we collect for various business purposes, including:
          </p>
          <ul>
            <li>Providing, personalizing, and improving our services</li>
            <li>Communicating with you about updates, security alerts, and support</li>
            <li>Processing your subscription payments</li>
            <li>Delivering targeted marketing, service updates, and promotional offers</li>
            <li>Analyzing usage patterns to improve user experience</li>
            <li>Detecting, preventing, and addressing technical issues</li>
          </ul>
          
          <h2>4. Sharing Your Information</h2>
          <p>
            We may share your information with:
          </p>
          <ul>
            <li>Service providers who perform services on our behalf</li>
            <li>Professional advisors, such as lawyers, auditors, and insurers</li>
            <li>Authorities and others, when required by law or to protect rights</li>
            <li>Business transferees, in connection with a merger, acquisition, or sale of assets</li>
          </ul>
          
          <h2>5. Your Rights and Choices</h2>
          <p>
            Depending on your location, you may have certain rights regarding your personal information, including:
          </p>
          <ul>
            <li>Access to your personal information</li>
            <li>Correction of inaccurate data</li>
            <li>Deletion of your personal information</li>
            <li>Restriction of processing</li>
            <li>Data portability</li>
            <li>Objection to processing</li>
          </ul>
          <p>
            To exercise these rights, please contact us using the details provided in the "Contact Us" section.
          </p>
          
          <h2>6. Data Security</h2>
          <p>
            We have implemented appropriate technical and organizational security measures to protect your information. However, no electronic transmission or storage of information can be guaranteed to be 100% secure.
          </p>
          
          <h2>7. Data Retention</h2>
          <p>
            We will only keep your personal information for as long as necessary for the purposes set out in this Privacy Policy, unless a longer retention period is required by law.
          </p>
          
          <h2>8. Children's Privacy</h2>
          <p>
            Our services are not directed to children under 16. We do not knowingly collect personal information from children under 16. If you are a parent or guardian and believe your child has provided us with personal information, please contact us.
          </p>
          
          <h2>9. Changes to This Privacy Policy</h2>
          <p>
            We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date.
          </p>
          
          <h2>10. Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us at:
          </p>
          <p>
            Email: privacy@reviewpro.com<br />
            Address: 123 Review Street, Content City, CA 94000
          </p>
        </div>
      </div>
    </div>
  );
}