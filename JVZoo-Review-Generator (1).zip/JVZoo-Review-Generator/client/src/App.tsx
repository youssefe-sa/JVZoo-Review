import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Landing from "@/pages/Landing";
import TextConverter from "@/pages/TextConverter";
import Dashboard from "@/pages/Dashboard";
import PrivacyPolicy from "@/pages/legal/Privacy";
import TermsOfService from "@/pages/legal/Terms";
import DataPolicy from "@/pages/legal/DataPolicy";
import CookiesPolicy from "@/pages/legal/Cookies";
import SeoGuide from "@/pages/resources/SeoGuide";
import VideoReviews from "@/pages/resources/VideoReviews";
import AnalyticsDashboard from "@/pages/resources/AnalyticsDashboard";

// Company pages
import About from "@/pages/company/About";
import Blog from "@/pages/company/Blog";
import Jobs from "@/pages/company/Jobs";
import Press from "@/pages/company/Press";

// Blog article pages
import Article1 from "@/pages/blog/Article1";

// Product pages
import Roadmap from "@/pages/product/Roadmap";
import API from "@/pages/product/API";

// Payment pages
import BasicPlan from "@/pages/payment/BasicPlan";
import ProPlan from "@/pages/payment/ProPlan";
import AgencyPlan from "@/pages/payment/AgencyPlan";
import BasicPlanAnnual from "@/pages/payment/BasicPlanAnnual";
import ProPlanAnnual from "@/pages/payment/ProPlanAnnual";
import AgencyPlanAnnual from "@/pages/payment/AgencyPlanAnnual";
import PlanSelect from "@/pages/payment/PlanSelect";
import PaymentPage from "@/pages/payment/PaymentPage";
import SuccessPage from "@/pages/payment/SuccessPage";

// New unified checkout
import CheckoutPage from "@/pages/payment/unified/CheckoutPage";
import CombinedCheckoutPage from "@/pages/payment/unified/CombinedCheckoutPage";

// Support pages
import HelpCenter from "@/pages/support/HelpCenter";
import Documentation from "@/pages/support/Documentation";
import Tutorials from "@/pages/support/Tutorials";
import Contact from "@/pages/support/Contact";

import { AuthProvider, useAuth } from "./lib/AuthContext";
import { Toaster } from "@/components/ui/toaster";
import Layout from "@/components/Layout";

// Private route component to protect dashboard routes
function PrivateRoute({ component: Component, ...rest }: any) {
  const { isAuthenticated, isLoading } = useAuth();
  
  // While checking authentication status, show nothing or a loading spinner
  if (isLoading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }
  
  // If authenticated, render the protected component
  // Otherwise, redirect to landing page
  return isAuthenticated ? <Component {...rest} /> : <Redirect to="/" />;
}

function Router() {
  return (
    <Switch>
      {/* Landing has its own header and footer */}
      <Route path="/" component={Landing} />
      
      {/* Wrap authenticated app routes with app variant Layout */}
      <Route path="/app">
        {() => (
          <Layout variant="app">
            <PrivateRoute component={Home} />
          </Layout>
        )}
      </Route>
      
      {/* User Dashboard - protected route */}
      <Route path="/dashboard">
        {() => (
          <PrivateRoute component={Dashboard} />
        )}
      </Route>
      
      {/* Public routes with landing variant Layout */}
      <Route path="/text-tools">
        {() => (
          <Layout variant="landing">
            <TextConverter />
          </Layout>
        )}
      </Route>
      
      {/* Legal pages with landing variant Layout */}
      <Route path="/privacy">
        {() => (
          <Layout variant="landing">
            <PrivacyPolicy />
          </Layout>
        )}
      </Route>
      <Route path="/terms">
        {() => (
          <Layout variant="landing">
            <TermsOfService />
          </Layout>
        )}
      </Route>
      <Route path="/data-policy">
        {() => (
          <Layout variant="landing">
            <DataPolicy />
          </Layout>
        )}
      </Route>
      <Route path="/cookies">
        {() => (
          <Layout variant="landing">
            <CookiesPolicy />
          </Layout>
        )}
      </Route>
      
      {/* Company pages */}
      <Route path="/company/about">
        {() => (
          <About />
        )}
      </Route>
      <Route path="/company/blog">
        {() => (
          <Blog />
        )}
      </Route>
      <Route path="/company/jobs">
        {() => (
          <Jobs />
        )}
      </Route>
      <Route path="/company/press">
        {() => (
          <Press />
        )}
      </Route>
      
      {/* Blog article pages */}
      <Route path="/blog/10-proven-strategies-to-boost-affiliate-review-conversions">
        {() => (
          <Article1 />
        )}
      </Route>
      
      {/* Product pages */}
      <Route path="/product/roadmap">
        {() => (
          <Roadmap />
        )}
      </Route>
      <Route path="/product/api">
        {() => (
          <API />
        )}
      </Route>
      
      {/* Support pages */}
      <Route path="/support/help-center">
        {() => (
          <HelpCenter />
        )}
      </Route>
      <Route path="/support/documentation">
        {() => (
          <Documentation />
        )}
      </Route>
      <Route path="/support/tutorials">
        {() => (
          <Tutorials />
        )}
      </Route>
      <Route path="/support/contact">
        {() => (
          <Contact />
        )}
      </Route>
      
      {/* Resource pages with landing variant Layout */}
      <Route path="/resources/seo-guide">
        {() => (
          <SeoGuide />
        )}
      </Route>
      <Route path="/resources/video-reviews">
        {() => (
          <VideoReviews />
        )}
      </Route>
      <Route path="/resources/analytics-dashboard">
        {() => (
          <AnalyticsDashboard />
        )}
      </Route>
      
      {/* Payment pages */}
      <Route path="/payment/basic">
        {() => (
          <Layout variant="landing">
            <BasicPlan />
          </Layout>
        )}
      </Route>
      <Route path="/payment/pro">
        {() => (
          <Layout variant="landing">
            <ProPlan />
          </Layout>
        )}
      </Route>
      <Route path="/payment/agency">
        {() => (
          <Layout variant="landing">
            <AgencyPlan />
          </Layout>
        )}
      </Route>
      <Route path="/payment/basic-annual">
        {() => (
          <Layout variant="landing">
            <BasicPlanAnnual />
          </Layout>
        )}
      </Route>
      <Route path="/payment/pro-annual">
        {() => (
          <Layout variant="landing">
            <ProPlanAnnual />
          </Layout>
        )}
      </Route>
      <Route path="/payment/agency-annual">
        {() => (
          <Layout variant="landing">
            <AgencyPlanAnnual />
          </Layout>
        )}
      </Route>
      
      {/* New unified payment system */}
      <Route path="/payment/plans">
        {() => (
          <Layout variant="landing">
            <PlanSelect />
          </Layout>
        )}
      </Route>
      <Route path="/payment/:cycle/:planId">
        {(params) => (
          <Layout variant="landing">
            <PaymentPage />
          </Layout>
        )}
      </Route>
      <Route path="/payment/success">
        {() => (
          <Layout variant="landing">
            <SuccessPage />
          </Layout>
        )}
      </Route>
      
      {/* New unified checkout flow */}
      <Route path="/checkout">
        {() => (
          <Layout variant="landing">
            <CombinedCheckoutPage />
          </Layout>
        )}
      </Route>
      <Route path="/checkout/:planType/:cycle">
        {(params) => (
          <Layout variant="landing">
            <CombinedCheckoutPage />
          </Layout>
        )}
      </Route>
      
      {/* Not Found page with landing variant Layout */}
      <Route>
        {() => (
          <Layout variant="landing">
            <NotFound />
          </Layout>
        )}
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
