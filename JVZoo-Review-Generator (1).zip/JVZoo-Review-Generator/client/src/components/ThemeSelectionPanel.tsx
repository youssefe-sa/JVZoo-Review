import { useState, useEffect, useRef } from "react";
import { REVIEW_THEMES, ThemeOption } from "@/lib/types";
import { ChevronDown, ChevronUp, Palette } from "lucide-react";

interface ThemeSelectionPanelProps {
  reviewTheme: string;
  updateFormData: (data: { reviewTheme: string }) => void;
}

export default function ThemeSelectionPanel({
  reviewTheme,
  updateFormData
}: ThemeSelectionPanelProps) {
  const [expanded, setExpanded] = useState(false);
  const [contentHeight, setContentHeight] = useState(0);
  const contentRef = useRef<HTMLDivElement>(null);
  
  // Update content height whenever expanded state changes
  useEffect(() => {
    // Using a timeout to ensure the DOM has updated
    const timer = setTimeout(() => {
      if (contentRef.current) {
        setContentHeight(contentRef.current.scrollHeight);
      }
    }, 10);
    
    return () => clearTimeout(timer);
  }, [contentRef, expanded, reviewTheme]);
  
  // Set the panel to be expanded by default on larger screens
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) { // lg breakpoint
        setExpanded(true);
      }
    };
    
    // Check on initial load
    handleResize();
    
    // Add event listener for resize
    window.addEventListener('resize', handleResize);
    
    // Cleanup
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  const handleThemeChange = (themeId: string) => {
    updateFormData({ reviewTheme: themeId });
  };
  
  const selectedTheme = REVIEW_THEMES.find(theme => theme.id === reviewTheme) || REVIEW_THEMES[0];
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div 
        className="p-5 border-b border-gray-100 flex justify-between items-center cursor-pointer
          hover:bg-gray-50 transition-colors duration-200"
        onClick={() => setExpanded(!expanded)}
        aria-expanded={expanded}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            setExpanded(!expanded);
            e.preventDefault();
          }
        }}
      >
        <div className="flex items-center">
          <Palette className="h-5 w-5 text-indigo-600 mr-2" />
          <h2 className="text-lg font-semibold text-gray-800">Review Theme</h2>
          {!expanded && (
            <span className="ml-2 text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">
              {selectedTheme.name}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-indigo-600 font-medium mr-1">
            {expanded ? 'Hide options' : 'Show options'}
          </span>
          <button 
            className="p-1 rounded-full hover:bg-indigo-100 transition-all text-indigo-600"
            aria-label={expanded ? "Collapse panel" : "Expand panel"}
            onClick={(e) => {
              e.stopPropagation();
              setExpanded(!expanded);
            }}
          >
            {expanded ? 
              <ChevronUp className="h-5 w-5" /> : 
              <ChevronDown className="h-5 w-5" />
            }
          </button>
        </div>
      </div>
      
      <div 
        ref={contentRef}
        style={{ 
          maxHeight: expanded ? `${contentHeight}px` : '0',
          opacity: expanded ? 1 : 0
        }}
        className="transition-all duration-300 ease-in-out overflow-hidden"
        aria-hidden={!expanded}
      >
        <div className="p-5 border-t border-gray-100">
          <div className="mb-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Selected Theme:</span>
              <span className="text-sm text-indigo-600 font-medium">{selectedTheme.name}</span>
            </div>
            <p className="text-xs text-gray-500 mt-1">{selectedTheme.description}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
            {REVIEW_THEMES.map((theme) => (
              <div 
                key={theme.id}
                onClick={() => handleThemeChange(theme.id)}
                className={`border p-3 rounded-lg cursor-pointer transition-all ${
                  reviewTheme === theme.id 
                    ? 'border-indigo-500 bg-indigo-50 shadow-sm transform scale-[1.02]' 
                    : 'border-gray-200 hover:border-indigo-300 hover:bg-gray-50 hover:shadow-sm hover:scale-[1.01]'
                } relative`}
              >
                {reviewTheme === theme.id && (
                  <div className="absolute top-1 right-1 bg-indigo-500 text-white text-[10px] px-1.5 py-0.5 rounded-full font-medium">
                    Active
                  </div>
                )}
                
                <div className="flex items-start">
                  <div className={`w-4 h-4 rounded-full flex-shrink-0 mt-0.5 ${
                    reviewTheme === theme.id 
                      ? 'bg-indigo-600 ring-2 ring-indigo-200' 
                      : 'border-2 border-gray-300'
                  }`}>
                    {reviewTheme === theme.id && (
                      <div className="h-full flex items-center justify-center">
                        <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
                      </div>
                    )}
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium">
                      {theme.name}
                    </h3>
                    <p className="text-xs text-gray-500 mt-0.5">{theme.description}</p>
                  </div>
                </div>
                
                {/* Theme preview visualization */}
                <div className={`mt-3 h-16 rounded-md overflow-hidden ${
                  reviewTheme === theme.id ? 'ring-2 ring-indigo-300' : ''
                }`}>
                  {/* Theme Visualization */}
                  {theme.id === 'classic' && (
                    <div className="h-full w-full bg-gradient-to-br from-gray-50 to-gray-100 p-1 flex flex-col">
                      <div className="w-full h-1/4 bg-indigo-600 rounded-sm mb-1" />
                      <div className="w-3/4 h-1/4 bg-indigo-500 rounded-sm mb-1" />
                      <div className="w-2/3 h-1/4 bg-indigo-400 rounded-sm" />
                      <div className="flex justify-between mt-1">
                        <div className="w-1/5 h-2 bg-indigo-600 rounded-sm" />
                        <div className="w-1/5 h-2 bg-indigo-600 rounded-sm" />
                        <div className="w-1/5 h-2 bg-indigo-600 rounded-sm" />
                      </div>
                    </div>
                  )}
                  
                  {theme.id === 'modern' && (
                    <div className="h-full w-full bg-gradient-to-r from-purple-50 to-indigo-50 p-1 flex flex-col">
                      <div className="flex h-1/3 w-full gap-1 mb-1">
                        <div className="w-1/4 bg-purple-500 rounded-sm" />
                        <div className="w-3/4 bg-gradient-to-r from-pink-500 to-indigo-500 rounded-sm" />
                      </div>
                      <div className="h-1/3 w-full bg-white rounded-sm mb-1 flex items-center justify-center">
                        <div className="w-2/3 h-1/2 bg-blue-100 rounded-sm" />
                      </div>
                      <div className="flex justify-between h-1/4">
                        <div className="w-1/3 bg-pink-300 rounded-sm" />
                        <div className="w-1/3 bg-indigo-300 rounded-sm" />
                      </div>
                    </div>
                  )}
                  
                  {theme.id === 'minimal' && (
                    <div className="h-full w-full bg-white p-1 flex flex-col">
                      <div className="w-full h-1/4 bg-gray-800 rounded-sm mb-1" />
                      <div className="w-3/4 h-1/4 bg-gray-600 rounded-sm mb-1" />
                      <div className="flex justify-between mt-1 gap-1">
                        <div className="w-2/3 h-4 bg-gray-200 rounded-sm" />
                        <div className="w-1/3 h-4 bg-gray-800 rounded-sm" />
                      </div>
                    </div>
                  )}
                  
                  {theme.id === 'premium' && (
                    <div className="h-full w-full bg-gradient-to-br from-yellow-50 to-gray-50 p-1 flex flex-col">
                      <div className="w-full h-1/4 bg-gradient-to-r from-yellow-600 to-yellow-400 rounded-sm mb-1" />
                      <div className="flex h-1/2 gap-1">
                        <div className="w-2/3 bg-gray-100 rounded-sm p-0.5">
                          <div className="w-full h-1/2 bg-gray-700 rounded-sm" />
                        </div>
                        <div className="w-1/3 bg-yellow-100 rounded-sm flex items-center justify-center">
                          <div className="w-3/4 h-3/4 bg-yellow-500 rounded-full" />
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {theme.id === 'comparison' && (
                    <div className="h-full w-full bg-white p-1 flex flex-col">
                      <div className="w-full h-1/3 flex">
                        <div className="w-1/2 bg-green-100 flex items-center justify-center">
                          <div className="w-3/4 h-2/3 bg-green-600 rounded-sm" />
                        </div>
                        <div className="w-1/2 bg-red-100 flex items-center justify-center">
                          <div className="w-3/4 h-2/3 bg-red-500 rounded-sm" />
                        </div>
                      </div>
                      <div className="flex justify-between mt-1 gap-1">
                        <div className="w-1/2 h-6 bg-green-200 rounded-sm flex items-center justify-center">
                          <div className="w-3/4 h-1/2 bg-green-600 rounded-sm" />
                        </div>
                        <div className="w-1/2 h-6 bg-red-200 rounded-sm flex items-center justify-center">
                          <div className="w-3/4 h-1/2 bg-red-500 rounded-sm" />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-4 pt-3 border-t border-gray-200">
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 bg-indigo-500 rounded-full animate-pulse"></div>
              <p className="text-xs text-gray-600">
                <span className="font-medium">Theme Preview: </span>
                <span className="text-gray-500">
                  The selected theme affects typography, colors, spacing, and overall visual style of your generated review.
                </span>
              </p>
            </div>
            <div className="flex justify-end mt-2">
              <button 
                onClick={() => handleThemeChange(reviewTheme)} 
                className="inline-flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-800 transition-colors"
              >
                <span>Apply Theme</span>
                <ChevronDown className="h-3 w-3 rotate-[270deg]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}