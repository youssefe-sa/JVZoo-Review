import { useState, useEffect, useRef } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronUp, Settings, StarIcon } from "lucide-react";

interface AdvancedFeaturesPanelProps {
  includeComparisonTable: boolean;
  competingProducts: string;
  includeTestimonials: boolean;
  includeProductRating: boolean;
  productRatingScore: string;
  includeBonusSection: boolean;
  bonusContent: string;
  updateFormData: (data: Partial<{
    includeComparisonTable: boolean;
    competingProducts: string;
    includeTestimonials: boolean;
    includeProductRating: boolean;
    productRatingScore: string;
    includeBonusSection: boolean;
    bonusContent: string;
  }>) => void;
}

export default function AdvancedFeaturesPanel({
  includeComparisonTable,
  competingProducts,
  includeTestimonials,
  includeProductRating,
  productRatingScore,
  includeBonusSection,
  bonusContent,
  updateFormData
}: AdvancedFeaturesPanelProps) {
  const [expanded, setExpanded] = useState(false);
  const [contentHeight, setContentHeight] = useState(0);
  const contentRef = useRef<HTMLDivElement>(null);
  
  // Count number of enabled features for the badge
  const enabledFeaturesCount = [
    includeComparisonTable,
    includeTestimonials,
    includeProductRating,
    includeBonusSection
  ].filter(Boolean).length;
  
  // Update content height whenever expanded state changes
  useEffect(() => {
    const timer = setTimeout(() => {
      if (contentRef.current) {
        setContentHeight(contentRef.current.scrollHeight);
      }
    }, 10);
    
    return () => clearTimeout(timer);
  }, [expanded, includeComparisonTable, includeTestimonials, includeProductRating, 
      includeBonusSection, competingProducts, bonusContent, productRatingScore]);
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div 
        className="p-5 border-b border-gray-100 flex justify-between items-center cursor-pointer
          hover:bg-gray-50 transition-colors duration-200"
        onClick={() => setExpanded(!expanded)}
        aria-expanded={expanded}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            setExpanded(!expanded);
            e.preventDefault();
          }
        }}
      >
        <div className="flex items-center">
          <Settings className="h-5 w-5 text-indigo-600 mr-2" />
          <h2 className="text-lg font-semibold text-gray-800">Advanced Features</h2>
          <Badge variant="secondary" className="ml-2 bg-indigo-100 text-indigo-800 hover:bg-indigo-200">PRO</Badge>
          {!expanded && enabledFeaturesCount > 0 && (
            <span className="ml-2 text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">
              {enabledFeaturesCount} feature{enabledFeaturesCount > 1 ? 's' : ''} enabled
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-indigo-600 font-medium mr-1">
            {expanded ? 'Hide options' : 'Show options'}
          </span>
          <button 
            className="p-1 rounded-full hover:bg-indigo-100 transition-all text-indigo-600"
            aria-label={expanded ? "Collapse panel" : "Expand panel"}
            onClick={(e) => {
              e.stopPropagation();
              setExpanded(!expanded);
            }}
          >
            {expanded ? 
              <ChevronUp className="h-5 w-5" /> : 
              <ChevronDown className="h-5 w-5" />
            }
          </button>
        </div>
      </div>
      
      <div 
        ref={contentRef}
        style={{ 
          maxHeight: expanded ? `${contentHeight}px` : '0',
          opacity: expanded ? 1 : 0
        }}
        className="transition-all duration-300 ease-in-out overflow-hidden"
      >
        <div className="p-5 border-t border-gray-100">
          <div className="space-y-4">
            {/* Product Rating */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <div>
                  <span className="text-sm font-medium text-gray-700">Product Rating</span>
                  <p className="text-xs text-gray-500 mt-0.5">Display an eye-catching rating score</p>
                </div>
                <div className="relative inline-block w-10 align-middle select-none">
                  <input 
                    type="checkbox" 
                    name="includeProductRating" 
                    id="includeProductRating" 
                    className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                    checked={includeProductRating}
                    onChange={(e) => updateFormData({ includeProductRating: e.target.checked })}
                    style={{ 
                      right: includeProductRating ? '0' : 'auto',
                      borderColor: includeProductRating ? '#4F46E5' : 'transparent'
                    }}
                  />
                  <label 
                    htmlFor="includeProductRating" 
                    className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                    style={{ backgroundColor: includeProductRating ? '#4F46E5' : '#D1D5DB' }}
                  ></label>
                </div>
              </div>
              
              {includeProductRating && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {['1.0', '2.0', '3.0', '4.0', '4.5', '5.0'].map((rating) => (
                    <button
                      key={rating}
                      type="button"
                      onClick={() => updateFormData({ productRatingScore: rating })}
                      className={`py-1 px-2 text-xs font-medium rounded-md ${
                        productRatingScore === rating 
                          ? 'bg-indigo-100 text-indigo-700 border border-indigo-300' 
                          : 'bg-gray-100 text-gray-700 border border-gray-200 hover:bg-gray-200'
                      }`}
                    >
                      {rating}
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            {/* Product Comparison Table */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <div>
                  <span className="text-sm font-medium text-gray-700">Comparison Table</span>
                  <p className="text-xs text-gray-500 mt-0.5">Compare with competing products</p>
                </div>
                <div className="relative inline-block w-10 align-middle select-none">
                  <input 
                    type="checkbox" 
                    name="includeComparisonTable" 
                    id="includeComparisonTable" 
                    className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                    checked={includeComparisonTable}
                    onChange={(e) => updateFormData({ includeComparisonTable: e.target.checked })}
                    style={{ 
                      right: includeComparisonTable ? '0' : 'auto',
                      borderColor: includeComparisonTable ? '#4F46E5' : 'transparent'
                    }}
                  />
                  <label 
                    htmlFor="includeComparisonTable" 
                    className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                    style={{ backgroundColor: includeComparisonTable ? '#4F46E5' : '#D1D5DB' }}
                  ></label>
                </div>
              </div>
              
              {includeComparisonTable && (
                <div className="mt-2">
                  <label htmlFor="competingProducts" className="block text-xs font-medium text-gray-700 mb-1">
                    Competing Products
                  </label>
                  <Textarea
                    id="competingProducts"
                    value={competingProducts}
                    onChange={(e) => updateFormData({ competingProducts: e.target.value })}
                    placeholder="Product A, Product B, Product C"
                    className="resize-none text-sm"
                    rows={2}
                  />
                  <p className="text-xs text-gray-500 mt-1">List competing products, separated by commas</p>
                </div>
              )}
            </div>
            
            {/* Include Testimonials */}
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm font-medium text-gray-700">Include Testimonials</span>
                <p className="text-xs text-gray-500 mt-0.5">Add social proof (AI-generated)</p>
              </div>
              <div className="relative inline-block w-10 align-middle select-none">
                <input 
                  type="checkbox" 
                  name="includeTestimonials" 
                  id="includeTestimonials" 
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                  checked={includeTestimonials}
                  onChange={(e) => updateFormData({ includeTestimonials: e.target.checked })}
                  style={{ 
                    right: includeTestimonials ? '0' : 'auto',
                    borderColor: includeTestimonials ? '#4F46E5' : 'transparent'
                  }}
                />
                <label 
                  htmlFor="includeTestimonials" 
                  className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                  style={{ backgroundColor: includeTestimonials ? '#4F46E5' : '#D1D5DB' }}
                ></label>
              </div>
            </div>
            
            {/* Special Bonus Section */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <div>
                  <span className="text-sm font-medium text-gray-700">Special Bonus Section</span>
                  <p className="text-xs text-gray-500 mt-0.5">Include exclusive bonuses for readers</p>
                </div>
                <div className="relative inline-block w-10 align-middle select-none">
                  <input 
                    type="checkbox" 
                    name="includeBonusSection" 
                    id="includeBonusSection" 
                    className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer right-0" 
                    checked={includeBonusSection}
                    onChange={(e) => updateFormData({ includeBonusSection: e.target.checked })}
                    style={{ 
                      right: includeBonusSection ? '0' : 'auto',
                      borderColor: includeBonusSection ? '#4F46E5' : 'transparent'
                    }}
                  />
                  <label 
                    htmlFor="includeBonusSection" 
                    className="toggle-label block overflow-hidden h-6 rounded-full cursor-pointer"
                    style={{ backgroundColor: includeBonusSection ? '#4F46E5' : '#D1D5DB' }}
                  ></label>
                </div>
              </div>
              
              {includeBonusSection && (
                <div className="mt-2">
                  <label htmlFor="bonusContent" className="block text-xs font-medium text-gray-700 mb-1">
                    Bonus Description
                  </label>
                  <Textarea
                    id="bonusContent"
                    value={bonusContent}
                    onChange={(e) => updateFormData({ bonusContent: e.target.value })}
                    placeholder="Describe the exclusive bonuses you're offering..."
                    className="resize-none text-sm"
                    rows={3}
                  />
                </div>
              )}
            </div>
          </div>
          
          <div className="mt-4 bg-gradient-to-r from-indigo-50 to-purple-50 p-3 rounded-lg">
            <p className="text-xs text-indigo-800">
              <span className="font-semibold">Pro Tip:</span> Including comparisons, testimonials, and special bonuses can significantly increase conversion rates.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}