import React, { useState } from 'react';
import { Helmet } from "react-helmet";
import Layout from "@/components/Layout";
import { Search, Book, Layers, Database, Code, Settings, ArrowRight, ChevronRight, ExternalLink } from "lucide-react";

export default function Documentation() {
  const [searchQuery, setSearchQuery] = useState("");
  
  // Documentation categories
  const docCategories = [
    {
      title: "User Guide",
      icon: <Book className="h-6 w-6 text-indigo-600" />,
      description: "Comprehensive guides for using ReviewPro features",
      sections: [
        { title: "Getting Started", link: "#" },
        { title: "Review Creation", link: "#" },
        { title: "Templates", link: "#" },
        { title: "SEO Optimization", link: "#" },
        { title: "Publishing", link: "#" }
      ]
    },
    {
      title: "API Reference",
      icon: <Code className="h-6 w-6 text-indigo-600" />,
      description: "Technical documentation for developers",
      sections: [
        { title: "Authentication", link: "#" },
        { title: "Endpoints", link: "#" },
        { title: "Response Formats", link: "#" },
        { title: "Rate Limits", link: "#" },
        { title: "Error Handling", link: "#" }
      ]
    },
    {
      title: "Integrations",
      icon: <Layers className="h-6 w-6 text-indigo-600" />,
      description: "Connect ReviewPro with other platforms",
      sections: [
        { title: "WordPress Plugin", link: "#" },
        { title: "Medium Integration", link: "#" },
        { title: "Shopify App", link: "#" },
        { title: "Wix Integration", link: "#" },
        { title: "Custom CMS Connections", link: "#" }
      ]
    },
    {
      title: "Data Management",
      icon: <Database className="h-6 w-6 text-indigo-600" />,
      description: "Manage your content and data within ReviewPro",
      sections: [
        { title: "Content Organization", link: "#" },
        { title: "Import/Export", link: "#" },
        { title: "Data Backup", link: "#" },
        { title: "Template Management", link: "#" },
        { title: "Bulk Operations", link: "#" }
      ]
    },
    {
      title: "Account Administration",
      icon: <Settings className="h-6 w-6 text-indigo-600" />,
      description: "Manage your account, team, and billing",
      sections: [
        { title: "User Management", link: "#" },
        { title: "Permissions", link: "#" },
        { title: "Billing & Subscriptions", link: "#" },
        { title: "Security", link: "#" },
        { title: "API Key Management", link: "#" }
      ]
    }
  ];
  
  // Documentation articles
  const popularDocs = [
    {
      title: "Complete Guide to Review Templates",
      description: "Learn how to create, customize, and save templates for different product categories",
      category: "User Guide",
      lastUpdated: "2 weeks ago",
      link: "#"
    },
    {
      title: "WordPress Integration Setup",
      description: "Step-by-step guide to connecting ReviewPro with your WordPress site",
      category: "Integrations",
      lastUpdated: "1 month ago",
      link: "#"
    },
    {
      title: "API Authentication Guide",
      description: "Learn how to authenticate API requests and manage API keys",
      category: "API Reference",
      lastUpdated: "3 weeks ago",
      link: "#"
    },
    {
      title: "Team Collaboration Best Practices",
      description: "Tips for effectively managing multi-user workflows",
      category: "Account Administration",
      lastUpdated: "2 months ago",
      link: "#"
    }
  ];
  
  // Resources
  const resources = [
    {
      title: "ReviewPro Academy",
      description: "Free courses and video tutorials to master ReviewPro",
      icon: <Book className="h-6 w-6 text-white" />,
      link: "#",
      linkText: "Start Learning"
    },
    {
      title: "Developer Hub",
      description: "SDK documentation, code samples, and API tools",
      icon: <Code className="h-6 w-6 text-white" />,
      link: "#",
      linkText: "Explore APIs"
    },
    {
      title: "Community Forum",
      description: "Connect with other users and share best practices",
      icon: <Layers className="h-6 w-6 text-white" />,
      link: "#",
      linkText: "Join Discussion"
    }
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real implementation, this would search through documentation
    console.log("Searching for:", searchQuery);
  };

  return (
    <Layout variant="landing">
      <Helmet>
        <title>Documentation | ReviewPro</title>
        <meta name="description" content="Comprehensive documentation for ReviewPro features, API, and integrations. Learn how to use the platform effectively." />
      </Helmet>
      
      <div className="bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Documentation Header */}
          <div className="text-center">
            <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl lg:text-5xl">Documentation</h1>
            <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
              Comprehensive guides and references for using ReviewPro
            </p>
          </div>
          
          {/* Search Bar */}
          <div className="mt-12 max-w-3xl mx-auto">
            <form onSubmit={handleSearch} className="sm:flex">
              <div className="min-w-0 flex-1">
                <label htmlFor="search" className="sr-only">Search documentation</label>
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    id="search"
                    className="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 pr-12 py-4 sm:text-lg border-gray-300 rounded-md"
                    placeholder="Search documentation..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              <div className="mt-3 sm:mt-0 sm:ml-3">
                <button
                  type="submit"
                  className="block w-full rounded-md border border-transparent px-5 py-4 bg-indigo-600 text-base font-medium text-white shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:px-10"
                >
                  Search
                </button>
              </div>
            </form>
          </div>
          
          {/* Documentation Categories */}
          <div className="mt-24">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">Documentation Categories</h2>
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {docCategories.map((category, index) => (
                <div key={index} className="bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden hover:shadow-xl transition-shadow duration-300">
                  <div className="p-6">
                    <div className="flex items-center mb-4">
                      <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                        {category.icon}
                      </div>
                      <h3 className="ml-4 text-xl font-semibold text-gray-900">{category.title}</h3>
                    </div>
                    <p className="text-gray-600 mb-6">{category.description}</p>
                    <ul className="space-y-3 text-gray-700">
                      {category.sections.map((section, idx) => (
                        <li key={idx} className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-indigo-500 flex-shrink-0 mt-0.5" />
                          <a href={section.link} className="ml-2 hover:text-indigo-600">
                            {section.title}
                          </a>
                        </li>
                      ))}
                    </ul>
                    <div className="mt-6">
                      <a
                        href="#"
                        className="inline-flex items-center text-indigo-600 hover:text-indigo-500 font-medium"
                      >
                        Explore {category.title}
                        <ArrowRight className="ml-1 h-4 w-4" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Popular Documentation */}
          <div className="mt-24">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">Popular Documentation</h2>
            <div className="grid gap-6 md:grid-cols-2">
              {popularDocs.map((doc, index) => (
                <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-100">
                  <div className="p-6">
                    <div className="flex justify-between items-start">
                      <h3 className="text-lg font-semibold text-gray-900">{doc.title}</h3>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                        {doc.category}
                      </span>
                    </div>
                    <p className="mt-2 text-gray-600">{doc.description}</p>
                    <div className="mt-4 flex justify-between items-center">
                      <span className="text-sm text-gray-500">Updated {doc.lastUpdated}</span>
                      <a
                        href={doc.link}
                        className="inline-flex items-center text-indigo-600 hover:text-indigo-500 text-sm font-medium"
                      >
                        Read more
                        <ArrowRight className="ml-1 h-4 w-4" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Documentation Resources */}
          <div className="mt-24">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">Learning Resources</h2>
            <div className="grid gap-6 md:grid-cols-3">
              {resources.map((resource, index) => (
                <div key={index} className="bg-indigo-700 rounded-lg shadow-xl overflow-hidden text-white">
                  <div className="p-6">
                    <div className="flex items-center mb-4">
                      <div className="h-12 w-12 bg-indigo-800 rounded-lg flex items-center justify-center">
                        {resource.icon}
                      </div>
                      <h3 className="ml-4 text-xl font-semibold">{resource.title}</h3>
                    </div>
                    <p className="text-indigo-200 mb-6">{resource.description}</p>
                    <a
                      href={resource.link}
                      className="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-white hover:bg-indigo-50"
                    >
                      {resource.linkText}
                      <ExternalLink className="ml-2 h-4 w-4" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Full Documentation Links */}
          <div className="mt-24">
            <div className="bg-gray-50 rounded-lg p-8 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Complete Documentation Index</h2>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <div>
                  <h3 className="font-medium text-indigo-600 mb-3">User Guide</h3>
                  <ul className="space-y-2 text-sm">
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Product Overview</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Dashboard Guide</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Review Creation</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Templates</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">SEO Tools</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Publishing</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Analytics</a></li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-medium text-indigo-600 mb-3">Integrations</h3>
                  <ul className="space-y-2 text-sm">
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">WordPress</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Medium</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Shopify</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Wix</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Custom CMS</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Social Media</a></li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-medium text-indigo-600 mb-3">API Reference</h3>
                  <ul className="space-y-2 text-sm">
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Getting Started</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Authentication</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Reviews API</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Templates API</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">SEO API</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">User API</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Webhooks</a></li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-medium text-indigo-600 mb-3">Administration</h3>
                  <ul className="space-y-2 text-sm">
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Account Settings</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">User Management</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Billing & Plans</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">API Keys</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Security</a></li>
                    <li><a href="#" className="text-gray-600 hover:text-indigo-600">Data Management</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          
          {/* Documentation Feedback */}
          <div className="mt-24 bg-indigo-50 rounded-lg py-12 px-6 sm:py-16 sm:px-12 text-center">
            <h2 className="text-3xl font-extrabold tracking-tight text-gray-900">
              Was this documentation helpful?
            </h2>
            <p className="mt-4 max-w-3xl mx-auto text-lg text-gray-500">
              We're constantly improving our documentation. Your feedback helps us make it better.
            </p>
            <div className="mt-8 flex justify-center space-x-4">
              <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                Yes, it was helpful
              </button>
              <button className="inline-flex items-center px-6 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                No, it needs improvement
              </button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}