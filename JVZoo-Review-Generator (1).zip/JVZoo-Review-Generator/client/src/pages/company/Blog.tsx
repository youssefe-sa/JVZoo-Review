import React from 'react';
import { Helmet } from "react-helmet";
import Layout from "@/components/Layout";
import { Link } from "wouter";
import { Calendar, Clock, ChevronRight, User } from "lucide-react";

export default function Blog() {
  // Sample articles data
  const articles = [
    {
      id: 1,
      title: "10 Proven Strategies to Boost Affiliate Review Conversions",
      excerpt: "Learn the top strategies that successful affiliate marketers use to create high-converting product reviews that drive more sales and commissions.",
      imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1115&q=80",
      date: "March 15, 2023",
      readTime: "8 min read",
      author: "Michael Bennett",
      authorImage: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80",
      category: "Affiliate Marketing",
      featured: true,
      slug: "10-proven-strategies-to-boost-affiliate-review-conversions"
    },
    {
      id: 2,
      title: "How AI is Revolutionizing Product Review Creation",
      excerpt: "Explore how artificial intelligence is transforming the way marketers create product reviews, saving time while improving quality and conversion rates.",
      imageUrl: "https://images.unsplash.com/photo-1555255707-c07966088b7b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      date: "April 22, 2023",
      readTime: "6 min read",
      author: "Sarah Chen",
      authorImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=761&q=80",
      category: "AI Technology",
      featured: true,
      slug: "how-ai-is-revolutionizing-product-review-creation"
    },
    {
      id: 3,
      title: "The Future of SEO for Product Reviews in 2023 and Beyond",
      excerpt: "Stay ahead of the curve with our comprehensive analysis of emerging SEO trends specifically for product reviews, including structured data, E-A-T principles, and more.",
      imageUrl: "https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1174&q=80",
      date: "May 10, 2023",
      readTime: "10 min read",
      author: "Alex Johnson",
      authorImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
      category: "SEO",
      featured: false,
      slug: "future-of-seo-for-product-reviews"
    }
  ];

  // Featured articles (max 2)
  const featuredArticles = articles.filter(article => article.featured).slice(0, 2);
  
  // Regular articles (all articles)
  const regularArticles = articles;

  return (
    <Layout variant="landing">
      <Helmet>
        <title>Blog | ReviewPro</title>
        <meta name="description" content="Latest insights, strategies, and tips on creating high-converting product reviews and optimizing your affiliate marketing content." />
      </Helmet>
      
      <div className="bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl lg:text-5xl">ReviewPro Blog</h1>
            <p className="mt-4 max-w-3xl mx-auto text-xl text-gray-500">
              Insights, strategies, and tips for creating better product reviews
            </p>
          </div>
          
          {/* Featured Articles Section */}
          {featuredArticles.length > 0 && (
            <div className="mt-16">
              <h2 className="text-2xl font-bold text-gray-900 mb-8">Featured Articles</h2>
              <div className="grid gap-8 lg:grid-cols-2">
                {featuredArticles.map((article) => (
                  <div key={article.id} className="bg-white rounded-lg shadow-xl overflow-hidden transition-all duration-300 hover:shadow-2xl">
                    <div className="h-64 overflow-hidden">
                      <img
                        src={article.imageUrl}
                        alt={article.title}
                        className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                      />
                    </div>
                    <div className="p-6">
                      <div className="flex items-center text-sm text-indigo-600 mb-2">
                        <span className="px-3 py-1 bg-indigo-100 rounded-full">{article.category}</span>
                      </div>
                      <Link href={`/blog/${article.slug}`}>
                        <a className="block mt-2">
                          <h3 className="text-xl font-semibold text-gray-900 hover:text-indigo-600 transition-colors duration-200">
                            {article.title}
                          </h3>
                        </a>
                      </Link>
                      <p className="mt-3 text-base text-gray-500">
                        {article.excerpt}
                      </p>
                      <div className="mt-6 flex items-center">
                        <div className="flex-shrink-0">
                          <img
                            className="h-10 w-10 rounded-full"
                            src={article.authorImage}
                            alt={article.author}
                          />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">{article.author}</p>
                          <div className="flex space-x-4 text-sm text-gray-500">
                            <span className="flex items-center">
                              <Calendar className="h-4 w-4 mr-1" />
                              {article.date}
                            </span>
                            <span className="flex items-center">
                              <Clock className="h-4 w-4 mr-1" />
                              {article.readTime}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="mt-6">
                        <Link href={`/blog/${article.slug}`}>
                          <a className="text-indigo-600 hover:text-indigo-500 font-medium flex items-center">
                            Read more <ChevronRight className="h-4 w-4 ml-1" />
                          </a>
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* All Articles Section */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">Latest Articles</h2>
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {regularArticles.map((article) => (
                <div key={article.id} className="bg-white rounded-lg shadow-lg overflow-hidden transition-all duration-300 hover:shadow-xl">
                  <div className="h-48 overflow-hidden">
                    <img
                      src={article.imageUrl}
                      alt={article.title}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex items-center text-sm text-indigo-600 mb-2">
                      <span className="px-2 py-0.5 bg-indigo-100 rounded-full text-xs">{article.category}</span>
                    </div>
                    <Link href={`/blog/${article.slug}`}>
                      <a className="block mt-2">
                        <h3 className="text-lg font-semibold text-gray-900 hover:text-indigo-600 transition-colors duration-200">
                          {article.title}
                        </h3>
                      </a>
                    </Link>
                    <p className="mt-3 text-sm text-gray-500 line-clamp-3">
                      {article.excerpt}
                    </p>
                    <div className="mt-4 flex items-center justify-between">
                      <div className="flex items-center">
                        <img
                          className="h-8 w-8 rounded-full"
                          src={article.authorImage}
                          alt={article.author}
                        />
                        <span className="ml-2 text-xs text-gray-700">{article.author}</span>
                      </div>
                      <div className="text-xs text-gray-500 flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        {article.date}
                      </div>
                    </div>
                    <div className="mt-4">
                      <Link href={`/blog/${article.slug}`}>
                        <a className="text-indigo-600 hover:text-indigo-500 text-sm font-medium flex items-center">
                          Read more <ChevronRight className="h-3 w-3 ml-1" />
                        </a>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Newsletter Section */}
          <div className="mt-24 bg-indigo-700 rounded-lg py-12 px-6 sm:py-16 sm:px-12 text-center">
            <h2 className="text-3xl font-extrabold text-white tracking-tight">
              Subscribe to our newsletter
            </h2>
            <p className="mt-4 max-w-3xl mx-auto text-lg text-indigo-100">
              Get the latest insights on affiliate marketing, SEO, and product review creation delivered to your inbox.
            </p>
            <div className="mt-8 sm:mx-auto sm:max-w-lg">
              <form action="#" method="POST" className="sm:flex">
                <div className="min-w-0 flex-1">
                  <label htmlFor="email" className="sr-only">Email address</label>
                  <input 
                    id="email" 
                    type="email" 
                    placeholder="Your email address" 
                    className="block w-full px-4 py-3 rounded-md border-0 text-base text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-300 focus:border-indigo-300"
                  />
                </div>
                <div className="mt-3 sm:mt-0 sm:ml-3">
                  <button 
                    type="submit" 
                    className="block w-full rounded-md border border-transparent px-4 py-3 bg-indigo-500 text-base font-medium text-white shadow hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-indigo-700 sm:px-10"
                  >
                    Subscribe
                  </button>
                </div>
              </form>
              <p className="mt-3 text-sm text-indigo-100">
                We care about your data. Read our <a href="/privacy" className="font-medium text-white underline">Privacy Policy</a>.
              </p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}