import React from 'react';
import Header from './Header';
import Footer from './Footer';
import LandingHeader from './LandingHeader';
import LandingFooter from './LandingFooter';

interface LayoutProps {
  children: React.ReactNode;
  hideHeader?: boolean;
  hideFooter?: boolean;
  variant?: 'app' | 'landing';
}

export default function Layout({ 
  children, 
  hideHeader = false, 
  hideFooter = false, 
  variant = 'landing' 
}: LayoutProps) {
  return (
    <div className="flex flex-col min-h-screen">
      {!hideHeader && variant === 'app' && <Header />}
      {!hideHeader && variant === 'landing' && <LandingHeader />}
      
      <main className="flex-grow">
        {children}
      </main>
      
      {!hideFooter && variant === 'app' && <Footer />}
      {!hideFooter && variant === 'landing' && <LandingFooter />}
    </div>
  );
}