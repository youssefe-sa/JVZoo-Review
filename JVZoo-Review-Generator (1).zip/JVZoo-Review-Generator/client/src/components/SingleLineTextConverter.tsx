import { useState } from 'react';
import { convertToSingleLine } from '@/lib/textUtils';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

export default function SingleLineTextConverter() {
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const { toast } = useToast();

  const handleConvert = () => {
    if (!inputText) {
      toast({
        title: 'No text provided',
        description: 'Please enter some text to convert',
        variant: 'destructive',
      });
      return;
    }

    const result = convertToSingleLine(inputText);
    setOutputText(result);
  };

  const handleCopyToClipboard = () => {
    if (!outputText) {
      toast({
        title: 'Nothing to copy',
        description: 'Please convert some text first',
        variant: 'destructive',
      });
      return;
    }

    navigator.clipboard.writeText(outputText)
      .then(() => {
        toast({
          title: 'Copied!',
          description: 'Text copied to clipboard',
        });
      })
      .catch(() => {
        toast({
          title: 'Copy failed',
          description: 'Could not copy text to clipboard',
          variant: 'destructive',
        });
      });
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="bg-indigo-600 text-white">
        <CardTitle className="flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 mr-2">
            <path d="M21 15V6m0 0H2m19 0l-7 4.5M21 18H2m0-3V6m0 0l7 4.5M2 18l7-4.5m5 0V6m0 12V13.5" />
          </svg>
          SEO Optimization - Single Line Text Converter
        </CardTitle>
        <CardDescription className="text-indigo-100">
          Convert multi-line text to a single line for better SEO and metadata
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4 pt-6">
        <div className="space-y-2">
          <Label htmlFor="input-text">Input Text (with line breaks)</Label>
          <Textarea
            id="input-text"
            placeholder="Enter your multi-line text here..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            rows={6}
            className="resize-none font-mono text-sm"
          />
        </div>
        <div className="space-y-2">
          <div className="flex justify-between">
            <Label htmlFor="output-text">Single Line Output</Label>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleCopyToClipboard}
              disabled={!outputText}
              className="text-xs h-6 px-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3.5 w-3.5 mr-1">
                <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
                <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
              </svg>
              Copy
            </Button>
          </div>
          <Textarea
            id="output-text"
            placeholder="Single line output will appear here..."
            value={outputText}
            readOnly
            rows={3}
            className="resize-none font-mono text-sm bg-gray-50"
          />
        </div>
      </CardContent>
      <CardFooter className="justify-between">
        <p className="text-xs text-gray-500">Perfect for meta descriptions, alt tags, and titles</p>
        <Button onClick={handleConvert} className="bg-indigo-600 hover:bg-indigo-700">
          Convert to Single Line
        </Button>
      </CardFooter>
    </Card>
  );
}