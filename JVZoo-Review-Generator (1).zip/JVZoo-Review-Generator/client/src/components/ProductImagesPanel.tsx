import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";
import { 
  AlertCircle, ExternalLink, Image, Info, Plus, X, 
  Check, ArrowUpDown, Layout, AlignCenter, Trash2
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

interface ProductImage {
  url: string;
  caption: string;
  altText: string;
  position: "header" | "introduction" | "features" | "prosCons" | "pricing" | "caseStudy" | "conclusion" | "galleryOnly";
  size: "small" | "medium" | "large" | "fullWidth";
  alignment: "left" | "center" | "right";
  style: "noBorder" | "standard" | "shadow" | "rounded";
}

interface ProductImagesPanelProps {
  productImages: ProductImage[];
  updateProductImages: (images: ProductImage[]) => void;
}

export default function ProductImagesPanel({ 
  productImages = [], 
  updateProductImages 
}: ProductImagesPanelProps) {
  const [currentURL, setCurrentURL] = useState("");
  const [currentCaption, setCurrentCaption] = useState("");
  const [currentAltText, setCurrentAltText] = useState("");
  const [currentPosition, setCurrentPosition] = useState<ProductImage["position"]>("features");
  const [currentSize, setCurrentSize] = useState<ProductImage["size"]>("medium");
  const [currentAlignment, setCurrentAlignment] = useState<ProductImage["alignment"]>("center");
  const [currentStyle, setCurrentStyle] = useState<ProductImage["style"]>("standard");
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [batchURLs, setBatchURLs] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handlePreview = () => {
    if (!currentURL) {
      setError("Please enter an image URL");
      setPreviewImage(null);
      return;
    }

    // Check if URL is valid
    try {
      new URL(currentURL);
      setPreviewImage(currentURL);
      setError(null);
    } catch (e) {
      setError("Please enter a valid URL");
      setPreviewImage(null);
    }
  };

  const handleAddImage = () => {
    if (!currentURL) {
      setError("Please enter an image URL");
      return;
    }

    try {
      new URL(currentURL);
      
      const newImage: ProductImage = {
        url: currentURL,
        caption: currentCaption,
        altText: currentAltText || currentCaption || "Product image",
        position: currentPosition,
        size: currentSize,
        alignment: currentAlignment,
        style: currentStyle
      };

      updateProductImages([...productImages, newImage]);
      
      // Reset form
      setCurrentURL("");
      setCurrentCaption("");
      setCurrentAltText("");
      setPreviewImage(null);
      setError(null);
    } catch (e) {
      setError("Please enter a valid URL");
    }
  };

  const handleRemoveImage = (index: number) => {
    const updatedImages = [...productImages];
    updatedImages.splice(index, 1);
    updateProductImages(updatedImages);
  };

  const handleClearAll = () => {
    if (confirm("Are you sure you want to remove all images?")) {
      updateProductImages([]);
    }
  };

  const handleProcessBatch = () => {
    if (!batchURLs.trim()) {
      setError("Please enter at least one URL");
      return;
    }

    const urls = batchURLs.split("\n").filter(url => url.trim() !== "");
    const validUrls: ProductImage[] = [];
    let invalidCount = 0;

    urls.forEach(url => {
      try {
        new URL(url.trim());
        validUrls.push({
          url: url.trim(),
          caption: "",
          altText: "Product image",
          position: currentPosition,
          size: currentSize,
          alignment: currentAlignment,
          style: currentStyle
        });
      } catch (e) {
        invalidCount++;
      }
    });

    if (validUrls.length > 0) {
      updateProductImages([...productImages, ...validUrls]);
      setBatchURLs("");
      setError(invalidCount > 0 ? `Added ${validUrls.length} images. Skipped ${invalidCount} invalid URLs.` : null);
    } else {
      setError("No valid URLs found. Please check your input.");
    }
  };

  const positionOptions = [
    { value: "header", label: "Header" },
    { value: "introduction", label: "Introduction" },
    { value: "features", label: "Features" },
    { value: "prosCons", label: "Pros/Cons" },
    { value: "pricing", label: "Pricing" },
    { value: "caseStudy", label: "Case Study" },
    { value: "conclusion", label: "Conclusion" },
    { value: "galleryOnly", label: "Gallery Only" }
  ];

  const sizeOptions = [
    { value: "small", label: "Small" },
    { value: "medium", label: "Medium" },
    { value: "large", label: "Large" },
    { value: "fullWidth", label: "Full Width" }
  ];

  const alignmentOptions = [
    { value: "left", label: "Left" },
    { value: "center", label: "Center" },
    { value: "right", label: "Right" }
  ];

  const styleOptions = [
    { value: "noBorder", label: "No Border" },
    { value: "standard", label: "Standard" },
    { value: "shadow", label: "Shadow" },
    { value: "rounded", label: "Rounded" }
  ];

  // Helper function to get readable name for display
  const getReadableName = (value: string, options: {value: string, label: string}[]): string => {
    return options.find(option => option.value === value)?.label || value;
  };

  return (
    <div className="bg-white rounded-xl shadow overflow-hidden">
      {/* Header with improved styling */}
      <div className="p-4 bg-indigo-600 text-white">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 bg-white rounded-md flex items-center justify-center">
            <Image className="h-5 w-5 text-indigo-600" />
          </div>
          <h2 className="text-lg font-semibold">Product Images</h2>
        </div>
      </div>
      
      <div className="p-5">
        {/* Info alert with improved styling */}
        <div className="bg-blue-50 rounded-lg p-4 mb-6 flex items-start gap-3">
          <Info className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="font-medium text-blue-800 text-sm mb-1">Enhance Your Review</h4>
            <p className="text-sm text-blue-700 leading-relaxed">
              High-quality product images significantly increase review engagement and conversion rates. 
              Add images strategically throughout your review to highlight features, benefits, and use cases.
            </p>
          </div>
        </div>

        {/* Tab navigation with cleaner styling */}
        <Tabs defaultValue="manual" className="w-full">
          <TabsList className="w-full mb-6 grid grid-cols-2 bg-gray-100 p-1 rounded-lg">
            <TabsTrigger value="manual" className="rounded-md text-sm">Single Image</TabsTrigger>
            <TabsTrigger value="batch" className="rounded-md text-sm">Batch Upload</TabsTrigger>
          </TabsList>

          {/* Single image upload tab */}
          <TabsContent value="manual">
            <div className="space-y-5">
              <Card className="shadow-sm">
                <CardHeader className="pb-3 pt-4 px-4">
                  <h3 className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <Image className="h-4 w-4 text-indigo-500" />
                    Image Source
                  </h3>
                </CardHeader>
                <CardContent className="px-4 pt-0 pb-4">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="imageUrl" className="text-sm text-gray-700">
                        Image URL
                      </Label>
                      <div className="flex mt-1.5 gap-2">
                        <Input 
                          id="imageUrl" 
                          type="url" 
                          placeholder="https://example.com/product-image.jpg" 
                          value={currentURL}
                          onChange={(e) => setCurrentURL(e.target.value)}
                          className="flex-1"
                        />
                        <Button 
                          type="button" 
                          variant="secondary" 
                          className="flex items-center gap-1 whitespace-nowrap"
                          onClick={handlePreview}
                        >
                          <ExternalLink className="h-4 w-4" />
                          Preview
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="imageCaption" className="text-sm text-gray-700">
                          Caption
                        </Label>
                        <Input 
                          id="imageCaption" 
                          type="text" 
                          placeholder="Product Dashboard" 
                          value={currentCaption}
                          onChange={(e) => setCurrentCaption(e.target.value)}
                          className="mt-1.5"
                        />
                      </div>
                      <div>
                        <Label htmlFor="imageAltText" className="text-sm text-gray-700">
                          Alt Text <span className="text-xs text-gray-500">(for SEO)</span>
                        </Label>
                        <Input 
                          id="imageAltText" 
                          type="text" 
                          placeholder="Description for screen readers" 
                          value={currentAltText}
                          onChange={(e) => setCurrentAltText(e.target.value)}
                          className="mt-1.5"
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Image settings with improved selectors */}
              <Card className="shadow-sm">
                <CardHeader className="pb-3 pt-4 px-4">
                  <h3 className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <Layout className="h-4 w-4 text-indigo-500" />
                    Image Settings
                  </h3>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-4 px-4 pt-0 pb-4">
                  <div>
                    <Label htmlFor="position" className="text-sm text-gray-700 mb-1.5 block">
                      Position
                    </Label>
                    <Select 
                      value={currentPosition} 
                      onValueChange={(value) => setCurrentPosition(value as ProductImage["position"])}
                    >
                      <SelectTrigger id="position" className="w-full">
                        <SelectValue placeholder="Select position" />
                      </SelectTrigger>
                      <SelectContent>
                        {positionOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="size" className="text-sm text-gray-700 mb-1.5 block">
                      Size
                    </Label>
                    <Select 
                      value={currentSize} 
                      onValueChange={(value) => setCurrentSize(value as ProductImage["size"])}
                    >
                      <SelectTrigger id="size" className="w-full">
                        <SelectValue placeholder="Select size" />
                      </SelectTrigger>
                      <SelectContent>
                        {sizeOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="alignment" className="text-sm text-gray-700 mb-1.5 block">
                      Alignment
                    </Label>
                    <Select 
                      value={currentAlignment} 
                      onValueChange={(value) => setCurrentAlignment(value as ProductImage["alignment"])}
                    >
                      <SelectTrigger id="alignment" className="w-full">
                        <SelectValue placeholder="Select alignment" />
                      </SelectTrigger>
                      <SelectContent>
                        {alignmentOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="style" className="text-sm text-gray-700 mb-1.5 block">
                      Style
                    </Label>
                    <Select 
                      value={currentStyle} 
                      onValueChange={(value) => setCurrentStyle(value as ProductImage["style"])}
                    >
                      <SelectTrigger id="style" className="w-full">
                        <SelectValue placeholder="Select style" />
                      </SelectTrigger>
                      <SelectContent>
                        {styleOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* Error message */}
              {error && (
                <div className="bg-red-50 rounded-md p-4 text-red-700 flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                  <span className="text-sm">{error}</span>
                </div>
              )}

              {/* Image preview with better styling */}
              {previewImage && (
                <Card className="shadow-sm overflow-hidden">
                  <CardHeader className="pb-2 pt-3 px-4">
                    <h3 className="text-sm font-medium text-gray-700">Image Preview</h3>
                  </CardHeader>
                  <CardContent className="px-4 py-3">
                    <div className="flex justify-center rounded-md bg-gray-50 p-4">
                      <img 
                        src={previewImage} 
                        alt="Preview" 
                        className="max-w-full max-h-60 object-contain" 
                        onError={() => {
                          setError("Failed to load image. Please check the URL.");
                          setPreviewImage(null);
                        }}
                      />
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Add button */}
              <Button 
                type="button" 
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 flex items-center justify-center gap-2"
                onClick={handleAddImage}
              >
                <Plus className="h-4 w-4" />
                Add Image to Review
              </Button>
            </div>
          </TabsContent>

          {/* Batch upload tab */}
          <TabsContent value="batch">
            <Card className="shadow-sm">
              <CardHeader className="pb-3 pt-4 px-4">
                <h3 className="text-sm font-medium text-gray-700 flex items-center gap-2">
                  <ArrowUpDown className="h-4 w-4 text-indigo-500" />
                  Batch Image Upload
                </h3>
              </CardHeader>
              <CardContent className="px-4 pt-0 pb-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="batchUrls" className="text-sm text-gray-700">
                      Image URLs <span className="text-xs text-gray-500">(one per line)</span>
                    </Label>
                    <Textarea 
                      id="batchUrls" 
                      placeholder="https://example.com/image1.jpg&#10;https://example.com/image2.jpg&#10;https://example.com/image3.jpg" 
                      className="min-h-[140px] mt-1.5"
                      value={batchURLs}
                      onChange={(e) => setBatchURLs(e.target.value)}
                    />
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="batch-position" className="text-sm text-gray-700 mb-1.5 block">
                        Position for All Images
                      </Label>
                      <Select 
                        value={currentPosition} 
                        onValueChange={(value) => setCurrentPosition(value as ProductImage["position"])}
                      >
                        <SelectTrigger id="batch-position" className="w-full">
                          <SelectValue placeholder="Select position" />
                        </SelectTrigger>
                        <SelectContent>
                          {positionOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="batch-size" className="text-sm text-gray-700 mb-1.5 block">
                        Size for All Images
                      </Label>
                      <Select 
                        value={currentSize} 
                        onValueChange={(value) => setCurrentSize(value as ProductImage["size"])}
                      >
                        <SelectTrigger id="batch-size" className="w-full">
                          <SelectValue placeholder="Select size" />
                        </SelectTrigger>
                        <SelectContent>
                          {sizeOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
                
                {/* Error message */}
                {error && (
                  <div className="bg-red-50 rounded-md p-4 text-red-700 flex items-center gap-2 mt-4">
                    <AlertCircle className="h-5 w-5 text-red-500" />
                    <span className="text-sm">{error}</span>
                  </div>
                )}
              </CardContent>
              <CardFooter className="px-4 pt-0 pb-4">
                <Button 
                  type="button" 
                  variant="default"
                  className="w-full flex items-center justify-center gap-2"
                  onClick={handleProcessBatch}
                >
                  <Check className="h-4 w-4" />
                  Process All URLs
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Images gallery with improved styling */}
        <div className="mt-8 pt-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-medium text-gray-800 flex items-center gap-2">
              <Image className="h-5 w-5 text-indigo-600" />
              Selected Images ({productImages.length})
            </h3>
            
            {productImages.length > 0 && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="text-red-600 hover:bg-red-50 hover:text-red-700 flex items-center gap-1"
                onClick={handleClearAll}
              >
                <Trash2 className="h-3.5 w-3.5" />
                Clear All
              </Button>
            )}
          </div>
          
          {productImages.length === 0 ? (
            <div className="border-dashed border border-gray-200 rounded-lg p-10 text-center bg-gray-50">
              <div className="flex justify-center mb-3">
                <Image className="h-10 w-10 text-gray-300" />
              </div>
              <p className="text-gray-500 mb-1">No images added yet</p>
              <p className="text-sm text-gray-400">Add images to enhance your product review</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {productImages.map((image, index) => (
                <Card key={index} className="overflow-hidden relative group shadow-sm hover:shadow-md transition-shadow">
                  {/* Remove button overlay */}
                  <div className="absolute top-2 right-2 z-10">
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                      onClick={() => handleRemoveImage(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  {/* Image container */}
                  <div className="h-36 overflow-hidden bg-gray-50">
                    <img 
                      src={image.url} 
                      alt={image.altText || "Product image"} 
                      className="w-full h-full object-contain p-2"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%23cccccc' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='3' width='18' height='18' rx='2' ry='2'%3E%3C/rect%3E%3Ccircle cx='8.5' cy='8.5' r='1.5'%3E%3C/circle%3E%3Cpolyline points='21 15 16 10 5 21'%3E%3C/polyline%3E%3C/svg%3E";
                      }}
                    />
                  </div>
                  
                  {/* Image details */}
                  <CardContent className="p-3">
                    <div className="text-sm font-medium text-gray-800 mb-2 truncate">
                      {image.caption || "No caption provided"}
                    </div>
                    
                    <div className="flex flex-wrap gap-1.5">
                      <Badge variant="outline" className="bg-indigo-50 text-indigo-700 border-0 text-xs px-1.5 py-0">
                        {getReadableName(image.position, positionOptions)}
                      </Badge>
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-0 text-xs px-1.5 py-0">
                        {getReadableName(image.size, sizeOptions)}
                      </Badge>
                      <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-0 text-xs px-1.5 py-0">
                        {getReadableName(image.style, styleOptions)}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}