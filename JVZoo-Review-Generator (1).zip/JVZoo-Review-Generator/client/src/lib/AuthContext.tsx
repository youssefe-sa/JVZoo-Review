import React, { createContext, useContext, useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { 
  auth, 
  loginWithEmailAndPassword, 
  registerWithEmailAndPassword, 
  logoutUser,
  onAuthStateChange 
} from './firebase';
import { User as FirebaseUser } from 'firebase/auth';
import { sendPasswordResetEmail } from 'firebase/auth';
import axios from 'axios';

type User = {
  id: string;
  email: string | null;
  username?: string;
  trialEndsAt?: string;
  subscriptionPlan?: {
    id: number;
    name: string;
    status: string;
    startDate?: Date;
    endDate?: Date;
  };
};

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (username: string, email: string, password: string, planId?: number) => Promise<boolean>;
  logout: () => Promise<void>;
  requestPasswordReset: (email: string) => Promise<boolean>;
}

// Create the context with default values
const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => false,
  register: async () => false,
  logout: async () => {},
  requestPasswordReset: async () => false,
});

// Helper function to convert Firebase user to our app User format
const formatUser = (firebaseUser: FirebaseUser): User => {
  return {
    id: firebaseUser.uid,
    email: firebaseUser.email,
    username: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User'
  };
};

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Listen for auth state changes
    const unsubscribe = onAuthStateChange((firebaseUser) => {
      setIsLoading(true);
      if (firebaseUser) {
        // User is signed in
        setUser(formatUser(firebaseUser));
      } else {
        // User is signed out
        setUser(null);
      }
      setIsLoading(false);
    });

    // Cleanup subscription on unmount
    return () => unsubscribe();
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      // First authenticate with Firebase
      const firebaseResult = await loginWithEmailAndPassword(email, password);

      if (firebaseResult.success) {
        try {
          // If Firebase auth succeeded, sync with our server
          const serverResponse = await axios.post('/api/auth/login', { 
            usernameOrEmail: email, 
            password: 'firebase-authenticated' // Password isn't actually checked by server now
          });

          if (serverResponse.data.success) {
            // Fetch user subscription information
            let userProfile: {
              trialEndsAt?: string;
              subscriptionPlan?: {
                id: number;
                name: string;
              };
              subscriptionStatus?: string;
              subscriptionStartDate?: string;
              subscriptionEndDate?: string;
            } | null = null;
            
            try {
              const userDataResponse = await axios.get('/api/user/profile');
              if (userDataResponse.data.success && userDataResponse.data.user) {
                // Update user with subscription plan and trial data
                userProfile = userDataResponse.data.user;
                setUser(prevUser => prevUser ? {
                  ...prevUser,
                  trialEndsAt: userProfile?.trialEndsAt || undefined,
                  subscriptionPlan: userProfile?.subscriptionPlan ? {
                    id: userProfile.subscriptionPlan.id,
                    name: userProfile.subscriptionPlan.name,
                    status: userProfile.subscriptionStatus || 'inactive',
                    startDate: userProfile.subscriptionStartDate ? new Date(userProfile.subscriptionStartDate) : undefined,
                    endDate: userProfile.subscriptionEndDate ? new Date(userProfile.subscriptionEndDate) : undefined
                  } : undefined
                } : null);
              }
            } catch (profileError) {
              console.error('Error fetching user profile:', profileError);
              // We don't fail the login if profile fetch fails
            }

            toast({
              title: "Login successful", 
              description: "Welcome back!",
            });
            
            // Check if user has an active subscription
            // If they do or if they have a free plan, redirect to app
            // Otherwise they should stay on current page to complete payment
            if (userProfile) {
              const hasActiveSubscription = 
                userProfile.subscriptionPlan?.id && 
                userProfile.subscriptionStatus === 'active';
                
              // Free trial plan ID is 1 based on our database
              if (hasActiveSubscription || userProfile.subscriptionPlan?.id === 1) {
                window.location.replace('/app');
              }
            } else {
              // If we couldn't get subscription info, just redirect to app
              // They'll be prompted to subscribe if needed
              window.location.replace('/app');
            }
            
            return true;
          } else {
            // If server sync failed, log the user out of Firebase
            await logoutUser();
            toast({
              title: "Login failed",
              description: "Your account was found but we couldn't log you in. Please try again later.",
              variant: "destructive",
            });
            return false;
          }
        } catch (serverError: any) {
          // If server sync failed, log the user out of Firebase
          await logoutUser();

          if (serverError.response?.status === 404) {
            toast({
              title: "Account not found",
              description: "Your account was not found in our system. Please register first.",
              variant: "destructive",
            });
          } else {
            toast({
              title: "Login failed",
              description: "Server error. Please try again later.",
              variant: "destructive",
            });
          }
          return false;
        }
      } else {
        toast({
          title: "Login failed",
          description: firebaseResult.error || "Invalid email or password",
          variant: "destructive",
        });
        return false;
      }
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error?.message || 'Login failed. Please try again.',
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (username: string, email: string, password: string, planId?: number): Promise<boolean> => {
    try {
      setIsLoading(true);

      // First create the user in our backend database
      try {
        const registerData: any = {
          username,
          email,
          password
        };

        // If a plan ID is provided, include it in the registration
        if (planId) {
          registerData.subscriptionPlanId = planId;
        }

        const serverResponse = await axios.post('/api/auth/register', registerData);

        if (!serverResponse.data.success) {
          toast({
            title: "Registration failed",
            description: serverResponse.data.message || "Registration failed. Please try again.",
            variant: "destructive",
          });
          return false;
        }
      } catch (serverError: any) {
        // If there's a server error (e.g., user already exists)
        toast({
          title: "Registration failed",
          description: serverError.response?.data?.message || 'Server error while creating account.',
          variant: "destructive",
        });
        return false;
      }

      // If backend registration was successful, let's sign in with Firebase
      const firebaseResult = await registerWithEmailAndPassword(email, password, username);

      if (firebaseResult.success) {
        toast({
          title: "Registration successful",
          description: "Your account has been created!",
        });

        // Automatically log in
        const loginSuccess = await login(email, password);
        
        // If they selected a paid plan, they should stay on the checkout page to complete payment
        // The redirection will happen automatically in the login function if no subscription plan ID was provided
        return true;
      } else {
        // If Firebase registration fails, we should try to clean up the backend user
        // But this is complex to handle, so we'll just inform the user
        toast({
          title: "Partial registration",
          description: "Account created but sign-in failed. Please try logging in.",
          variant: "default",
        });
        return false;
      }
    } catch (error: any) {
      toast({
        title: "Registration failed",
        description: error?.message || 'Registration failed. Please try again.',
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      setIsLoading(true);

      // First logout from Firebase
      const firebaseResult = await logoutUser();

      // Also logout from our backend
      try {
        await axios.post('/api/auth/logout');

        if (firebaseResult.success) {
          toast({
            title: "Logout successful",
            description: "You have been logged out.",
          });
        } else {
          toast({
            title: "Partial logout",
            description: "You've been logged out but there might be some issues. Please refresh the page.",
            variant: "default",
          });
        }
      } catch (serverError) {
        console.error('Error logging out from server:', serverError);

        // Even if server logout fails, we consider the logout successful if Firebase logout worked
        if (firebaseResult.success) {
          toast({
            title: "Partial logout",
            description: "You've been logged out but there might be some issues. Please refresh the page.",
            variant: "default",
          });
        } else {
          toast({
            title: "Logout error",
            description: firebaseResult.error || "There was an issue logging out. Please try again.",
            variant: "destructive",
          });
        }
      }
    } catch (error: any) {
      toast({
        title: "Logout error",
        description: error?.message || "There was an issue logging out. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const requestPasswordReset = async (email: string): Promise<boolean> => {
    try {
      setIsLoading(true);

      // Send password reset email via Firebase
      await sendPasswordResetEmail(auth, email);

      // Also notify our backend about the request (it won't actually send an email)
      try {
        await axios.post('/api/auth/forgot-password', { email });
      } catch (serverError) {
        console.error('Error syncing password reset with server:', serverError);
        // We don't fail the request if the server sync fails since Firebase will handle the reset
      }

      toast({
        title: "Password reset email sent",
        description: "If an account with this email exists, you will receive password reset instructions.",
      });
      return true;
    } catch (error: any) {
      toast({
        title: "Password reset failed",
        description: error?.message || 'Password reset request failed. Please try again.',
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        register,
        logout,
        requestPasswordReset,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

// Hook for easy access to the auth context
export const useAuth = (): AuthContextType => {
  // Since we've provided default values, we can be sure context is never undefined
  return useContext(AuthContext);
};