import { pgTable, text, serial, integer, boolean, json, timestamp, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Subscription plan schema
export const subscriptionPlans = pgTable("subscription_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  price: decimal("price").notNull(),
  billingCycle: text("billing_cycle").notNull(), // 'monthly' or 'yearly'
  features: json("features").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans).omit({
  id: true,
  createdAt: true,
});

// User schema with subscription details
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull(),
  password: text("password").notNull(),
  firebaseUid: text("firebase_uid").unique(),
  subscriptionPlanId: integer("subscription_plan_id"),
  subscriptionStatus: text("subscription_status").default("inactive"),
  subscriptionStartDate: timestamp("subscription_start_date"),
  subscriptionEndDate: timestamp("subscription_end_date"),
  trialEndsAt: timestamp("trial_ends_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  firebaseUid: true,
});

// Review configuration schema
export const reviewConfigs = pgTable("review_configs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  productName: text("product_name").notNull(),
  productDescription: text("product_description"),
  offerLink: text("offer_link"),
  jvDoc: text("jv_doc"),
  affiliateLink: text("affiliate_link"),
  bundleLink: text("bundle_link"),
  reviewStyle: text("review_style").notNull(),
  toneStyle: text("tone_style").notNull(),
  includePricingTable: boolean("include_pricing_table").notNull().default(true),
  includeProsConsSection: boolean("include_pros_cons_section").notNull().default(true),
  includeCtaBanner: boolean("include_cta_banner").notNull().default(true),
  includeProductImages: boolean("include_product_images").notNull().default(true),
  includeFaqSection: boolean("include_faq_section").notNull().default(false),
  
  // SEO and Keyword Options
  targetKeyword: text("target_keyword"),
  secondaryKeywords: text("secondary_keywords"),
  includeTableOfContents: boolean("include_table_of_contents").default(true),
  
  // Theme Configuration
  reviewTheme: text("review_theme").default("classic"),
  
  // Enhanced Content Elements
  includeComparisonTable: boolean("include_comparison_table").default(false),
  includeTestimonials: boolean("include_testimonials").default(false),
  includeProductRating: boolean("include_product_rating").default(true),
  productRatingScore: text("product_rating_score"),
  competingProducts: text("competing_products"),
  includeBonusSection: boolean("include_bonus_section").default(false),
  bonusContent: text("bonus_content"),
  
  // Advanced Professional Features
  usePhaseApproach: boolean("use_phase_approach").default(false),
  useMarketingCopywriting: boolean("use_marketing_copywriting").default(false),
  extendedWordCount: boolean("extended_word_count").default(false),
  includeSeoSchema: boolean("include_seo_schema").default(false),
  
  createdAt: text("created_at").notNull(),
  generatedContent: text("generated_content"),
});

export const insertReviewConfigSchema = createInsertSchema(reviewConfigs).omit({
  id: true, 
  userId: true,
  createdAt: true,
  generatedContent: true,
});

// Review template schema for saving and reusing templates
export const reviewTemplates = pgTable("review_templates", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  templateName: text("template_name").notNull(),
  templateDescription: text("template_description"),
  templateConfig: json("template_config").notNull(),
  isPublic: boolean("is_public").default(false),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at"),
});

export const insertReviewTemplateSchema = createInsertSchema(reviewTemplates).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

// Response from Google AI Studio API
export const reviewResponses = pgTable("review_responses", {
  id: serial("id").primaryKey(),
  configId: integer("config_id").notNull(),
  content: text("content").notNull(),
  htmlContent: text("html_content"),
  seoScore: integer("seo_score"),
  readabilityScore: integer("readability_score"),
  keywordDensity: json("keyword_density"),
  createdAt: text("created_at").notNull(),
});

export const insertReviewResponseSchema = createInsertSchema(reviewResponses).omit({
  id: true,
  createdAt: true,
});

// Type definitions
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertReviewConfig = z.infer<typeof insertReviewConfigSchema>;
export type ReviewConfig = typeof reviewConfigs.$inferSelect;

export type InsertReviewTemplate = z.infer<typeof insertReviewTemplateSchema>;
export type ReviewTemplate = typeof reviewTemplates.$inferSelect;

export type InsertReviewResponse = z.infer<typeof insertReviewResponseSchema>;
export type ReviewResponse = typeof reviewResponses.$inferSelect;
export type InsertSubscriptionPlan = z.infer<typeof insertSubscriptionPlanSchema>;
export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;

// Product Image type
export const ProductImageSchema = z.object({
  url: z.string().min(1),
  caption: z.string().optional(),
  altText: z.string().optional(),
  position: z.enum([
    "header", "introduction", "features", "prosCons", 
    "pricing", "caseStudy", "conclusion", "galleryOnly"
  ]),
  size: z.enum(["small", "medium", "large", "fullWidth"]),
  alignment: z.enum(["left", "center", "right"]),
  style: z.enum(["noBorder", "standard", "shadow", "rounded"]),
});

// API request schema for generating reviews
export const generateReviewSchema = z.object({
  apiKey: z.string().min(1, "API key is required"),
  model: z.string().min(1, "AI model is required"),
  productName: z.string().min(1, "Product name is required"),
  productDescription: z.string().optional(),
  offerLink: z.string().optional(),
  jvDoc: z.string().optional(),
  affiliateLink: z.string().optional(),
  bundleLink: z.string().optional(),
  reviewStyle: z.string().min(1, "Review style is required"),
  toneStyle: z.string().min(1, "Tone style is required"),
  includePricingTable: z.boolean().default(true),
  includeProsConsSection: z.boolean().default(true),
  includeCtaBanner: z.boolean().default(true),
  includeProductImages: z.boolean().default(true),
  includeFaqSection: z.boolean().default(false),
  
  // SEO and Keyword Options
  targetKeyword: z.string().optional(),
  secondaryKeywords: z.string().optional(),
  includeTableOfContents: z.boolean().optional().default(true),
  
  // Theme Configuration
  reviewTheme: z.string().optional().default("classic"),
  
  // Enhanced Content Elements
  includeComparisonTable: z.boolean().optional().default(false),
  includeTestimonials: z.boolean().optional().default(false),
  includeProductRating: z.boolean().optional().default(true),
  productRatingScore: z.string().optional(),
  competingProducts: z.string().optional(),
  includeBonusSection: z.boolean().optional().default(false),
  bonusContent: z.string().optional(),
  
  // Product Images
  productImagesList: z.array(ProductImageSchema).optional(),
  
  // Advanced Professional Features
  usePhaseApproach: z.boolean().optional().default(false),
  useMarketingCopywriting: z.boolean().optional().default(false),
  extendedWordCount: z.boolean().optional().default(false),
  includeSeoSchema: z.boolean().optional().default(false),
});

export type GenerateReviewRequest = z.infer<typeof generateReviewSchema>;

// Schema for template operations
export const saveTemplateSchema = z.object({
  templateName: z.string().min(1, "Template name is required"),
  templateDescription: z.string().optional(),
  templateConfig: z.any(),
  isPublic: z.boolean().default(false),
});

export type SaveTemplateRequest = z.infer<typeof saveTemplateSchema>;

// Authentication Schemas
export const registerUserSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters").max(50),
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Invalid email address"),
  fullName: z.string().min(2, "Full name must be at least 2 characters").optional(),
  // Subscription information can be provided during registration
  subscriptionPlanId: z.number().optional(),
  billingCycle: z.enum(["monthly", "yearly", "trial"]).optional(),
});

export const loginUserSchema = z.object({
  usernameOrEmail: z.string().min(1, "Username or email is required"),
  password: z.string().min(1, "Password is required"),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

// Payment Processing Schemas
export const paymentFormSchema = z.object({
  subscriptionPlanId: z.number().positive("A valid subscription plan is required"),
  cardName: z.string().min(1, "Cardholder name is required"),
  cardNumber: z.string().regex(/^\d{16}$/, "Card number must be 16 digits"),
  expiryMonth: z.string().regex(/^(0[1-9]|1[0-2])$/, "Month must be in MM format"),
  expiryYear: z.string().regex(/^\d{4}$/, "Year must be in YYYY format"),
  cvv: z.string().regex(/^\d{3,4}$/, "CVV must be 3 or 4 digits"),
  billingAddress: z.string().min(1, "Billing address is required"),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State/Province is required"),
  zipCode: z.string().min(1, "ZIP/Postal code is required"),
  country: z.string().min(1, "Country is required"),
  includeTrial: z.boolean().default(false),
  agreeTerms: z.boolean().refine(val => val === true, {
    message: "You must agree to the terms and conditions",
  }),
});

export const subscriptionSchema = z.object({
  subscriptionPlanId: z.number().positive("A valid plan ID is required"),
  status: z.string().optional(),
  userId: z.number().positive("A valid user ID is required"),
  billingCycle: z.enum(["monthly", "yearly", "trial"], {
    errorMap: () => ({ message: "Billing cycle must be monthly, yearly, or trial" }),
  }),
  paymentMethod: z.object({
    type: z.string(),
    lastFour: z.string(),
    expiryMonth: z.string(),
    expiryYear: z.string(),
  }),
});

export type PaymentFormData = z.infer<typeof paymentFormSchema>;
export type SubscriptionData = z.infer<typeof subscriptionSchema>;
export type RegisterUserRequest = z.infer<typeof registerUserSchema>;
export type LoginUserRequest = z.infer<typeof loginUserSchema>;
export type ForgotPasswordRequest = z.infer<typeof forgotPasswordSchema>;
