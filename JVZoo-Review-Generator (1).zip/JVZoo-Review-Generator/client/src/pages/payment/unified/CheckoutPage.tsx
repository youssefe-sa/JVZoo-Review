import React, { useState, useEffect } from 'react';
import { useRoute, useLocation } from 'wouter';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { ArrowRightIcon, CheckIcon } from '@heroicons/react/24/outline';
import { useAuth } from '@/lib/AuthContext';
import { AuthDialog } from '@/components/AuthDialog';
import { PaymentForm } from '@/components/PaymentForm';

// Define plan types
type PlanType = 'basic' | 'pro' | 'agency';
type BillingCycle = 'monthly' | 'yearly';

// Define plan structure
interface Plan {
  id: number;
  name: string;
  description: string;
  price: string;
  billingCycle: BillingCycle;
  features: string[];
}

export default function CheckoutPage() {
  // Use wouter route to extract parameters
  const [matched, params] = useRoute('/checkout/:planType?/:cycle?');
  const [, navigate] = useLocation();

  // Default to 'pro' plan and 'monthly' billing if not specified
  const initialPlanType = params?.planType as PlanType || 'pro';
  const initialCycle = params?.cycle as BillingCycle || 'monthly';

  // Use state to track the selected plan and billing cycle
  const [selectedPlanType, setSelectedPlanType] = useState<PlanType>(initialPlanType);
  const [billingCycle, setBillingCycle] = useState<BillingCycle>(initialCycle);
  const [step, setStep] = useState<'plan-select' | 'authentication' | 'payment'>('plan-select');
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [submitClicked, setSubmitClicked] = useState(false);
  
  // Get authentication status
  const { isAuthenticated } = useAuth();

  // When URL parameters change, update the state
  useEffect(() => {
    if (params?.planType) {
      setSelectedPlanType(params.planType as PlanType);
    }
    if (params?.cycle) {
      setBillingCycle(params.cycle as BillingCycle);
    }
  }, [params]);

  // Plan data
  const planData: Record<PlanType, { monthly: Plan, yearly: Plan }> = {
    basic: {
      monthly: {
        id: 1,
        name: 'Basic',
        description: 'Perfect for beginners and small websites starting with review content.',
        price: '19',
        billingCycle: 'monthly',
        features: [
          '20 AI-generated reviews per month',
          'Basic SEO optimization',
          '3 design themes',
          'Standard review templates',
          'Email support with 24-hour response time'
        ]
      },
      yearly: {
        id: 4,
        name: 'Basic',
        description: 'Perfect for beginners and small websites starting with review content.',
        price: '190',
        billingCycle: 'yearly',
        features: [
          '20 AI-generated reviews per month',
          'Basic SEO optimization',
          '3 design themes',
          'Standard review templates',
          'Email support with 24-hour response time',
          '2 months free with annual billing'
        ]
      }
    },
    pro: {
      monthly: {
        id: 2,
        name: 'Pro',
        description: 'Designed for marketing professionals and serious affiliate websites with regular review needs.',
        price: '49',
        billingCycle: 'monthly',
        features: [
          '50 AI-generated reviews per month',
          'Advanced SEO optimization with schema markup',
          'All design themes with customization options',
          'Premium review templates with higher conversions',
          'Priority email support with 8-hour response time',
          'Advanced conversion features including A/B testing',
          'Template library access with premium templates'
        ]
      },
      yearly: {
        id: 5,
        name: 'Pro',
        description: 'Designed for marketing professionals and serious affiliate websites with regular review needs.',
        price: '490',
        billingCycle: 'yearly',
        features: [
          '50 AI-generated reviews per month',
          'Advanced SEO optimization with schema markup',
          'All design themes with customization options',
          'Premium review templates with higher conversions',
          'Priority email support with 8-hour response time',
          'Advanced conversion features including A/B testing',
          'Template library access with premium templates',
          '2 months free with annual billing'
        ]
      }
    },
    agency: {
      monthly: {
        id: 3,
        name: 'Agency',
        description: 'Full-featured solution for agencies and power users managing multiple sites and clients.',
        price: '99',
        billingCycle: 'monthly',
        features: [
          'Unlimited AI-generated reviews',
          'Advanced SEO optimization with custom schema',
          'All design themes + exclusives with full customization',
          'Premium review templates with highest conversions',
          'Priority email & chat support with 4-hour response time',
          'Advanced conversion features with advanced analytics',
          'Template library access with ability to create custom templates',
          'API access & white-labeling for client portals'
        ]
      },
      yearly: {
        id: 6,
        name: 'Agency',
        description: 'Full-featured solution for agencies and power users managing multiple sites and clients.',
        price: '990',
        billingCycle: 'yearly',
        features: [
          'Unlimited AI-generated reviews',
          'Advanced SEO optimization with custom schema',
          'All design themes + exclusives with full customization',
          'Premium review templates with highest conversions',
          'Priority email & chat support with 4-hour response time',
          'Advanced conversion features with advanced analytics',
          'Template library access with ability to create custom templates',
          'API access & white-labeling for client portals',
          '2 months free with annual billing'
        ]
      }
    }
  };

  // Get the selected plan based on current state
  const selectedPlan = planData[selectedPlanType][billingCycle];

  // Handle plan selection
  const handlePlanSelect = (plan: Plan) => {
    setSelectedPlanType(plan.name.toLowerCase() as PlanType);
    const planPath = `/checkout/${plan.name.toLowerCase()}/${billingCycle}`;
    navigate(planPath);
  };

  // Handle billing cycle change
  const handleBillingCycleChange = (cycle: BillingCycle) => {
    setBillingCycle(cycle);
    const planPath = `/checkout/${selectedPlanType}/${cycle}`;
    navigate(planPath);
  };

  // Handle continue to next step
  const handleContinue = () => {
    if (!isAuthenticated) {
      setStep('authentication');
      setIsAuthOpen(true);
    } else {
      setStep('payment');
    }
  };

  // Handle authentication success
  const handleAuthSuccess = () => {
    setStep('payment');
  };

  // Handle payment success
  const handlePaymentSuccess = () => {
    navigate('/payment/success');
  };

  // Handle back to plan selection
  const handleBackToPlanSelect = () => {
    setStep('plan-select');
  };

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl mb-4">
            Complete Your Purchase
          </h1>
          <p className="text-lg text-gray-500 max-w-2xl mx-auto">
            You're just a few steps away from creating amazing product reviews that convert.
          </p>
        </div>

        {/* Progress steps */}
        <div className="mb-10">
          <div className="flex justify-center items-center space-x-4">
            <div className={`flex items-center ${step === 'plan-select' ? 'text-indigo-600 font-bold' : 'text-gray-500'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${step === 'plan-select' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                1
              </div>
              <span>Choose Plan</span>
            </div>
            <div className="w-12 h-0.5 bg-gray-200"></div>
            <div className={`flex items-center ${step === 'authentication' ? 'text-indigo-600 font-bold' : 'text-gray-500'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${step === 'authentication' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                2
              </div>
              <span>Account</span>
            </div>
            <div className="w-12 h-0.5 bg-gray-200"></div>
            <div className={`flex items-center ${step === 'payment' ? 'text-indigo-600 font-bold' : 'text-gray-500'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${step === 'payment' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
                3
              </div>
              <span>Payment</span>
            </div>
          </div>
        </div>

        {/* Plan selection */}
        {step === 'plan-select' && (
          <div className="space-y-8">
            {/* Billing toggle */}
            <div className="flex flex-col md:flex-row items-center justify-center mb-8 space-y-4 md:space-y-0">
              <span className={`text-lg ${billingCycle === 'monthly' ? 'font-semibold text-gray-900' : 'text-gray-500'}`}>
                Monthly Billing
              </span>
              <div className="mx-4 flex items-center">
                <Switch
                  checked={billingCycle === 'yearly'}
                  onCheckedChange={(checked) => handleBillingCycleChange(checked ? 'yearly' : 'monthly')}
                  className="mx-4"
                />
              </div>
              <div className="flex items-center">
                <span className={`text-lg ${billingCycle === 'yearly' ? 'font-semibold text-gray-900' : 'text-gray-500'}`}>
                  Annual Billing
                </span>
                <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  Save 20%
                </span>
              </div>
            </div>

            {/* Plan cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Basic Plan */}
              <Card 
                className={`shadow-lg transition-all duration-300 hover:shadow-xl ${selectedPlanType === 'basic' ? 'ring-2 ring-indigo-500' : ''}`}
                onClick={() => handlePlanSelect(planData.basic[billingCycle])}
              >
                <CardHeader>
                  <CardTitle>{planData.basic[billingCycle].name}</CardTitle>
                  <CardDescription>{planData.basic[billingCycle].description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-3xl font-extrabold text-gray-900">${planData.basic[billingCycle].price}</span>
                    <span className="text-gray-500">/{billingCycle === 'monthly' ? 'mo' : 'yr'}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {planData.basic[billingCycle].features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckIcon className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    variant={selectedPlanType === 'basic' ? 'default' : 'outline'} 
                    className="w-full mt-6"
                    onClick={() => handlePlanSelect(planData.basic[billingCycle])}
                  >
                    {selectedPlanType === 'basic' ? 'Selected' : 'Select Basic'}
                  </Button>
                </CardContent>
              </Card>

              {/* Pro Plan */}
              <Card 
                className={`shadow-lg transition-all duration-300 hover:shadow-xl ${selectedPlanType === 'pro' ? 'ring-2 ring-indigo-500' : ''}`}
                onClick={() => handlePlanSelect(planData.pro[billingCycle])}
              >
                <div className="py-1 px-4 bg-indigo-500 text-white text-center text-xs font-semibold">
                  MOST POPULAR
                </div>
                <CardHeader>
                  <CardTitle>{planData.pro[billingCycle].name}</CardTitle>
                  <CardDescription>{planData.pro[billingCycle].description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-3xl font-extrabold text-gray-900">${planData.pro[billingCycle].price}</span>
                    <span className="text-gray-500">/{billingCycle === 'monthly' ? 'mo' : 'yr'}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {planData.pro[billingCycle].features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckIcon className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    variant={selectedPlanType === 'pro' ? 'default' : 'outline'} 
                    className="w-full mt-6"
                    onClick={() => handlePlanSelect(planData.pro[billingCycle])}
                  >
                    {selectedPlanType === 'pro' ? 'Selected' : 'Select Pro'}
                  </Button>
                </CardContent>
              </Card>

              {/* Agency Plan */}
              <Card 
                className={`shadow-lg transition-all duration-300 hover:shadow-xl ${selectedPlanType === 'agency' ? 'ring-2 ring-indigo-500' : ''}`}
                onClick={() => handlePlanSelect(planData.agency[billingCycle])}
              >
                <CardHeader>
                  <CardTitle>{planData.agency[billingCycle].name}</CardTitle>
                  <CardDescription>{planData.agency[billingCycle].description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-3xl font-extrabold text-gray-900">${planData.agency[billingCycle].price}</span>
                    <span className="text-gray-500">/{billingCycle === 'monthly' ? 'mo' : 'yr'}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {planData.agency[billingCycle].features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <CheckIcon className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    variant={selectedPlanType === 'agency' ? 'default' : 'outline'} 
                    className="w-full mt-6"
                    onClick={() => handlePlanSelect(planData.agency[billingCycle])}
                  >
                    {selectedPlanType === 'agency' ? 'Selected' : 'Select Agency'}
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Continue button */}
            <div className="flex justify-center mt-10">
              <Button 
                size="lg" 
                className="px-10"
                onClick={handleContinue}
              >
                Continue to {isAuthenticated ? 'Payment' : 'Account'} <ArrowRightIcon className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        )}

        {/* Payment step */}
        {step === 'payment' && (
          <PaymentForm 
            plan={{
              id: selectedPlan.id,
              name: selectedPlan.name,
              price: selectedPlan.price,
              billingCycle: billingCycle,
              description: selectedPlan.description,
              features: selectedPlan.features
            }}
            onSuccess={handlePaymentSuccess}
            onCancel={handleBackToPlanSelect}
          />
        )}

        {/* Authentication Dialog */}
        <AuthDialog 
          isOpen={isAuthOpen} 
          onClose={() => setIsAuthOpen(false)} 
          defaultTab="register"
          onAuthSuccess={handleAuthSuccess}
          planId={selectedPlan.id}
        />
      </div>
    </div>
  );
}