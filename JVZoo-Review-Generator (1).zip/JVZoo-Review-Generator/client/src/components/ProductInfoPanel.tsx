interface ProductInfoPanelProps {
  productName: string;
  productDescription: string;
  offerLink: string;
  jvDoc: string;
  affiliateLink: string;
  bundleLink: string;
  updateFormData: (data: Partial<{
    productName: string;
    productDescription: string;
    offerLink: string;
    jvDoc: string;
    affiliateLink: string;
    bundleLink: string;
  }>) => void;
}

export default function ProductInfoPanel({
  productName,
  productDescription,
  offerLink,
  jvDoc,
  affiliateLink,
  bundleLink,
  updateFormData
}: ProductInfoPanelProps) {
  // Helper function to show input requirements information
  const showInputTip = (field: string) => {
    switch (field) {
      case 'productName':
        return (
          <div className="mt-1 text-xs text-gray-500 flex items-start">
            <i className="ri-information-line mr-1 mt-0.5 text-indigo-400"></i>
            <span>Enter the complete product name as it appears on sales page</span>
          </div>
        );
      case 'productDescription':
        return (
          <div className="mt-1 text-xs text-gray-500 flex items-start">
            <i className="ri-information-line mr-1 mt-0.5 text-indigo-400"></i>
            <span>For best results, include key product benefits, target audience, and main features</span>
          </div>
        );
      case 'offerLink':
        return (
          <div className="mt-1 text-xs text-indigo-600 font-medium flex items-center">
            <i className="ri-checkbox-circle-line mr-1 text-green-500"></i>
            <span>Provides essential product information for your review</span>
          </div>
        );
      case 'jvDoc':
        return (
          <div className="mt-1 text-xs text-indigo-600 font-medium flex items-center">
            <i className="ri-star-line mr-1 text-amber-500"></i>
            <span>Critical for deep analysis of marketing positioning and product benefits</span>
          </div>
        );
      case 'affiliateLink':
        return (
          <div className="mt-1 text-xs text-gray-500 flex items-center">
            <i className="ri-link-m mr-1 text-indigo-400"></i>
            <span>Used for call-to-action buttons throughout the review</span>
          </div>
        );
      case 'bundleLink':
        return (
          <div className="mt-1 text-xs text-gray-500 flex items-center">
            <i className="ri-price-tag-3-line mr-1 text-indigo-400"></i>
            <span>Used for premium call-to-action sections (optional but recommended)</span>
          </div>
        );
      default:
        return null;
    }
  };
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="p-5 border-b border-gray-100">
        <div className="flex items-center">
          <i className="ri-shopping-bag-line text-lg text-indigo-600 mr-2"></i>
          <h2 className="text-lg font-semibold text-gray-800">Product Information</h2>
        </div>
      </div>
      
      <div className="p-5">
        <div className="grid gap-5">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="productName" className="block text-sm font-medium text-gray-700">Product Name</label>
              <span className="text-xs text-indigo-600 font-medium">Required</span>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <i className="ri-shopping-bag-line text-gray-400"></i>
              </div>
              <input 
                type="text" 
                id="productName" 
                value={productName}
                onChange={(e) => updateFormData({ productName: e.target.value })}
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm" 
                placeholder="e.g., TrafficWave Pro"
              />
            </div>
            {showInputTip('productName')}
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="productDescription" className="block text-sm font-medium text-gray-700">Product Description</label>
              <span className="text-xs text-gray-500">Enhances quality</span>
            </div>
            <textarea 
              id="productDescription" 
              rows={3}
              value={productDescription}
              onChange={(e) => updateFormData({ productDescription: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm resize-none" 
              placeholder="Briefly describe what the product does, who it's for, and its main benefits"
            ></textarea>
            {showInputTip('productDescription')}
          </div>

          <div className="border-t border-gray-100 pt-4">
            <h3 className="text-sm font-medium text-gray-800 mb-2 flex items-center">
              <i className="ri-link-m text-indigo-500 mr-1.5"></i>
              Product Links
            </h3>
            
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label htmlFor="offerLink" className="block text-sm font-medium text-gray-700">JVZoo Offer Link</label>
                  <span className="text-xs text-indigo-600 font-medium">Recommended</span>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i className="ri-external-link-line text-gray-400"></i>
                  </div>
                  <input 
                    type="url" 
                    id="offerLink" 
                    value={offerLink}
                    onChange={(e) => updateFormData({ offerLink: e.target.value })}
                    className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm" 
                    placeholder="https://www.jvzoo.com/products/123456"
                  />
                </div>
                {showInputTip('offerLink')}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label htmlFor="jvDoc" className="block text-sm font-medium text-gray-700">JV Document Link</label>
                  <span className="text-xs text-amber-600 font-medium">High value</span>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i className="ri-file-text-line text-gray-400"></i>
                  </div>
                  <input 
                    type="url" 
                    id="jvDoc" 
                    value={jvDoc}
                    onChange={(e) => updateFormData({ jvDoc: e.target.value })}
                    className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm" 
                    placeholder="https://example.com/jv-doc.pdf"
                  />
                </div>
                {showInputTip('jvDoc')}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label htmlFor="affiliateLink" className="block text-sm font-medium text-gray-700">Your Affiliate Link</label>
                  <span className="text-xs text-indigo-600 font-medium">Required</span>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i className="ri-links-line text-gray-400"></i>
                  </div>
                  <input 
                    type="url" 
                    id="affiliateLink" 
                    value={affiliateLink}
                    onChange={(e) => updateFormData({ affiliateLink: e.target.value })}
                    className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm" 
                    placeholder="https://yoursite.com/recommends/product"
                  />
                </div>
                {showInputTip('affiliateLink')}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label htmlFor="bundleLink" className="block text-sm font-medium text-gray-700">Best Value Bundle/OTO Link</label>
                  <span className="text-xs text-gray-500">Optional</span>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i className="ri-price-tag-3-line text-gray-400"></i>
                  </div>
                  <input 
                    type="url" 
                    id="bundleLink" 
                    value={bundleLink}
                    onChange={(e) => updateFormData({ bundleLink: e.target.value })}
                    className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm" 
                    placeholder="https://yoursite.com/recommends/product-bundle"
                  />
                </div>
                {showInputTip('bundleLink')}
              </div>
            </div>

            <div className="bg-blue-50 rounded-md p-3 mt-5 text-xs text-blue-700 flex items-start">
              <i className="ri-information-line mt-0.5 mr-2 text-blue-500"></i>
              <p>
                <span className="font-semibold">Pro Tip:</span> For the most comprehensive review, include both the JVZoo Offer Link and JV Doc link. 
                This provides the AI with detailed product information to create a more accurate and persuasive review.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
